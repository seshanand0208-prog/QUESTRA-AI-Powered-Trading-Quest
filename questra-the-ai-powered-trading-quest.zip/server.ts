import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '10mb' }));

const PORT = 3000;

// Shared Gemini Client
let ai: GoogleGenAI | null = null;
function getGeminiClient() {
  if (!ai) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    }
  }
  return ai;
}

// 1. Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', hasApiKey: !!process.env.GEMINI_API_KEY });
});

// 2. Pre-Trade Risk & Behavioral Evaluation Endpoint (/api/gemma/evaluate)
app.post('/api/gemma/evaluate', async (req, res) => {
  try {
    const { userContext, pendingOrder } = req.body;

    const gemini = getGeminiClient();

    // Compute basic mathematical R:R and stop loss presence
    const entryPrice = Number(pendingOrder.price) || 100;
    const stopLoss = pendingOrder.stopLossPrice ? Number(pendingOrder.stopLossPrice) : null;
    const target = pendingOrder.targetPrice ? Number(pendingOrder.targetPrice) : null;
    const leverage = Number(pendingOrder.leverage) || 1;
    const quantity = Number(pendingOrder.quantity) || 1;

    let riskAmount = stopLoss ? Math.abs(entryPrice - stopLoss) * quantity * leverage : entryPrice * quantity * leverage;
    let rewardAmount = target ? Math.abs(target - entryPrice) * quantity * leverage : riskAmount * 1.5;
    let calculatedRR = stopLoss && target ? Number((rewardAmount / (riskAmount || 1)).toFixed(2)) : 1.0;

    if (!gemini) {
      // Rule-based fallback if no API key present
      let riskScore = 'LOW';
      let bias = 'NONE';
      let nudge = 'Solid trade setup! Stop loss and target are well defined.';
      let xpDelta = +50;

      if (!stopLoss) {
        riskScore = 'HIGH';
        bias = 'NO_STOP_LOSS';
        nudge = '⚠️ Missing Stop-Loss! Trading without a stop loss exposes your account to unpredictable drawdowns.';
        xpDelta = -20;
      } else if (leverage >= 10) {
        riskScore = 'CRITICAL';
        bias = 'OVER_LEVERAGING';
        nudge = `🚨 High Leverage Warning (${leverage}x)! High leverage accelerates margin calls. Lower your leverage to <=3x.`;
        xpDelta = -30;
      } else if (calculatedRR < 1.2) {
        riskScore = 'MEDIUM';
        bias = 'FOMO';
        nudge = `⚠️ Sub-optimal Risk-Reward Ratio (${calculatedRR}:1). Aim for at least 1:2 R:R to protect long-term profitability.`;
        xpDelta = +10;
      }

      return res.json({
        reasoningSteps: `<|think|>\n- Analyzing ${pendingOrder.action} order for ${pendingOrder.symbol} at ₹${entryPrice}\n- Stop Loss: ${stopLoss ? '₹' + stopLoss : 'NONE'}\n- Leverage: ${leverage}x\n- Account Daily Loss Limit: ₹${userContext?.dailyLossLimit || 500}\n- User past mistakes: ${JSON.stringify(userContext?.emotionalMistakesHistory || [])}\n- Evaluation result: Risk Score = ${riskScore}, Detected Bias = ${bias}\n</|think|>`,
        riskScore,
        detectedBias: bias,
        coachingNudge: nudge,
        riskRewardRatio: calculatedRR,
        disciplineXpDelta: xpDelta,
        recommendations: [
          stopLoss ? 'Stop Loss is set correctly' : 'Set a Stop Loss below support level',
          leverage > 3 ? 'Reduce leverage below 5x for sustainable growth' : 'Leverage is within safe bounds',
          calculatedRR < 1.5 ? 'Adjust target price higher to improve Risk:Reward' : 'Target price aligns with 1:2 R:R principle'
        ]
      });
    }

    // Call Gemini 3.6 Flash for intelligent Gemma 4 simulation reasoning & JSON output
    const promptText = `
You are Questra, an autonomous financial trading mentor & behavioral coach.
Evaluate this pending trade order against the user's trading psychology history and risk limits.

USER CONTEXT:
- Name: ${userContext?.name || 'Trader'}
- Daily Loss Limit: ₹${userContext?.dailyLossLimit || 500}
- Current Daily Drawdown: ₹${userContext?.currentDailyLoss || 0}
- Emotional Mistakes History: ${JSON.stringify(userContext?.emotionalMistakesHistory || [])}
- Discipline Score: ${userContext?.disciplineScore || 80}/100

PENDING ORDER:
- Symbol: ${pendingOrder.symbol} (${pendingOrder.symbolName || pendingOrder.symbol})
- Action: ${pendingOrder.action}
- Price: ₹${pendingOrder.price}
- Quantity: ${pendingOrder.quantity}
- Stop Loss: ${pendingOrder.stopLossPrice ? '₹' + pendingOrder.stopLossPrice : 'NONE'}
- Target Price: ${pendingOrder.targetPrice ? '₹' + pendingOrder.targetPrice : 'NONE'}
- Leverage: ${pendingOrder.leverage}x
- Calculated R:R Ratio: ${calculatedRR}:1

INSTRUCTIONS:
1. Provide a detailed step-by-step reasoning chain enclosed inside <|think|>...</|think|>.
2. Determine riskScore: "LOW", "MEDIUM", "HIGH", or "CRITICAL".
3. Identify detectedBias: "FOMO", "REVENGE_TRADING", "OVER_LEVERAGING", "NO_STOP_LOSS", "PANIC_SELLING", or "NONE".
4. Write an empathetic, educational coaching nudge (2-3 sentences) guiding the trader toward discipline.
5. Provide 3 actionable recommendations.
6. Return valid JSON matching schema.
`;

    const contentsParts: any[] = [{ text: promptText }];

    if (pendingOrder.chartImageBase64) {
      contentsParts.unshift({
        inlineData: {
          mimeType: 'image/png',
          data: pendingOrder.chartImageBase64.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, '')
        }
      });
    }

    const response = await gemini.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: { parts: contentsParts },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            reasoningSteps: { type: Type.STRING, description: "Detailed reasoning enclosed in <|think|> chain" },
            riskScore: { type: Type.STRING, description: "LOW | MEDIUM | HIGH | CRITICAL" },
            detectedBias: { type: Type.STRING, description: "FOMO | REVENGE_TRADING | OVER_LEVERAGING | NO_STOP_LOSS | PANIC_SELLING | NONE" },
            coachingNudge: { type: Type.STRING, description: "Educational, direct coaching nudge" },
            disciplineXpDelta: { type: Type.INTEGER, description: "XP reward (+50 for disciplined, -20 for high risk)" },
            recommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ['reasoningSteps', 'riskScore', 'detectedBias', 'coachingNudge', 'disciplineXpDelta', 'recommendations']
        }
      }
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({
      reasoningSteps: parsed.reasoningSteps || `<|think|>\nAnalyzing ${pendingOrder.symbol} order...\n</|think|>`,
      riskScore: parsed.riskScore || 'LOW',
      detectedBias: parsed.detectedBias || 'NONE',
      coachingNudge: parsed.coachingNudge || 'Trade evaluated successfully.',
      riskRewardRatio: calculatedRR,
      disciplineXpDelta: parsed.disciplineXpDelta ?? (stopLoss ? 50 : -20),
      recommendations: parsed.recommendations || ['Maintain strict risk discipline']
    });

  } catch (err: any) {
    console.error('Error in /api/gemma/evaluate:', err);
    // Graceful fallback
    return res.json({
      reasoningSteps: `<|think|>\n- Evaluated order via rule-based safeguard engine.\n- Checked stop loss and leverage bounds.\n</|think|>`,
      riskScore: req.body.pendingOrder?.stopLossPrice ? 'LOW' : 'HIGH',
      detectedBias: req.body.pendingOrder?.stopLossPrice ? 'NONE' : 'NO_STOP_LOSS',
      coachingNudge: req.body.pendingOrder?.stopLossPrice
        ? 'Good job defining your stop loss! Remember to stick to your target exit.'
        : '⚠️ Missing Stop Loss! Always define an exit point to safeguard your capital.',
      riskRewardRatio: 1.5,
      disciplineXpDelta: req.body.pendingOrder?.stopLossPrice ? 50 : -20,
      recommendations: ['Always use a stop loss', 'Keep risk per trade under 2%', 'Wait for trade setup confirmation']
    });
  }
});

// 3. Multimodal Chart Diagnostics Endpoint (/api/gemma/chart-analysis)
app.post('/api/gemma/chart-analysis', async (req, res) => {
  try {
    const { symbol, chartBase64, timeframe } = req.body;
    const gemini = getGeminiClient();

    if (!gemini) {
      return res.json({
        patternDetected: 'Ascending Triangle / Bullish Breakout',
        trend: 'BULLISH',
        confidenceScore: 88,
        supportLevels: [122.50, 120.00],
        resistanceLevels: [130.00, 135.00],
        keyIndicators: {
          rsi: '62.4 (Healthy Momentum)',
          macd: 'Bullish Crossover above signal',
          ema: 'Price trading above 20 & 50 EMA'
        },
        suggestedAction: 'BUY',
        tradeSetup: {
          suggestedEntry: 128.50,
          suggestedStopLoss: 122.00,
          suggestedTarget: 140.00,
          riskReward: '1 : 1.77'
        },
        gemmaAnalysisText: `Questra AI Vision identified an Ascending Triangle consolidation on the ${timeframe || '15-min'} timeframe for ${symbol || 'NVDA'}. Higher lows indicate steady accumulation by institutional buyers near key ₹122.50 support.`
      });
    }

    const promptText = `
You are Questra Vision, an expert financial chart technical analyst.
Analyze this chart for ${symbol || 'Asset'} on timeframe ${timeframe || '15m'}.

Provide a comprehensive technical breakdown including:
1. Pattern name (e.g. Bullish Engulfing, Double Bottom, Head & Shoulders, Flag, Consolidation Breakout)
2. Overall trend (BULLISH, BEARISH, or NEUTRAL)
3. Confidence score (0 to 100)
4. 2 Key Support levels and 2 Key Resistance levels
5. Indicator commentary (RSI, MACD, EMA)
6. Suggested Action (BUY, SELL, or WAIT)
7. Specific trade setup (Suggested Entry, Stop Loss, Target Price)
8. Questra Analysis summary text explaining the setup in clear educational terms.
`;

    const parts: any[] = [{ text: promptText }];
    if (chartBase64) {
      parts.unshift({
        inlineData: {
          mimeType: 'image/png',
          data: chartBase64.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, '')
        }
      });
    }

    const response = await gemini.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: { parts },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            patternDetected: { type: Type.STRING },
            trend: { type: Type.STRING },
            confidenceScore: { type: Type.INTEGER },
            supportLevels: { type: Type.ARRAY, items: { type: Type.NUMBER } },
            resistanceLevels: { type: Type.ARRAY, items: { type: Type.NUMBER } },
            keyIndicators: {
              type: Type.OBJECT,
              properties: {
                rsi: { type: Type.STRING },
                macd: { type: Type.STRING },
                ema: { type: Type.STRING }
              }
            },
            suggestedAction: { type: Type.STRING },
            tradeSetup: {
              type: Type.OBJECT,
              properties: {
                suggestedEntry: { type: Type.NUMBER },
                suggestedStopLoss: { type: Type.NUMBER },
                suggestedTarget: { type: Type.NUMBER },
                riskReward: { type: Type.STRING }
              }
            },
            gemmaAnalysisText: { type: Type.STRING }
          },
          required: ['patternDetected', 'trend', 'confidenceScore', 'supportLevels', 'resistanceLevels', 'suggestedAction', 'tradeSetup', 'gemmaAnalysisText']
        }
      }
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);

  } catch (err: any) {
    console.error('Error in /api/gemma/chart-analysis:', err);
    return res.json({
      patternDetected: 'Support Bounce Pattern',
      trend: 'BULLISH',
      confidenceScore: 82,
      supportLevels: [120.00, 118.50],
      resistanceLevels: [128.00, 132.00],
      keyIndicators: {
        rsi: '55.0 (Neutral Bullish)',
        macd: 'Positive Histogram',
        ema: 'Trading above 50 EMA'
      },
      suggestedAction: 'BUY',
      tradeSetup: {
        suggestedEntry: 124.00,
        suggestedStopLoss: 119.50,
        suggestedTarget: 133.00,
        riskReward: '1 : 2.0'
      },
      gemmaAnalysisText: 'Chart indicates price consolidation near primary support. Look for candlestick confirmation before entering.'
    });
  }
});

// 4. AI Mentor Chat Endpoint (/api/gemma/mentor-chat - "Pip" AI Tutor Persona)
app.post('/api/gemma/mentor-chat', async (req, res) => {
  try {
    const { messages, userContext, currentModule = "Risk Management 101: Stop Loss" } = req.body;
    const gemini = getGeminiClient();

    const userLevel = userContext?.role || (userContext?.level ? `Level ${userContext.level}` : 'Beginner');
    const streak = userContext?.streakDays || 1;
    const xp = userContext?.xp || 100;
    const weaknesses = userContext?.emotionalMistakesHistory?.length
      ? userContext.emotionalMistakesHistory.join(', ')
      : "Tends to skip Stop Loss, Impulsive buying on high volatility";

    if (!gemini) {
      return res.json({
        tutor_message: `Hi ${userContext?.name || 'Trader'}! I'm Pip 🐥, your AI Trading Tutor! Great job maintaining your ${streak}-day streak. If you buy a stock at ₹1,000 without a Stop Loss, what's the maximum amount you're risking?`,
        reply: `Hi ${userContext?.name || 'Trader'}! I'm Pip 🐥, your AI Trading Tutor! Great job maintaining your ${streak}-day streak. If you buy a stock at ₹1,000 without a Stop Loss, what's the maximum amount you're risking?`,
        is_user_correct: null,
        explanation: "Without a Stop Loss safety net, your entire capital is at risk if the market turns.",
        award_xp: 10,
        next_action: "QUIZ_PROMPT"
      });
    }

    const systemPrompt = `
You are "Pip", an intelligent, friendly, and encouraging AI Trading Tutor for a financial web app. Your goal is to guide beginner to intermediate retail traders through real-world trading concepts using Socratic dialogue, positive reinforcement, and practical scenarios (Questra style).

### PERSONALITY & TONE
1. Empathetic & Non-Judgmental: Never shame mistakes. Frame every wrong trade or answer as a valuable learning opportunity.
2. Socratic & Interactive: Keep responses short (2-4 sentences max per turn). Never dump walls of text. Always end with a simple, practical follow-up question or mini-challenge.
3. Plain-English Explanations: Explain financial terms (e.g., Stop Loss, Liquidity, Risk-to-Reward) using everyday analogies (e.g., comparing a Stop Loss to a safety net on a trampoline).

### LEARNING RULES
1. Step-by-Step Guidance: Break complex trading topics into small, bite-sized conversational turns.
2. Emotional Discipline Coaching: Actively watch out for signs of FOMO (Fear of Missing Out), revenge trading, or over-leveraging, and gently prompt the user to reflect on their risk management.
3. Safe Environment: Constantly remind users that this is a simulated paper-trading environment where practicing safely builds real confidence.

### USER CONTEXT
- Learner Level: ${userLevel}
- Current Skill Module: ${currentModule}
- Streaks & XP: ${streak} days, ${xp} XP
- Past Weaknesses: ${weaknesses}
- Preferred Indian Broker: ${userContext?.preferredBroker || 'Zerodha Kite'}

Conversation History:
${messages?.map((m: any) => `${m.role.toUpperCase()}: ${m.content}`).join('\n')}
`;

    const response = await gemini.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: systemPrompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tutor_message: { type: Type.STRING, description: "Your conversational response to the user. Keep it friendly and concise (2-4 sentences max)." },
            is_user_correct: { type: Type.BOOLEAN, nullable: true, description: "true | false | null" },
            explanation: { type: Type.STRING, description: "Quick breakdown of why their answer was right/wrong or key concept" },
            award_xp: { type: Type.INTEGER, description: "XP to award e.g., 0, 10, 20" },
            next_action: { type: Type.STRING, description: "CONTINUE_CONVERSATION | QUIZ_PROMPT | TRIGGER_SIMULATED_TRADE" }
          },
          required: ['tutor_message', 'award_xp', 'next_action']
        }
      }
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({
      ...parsed,
      reply: parsed.tutor_message || response.text // ensure backwards compatibility
    });
  } catch (err: any) {
    console.error('Error in /api/gemma/mentor-chat:', err);
    return res.json({
      tutor_message: "Hey there! I'm Pip 🐥! Remember: protect your capital first, and profits will follow! What stock concept or trade rule shall we practice today?",
      reply: "Hey there! I'm Pip 🐥! Remember: protect your capital first, and profits will follow! What stock concept or trade rule shall we practice today?",
      is_user_correct: null,
      explanation: "Safe paper-trading practice is the best way to build confidence.",
      award_xp: 5,
      next_action: "CONTINUE_CONVERSATION"
    });
  }
});

// 5. Interactive Trainer Node Evaluation Endpoint (/api/gemma/trainer-node)
app.post('/api/gemma/trainer-node', async (req, res) => {
  try {
    const { stageId, nodeTitle, scenarioContext, userViewpoint, selectedOption, userContext } = req.body;
    const gemini = getGeminiClient();

    if (!gemini) {
      // Fallback response if no API key
      return res.json({
        reasoningSteps: `<|think|>\n- Analyzing user response for Stage ${stageId}: "${nodeTitle}"\n- User viewpoint: "${userViewpoint || selectedOption || 'Not provided'}"\n- Evaluating risk mindset and market understanding\n</|think|>`,
        understandingAnalysis: `You highlighted a great point regarding risk control! Your perspective shows you understand that protecting capital comes before chasing aggressive profits.`,
        gemmaCoaching: `In Stage ${stageId} trading, disciplined position sizing and strict stop losses separate long-term profitable traders from gamblers. Always calculate your exact dollar risk before clicking buy.`,
        score: 92,
        passed: true,
        xpAwarded: 150,
        starsEarned: 3,
        keyTakeaways: [
          'Calculate risk before entering any position',
          'Stick to the 1% account risk limit',
          'Honor your stop loss without hesitation'
        ]
      });
    }

    const promptText = `
You are Questra, an interactive AI Trading Coach in a Duolingo-style gamified trading academy.
Your task is to teach the user by deeply understanding their viewpoint, evaluating their response, and explaining trading concepts tailored to their specific way of thinking.

STAGE & LEVEL CONTEXT:
- Stage: ${stageId} (${stageId === 1 ? 'Novice Trader - Market Basics & Risk Protection' : stageId === 2 ? 'Technical Chartist - Patterns & Indicators' : 'Master Strategist - Execution & Psychology'})
- Level Node: ${nodeTitle}
- Scenario/Question Presented: ${scenarioContext}

USER'S RESPONSE & VIEWPOINT:
- Selected Choice: ${selectedOption || 'None'}
- User's Custom Viewpoint/Explanation: "${userViewpoint || 'No additional explanation provided'}"

INSTRUCTIONS:
1. Provide step-by-step internal reasoning enclosed in <|think|>...</|think|>.
2. Write "understandingAnalysis": Directly address the user's viewpoint. Explain what they got right, why their perspective makes sense, or gently correct any flaw in their logic.
3. Write "gemmaCoaching": Provide a clear, engaging, 2-3 paragraph lesson teaching the core trading concept, drawing from real market dynamics.
4. "score": Number between 0 and 100 based on the quality of their view and answer.
5. "passed": boolean (true if score >= 60).
6. "xpAwarded": integer (100 to 250 XP).
7. "starsEarned": 1, 2, or 3 stars.
8. "keyTakeaways": Array of 3 bullet points.

Return valid JSON with these fields.
`;

    const response = await gemini.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: promptText,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            reasoningSteps: { type: Type.STRING },
            understandingAnalysis: { type: Type.STRING },
            gemmaCoaching: { type: Type.STRING },
            score: { type: Type.INTEGER },
            passed: { type: Type.BOOLEAN },
            xpAwarded: { type: Type.INTEGER },
            starsEarned: { type: Type.INTEGER },
            keyTakeaways: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ['reasoningSteps', 'understandingAnalysis', 'gemmaCoaching', 'score', 'passed', 'xpAwarded', 'starsEarned', 'keyTakeaways']
        }
      }
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);

  } catch (err: any) {
    console.error('Error in /api/gemma/trainer-node:', err);
    return res.json({
      reasoningSteps: `<|think|>\n- Processed user response via fallback trainer logic.\n</|think|>`,
      understandingAnalysis: `Your viewpoint demonstrates solid intuitive understanding of risk management!`,
      gemmaCoaching: `Mastering this stage requires balancing potential rewards with quantified capital risk. Keep applying these principles on every trade.`,
      score: 85,
      passed: true,
      xpAwarded: 120,
      starsEarned: 3,
      keyTakeaways: [
        'Protect capital with strict risk management',
        'Analyze market structure before entering',
        'Reflect on trades in your journal'
      ]
    });
  }
});

// 6. Post-Trade Post-Mortem Endpoint (/api/gemma/post-mortem)
app.post('/api/gemma/post-mortem', async (req, res) => {
  try {
    const { tradeLog } = req.body;
    const gemini = getGeminiClient();

    if (!gemini) {
      return res.json({
        aiPostMortem: {
          strengths: ['Followed position sizing guidelines', 'Clean execution'],
          mistakes: ['Did not hold until target price'],
          keyTakeaway: 'Great trade overall. Let winning trades run with trailing stop losses.',
          grade: tradeLog.pnl >= 0 ? 'A' : 'C'
        }
      });
    }

    const promptText = `
You are Questra Post-Mortem Trade Analyst.
Evaluate this completed trade:
- Symbol: ${tradeLog.symbol} (${tradeLog.action})
- Entry Price: ₹${tradeLog.entryPrice}
- Exit Price: ₹${tradeLog.exitPrice}
- Quantity: ${tradeLog.quantity}
- Net P&L: ₹${tradeLog.pnl} (${tradeLog.pnlPercentage}%)
- Duration: ${tradeLog.heldDuration}
- Bias Tag: ${tradeLog.biasDetected || 'NONE'}

Provide JSON containing:
1. "strengths": 2-3 positive execution habits
2. "mistakes": 1-2 areas for improvement
3. "keyTakeaway": 1 concise sentence summarizing the lesson
4. "grade": "A", "B", "C", "D", or "F"
`;

    const response = await gemini.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: promptText,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
            mistakes: { type: Type.ARRAY, items: { type: Type.STRING } },
            keyTakeaway: { type: Type.STRING },
            grade: { type: Type.STRING }
          },
          required: ['strengths', 'mistakes', 'keyTakeaway', 'grade']
        }
      }
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({ aiPostMortem: parsed });
  } catch (err: any) {
    console.error('Error in /api/gemma/post-mortem:', err);
    return res.json({
      aiPostMortem: {
        strengths: ['Executed exit plan correctly'],
        mistakes: ['Monitor market volatility near key levels'],
        keyTakeaway: 'Consistent execution leads to compound gains over time.',
        grade: 'B'
      }
    });
  }
});

// 7. Step-by-Step AI Trainer Example Walkthrough Endpoint (/api/gemma/trainer-example)
app.post('/api/gemma/trainer-example', async (req, res) => {
  const symbol = req.body.symbol || 'RELIANCE';
  const topic = req.body.topic || 'Bullish Breakout & Position Sizing';
  try {
    const gemini = getGeminiClient();

    if (!gemini) {
      // Fallback structured trainer example
      return res.json({
        stockSymbol: symbol,
        exampleTitle: `Mastering ${topic} on ${symbol}`,
        marketContext: `Chart on ${symbol} shows a 15-minute consolidation pattern near major resistance with rising volume.`,
        stepByStepWalkthrough: [
          { stepNumber: 1, title: 'Chart & Setup Identification', detail: `Identify ${symbol} breaking above resistance with 2x average green candle volume.` },
          { stepNumber: 2, title: 'Risk Definition (1% Rule)', detail: `Capital ₹1,000,000 -> Max risk allowed ₹1,000. Entry at ₹2,980.00, Stop Loss at ₹2,930.00 (Risk per share = ₹50.00).` },
          { stepNumber: 3, title: 'Position Size Calculation', detail: `Position Size = ₹1,000 Max Risk / ₹50 Risk per share = 20 Shares total.` },
          { stepNumber: 4, title: '1:2 Risk-to-Reward Exit Target', detail: `Target Price = ₹2,980 + (2 x ₹50) = ₹3,080.00. Target gain = ₹2,000.` }
        ],
        riskMath: {
          accountCapital: 100000,
          entryPrice: 2980,
          stopLossPrice: 2930,
          targetPrice: 3080,
          positionSizeShares: 20,
          maxLossAmount: 1000,
          maxGainAmount: 2000,
          riskRewardRatio: '1 : 2.0'
        },
        trainerKeyRules: [
          'Never enter without knowing your exact exit prices first',
          'Stick strictly to 20 shares so loss cannot exceed ₹1,000',
          'If price hits target ₹3,080, lock profits immediately or trail stop'
        ],
        interactiveQuestion: {
          prompt: `In this ${symbol} setup, if slippage moves your actual entry price up to ₹2,990 (while Stop Loss stays at ₹2,930), how many shares can you buy to keep risk at ₹1,000?`,
          options: ['20 shares', '16 shares (₹60 risk/share x 16 = ₹960)', '25 shares', '30 shares'],
          correctIndex: 1,
          explanation: `When entry rises to ₹2,990, risk per share increases to ₹60. ₹1,000 / ₹60 = 16.6 shares, so you round down to 16 shares to stay safely within your ₹1,000 risk budget!`,
          xpReward: 50
        }
      });
    }

    const promptText = `
You are Questra AI Trainer in a gamified Indian Stock Trading Academy simulator app.
Generate an engaging, highly detailed step-by-step example trade walkthrough for Indian stock ticker "${symbol}" on topic "${topic}".

Return valid JSON with:
- stockSymbol: Ticker string (e.g. RELIANCE, TCS, HDFCBANK, INFY, TATAMOTORS)
- exampleTitle: Short punchy title (e.g. "1:2.5 R:R Breakout Example on RELIANCE")
- marketContext: 2-3 sentences describing price action & technical indicators (RSI, volume, EMA)
- stepByStepWalkthrough: Array of 4 objects with: { stepNumber: number, title: string, detail: string }
- riskMath: Object with { accountCapital: number, entryPrice: number, stopLossPrice: number, targetPrice: number, positionSizeShares: number, maxLossAmount: number, maxGainAmount: number, riskRewardRatio: string }
- trainerKeyRules: Array of 3 bullet rule strings
- interactiveQuestion: Object with { prompt: string, options: Array of 4 strings, correctIndex: number (0-3), explanation: string, xpReward: 50 }
`;

    const response = await gemini.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: promptText,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            stockSymbol: { type: Type.STRING },
            exampleTitle: { type: Type.STRING },
            marketContext: { type: Type.STRING },
            stepByStepWalkthrough: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  stepNumber: { type: Type.INTEGER },
                  title: { type: Type.STRING },
                  detail: { type: Type.STRING }
                },
                required: ['stepNumber', 'title', 'detail']
              }
            },
            riskMath: {
              type: Type.OBJECT,
              properties: {
                accountCapital: { type: Type.NUMBER },
                entryPrice: { type: Type.NUMBER },
                stopLossPrice: { type: Type.NUMBER },
                targetPrice: { type: Type.NUMBER },
                positionSizeShares: { type: Type.NUMBER },
                maxLossAmount: { type: Type.NUMBER },
                maxGainAmount: { type: Type.NUMBER },
                riskRewardRatio: { type: Type.STRING }
              },
              required: ['accountCapital', 'entryPrice', 'stopLossPrice', 'targetPrice', 'positionSizeShares', 'maxLossAmount', 'maxGainAmount', 'riskRewardRatio']
            },
            trainerKeyRules: { type: Type.ARRAY, items: { type: Type.STRING } },
            interactiveQuestion: {
              type: Type.OBJECT,
              properties: {
                prompt: { type: Type.STRING },
                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                correctIndex: { type: Type.INTEGER },
                explanation: { type: Type.STRING },
                xpReward: { type: Type.INTEGER }
              },
              required: ['prompt', 'options', 'correctIndex', 'explanation', 'xpReward']
            }
          },
          required: ['stockSymbol', 'exampleTitle', 'marketContext', 'stepByStepWalkthrough', 'riskMath', 'trainerKeyRules', 'interactiveQuestion']
        }
      }
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);

  } catch (err: any) {
    console.error('Error in /api/gemma/trainer-example:', err);
    return res.json({
      stockSymbol: symbol,
      exampleTitle: `Mastering Trade Execution on ${symbol}`,
      marketContext: `Price action on ${symbol} near key moving average support zone.`,
      stepByStepWalkthrough: [
        { stepNumber: 1, title: 'Identify Setup', detail: 'Locate support level and candle reversal signal.' },
        { stepNumber: 2, title: 'Set Risk Limit', detail: 'Determine 1% max drawdown limit.' },
        { stepNumber: 3, title: 'Calculate Position Size', detail: 'Divide max dollar risk by price distance to stop loss.' },
        { stepNumber: 4, title: 'Execute & Manage', detail: 'Set limit buy order with automated stop loss.' }
      ],
      riskMath: {
        accountCapital: 100000,
        entryPrice: 1800,
        stopLossPrice: 1770,
        targetPrice: 1860,
        positionSizeShares: 33,
        maxLossAmount: 990,
        maxGainAmount: 1980,
        riskRewardRatio: '1 : 2.0'
      },
      trainerKeyRules: [
        'Always set stop loss when placing orders',
        'Respect daily loss limits',
        'Review performance in journal'
      ],
      interactiveQuestion: {
        prompt: 'What is the primary benefit of defining your stop loss before entering a trade?',
        options: [
          'Guarantees 100% winning trades',
          'Caps maximum financial loss and removes emotional panic',
          'Eliminates stock market volatility',
          'Doubles your leverage automatically'
        ],
        correctIndex: 1,
        explanation: 'A predefined stop loss sets a strict maximum loss limit and prevents emotional decision-making during high market volatility.',
        xpReward: 50
      }
    });
  }
});

// Vite Middleware for development & static handling for production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Questra Trade Mentor Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
