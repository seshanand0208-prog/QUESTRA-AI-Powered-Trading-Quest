import React, { useState, useEffect } from 'react';
import {
  INITIAL_USER_CONTEXT,
  INITIAL_TICKERS,
  ACADEMY_MODULES,
  DAILY_CHALLENGES,
  BADGES,
  INITIAL_JOURNAL_ENTRIES,
} from './data/mockMarketData';
import { UserContext, PendingOrder, Position, TradeJournalEntry, AcademyModule, DailyChallenge, Badge } from './types';
import { Navbar } from './components/Navbar';
import { TradingTerminal } from './components/TradingTerminal';
import { GemmaTradeNudgeModal } from './components/GemmaTradeNudgeModal';
import { AcademyView } from './components/AcademyView';
import { TradeJournalView } from './components/TradeJournalView';
import { MentorChatView } from './components/MentorChatView';
import { AccountDashboardView } from './components/AccountDashboardView';
import { AuthScreen } from './components/AuthScreen';
import { OnboardingQuestraModal } from './components/OnboardingQuestraModal';
import { QuestraSplashScreen } from './components/QuestraSplashScreen';

export default function App() {
  const [showSplash, setShowSplash] = useState<boolean>(true);

  // Start with loggedOut by default to land on the Login/Sign Up page first as requested
  const [user, setUser] = useState<UserContext>({
    ...INITIAL_USER_CONTEXT,
    isLoggedIn: false,
    hasCompletedOnboarding: false,
    preferredBroker: 'Zerodha Kite',
    hearts: 5,
    maxHearts: 5,
  });

  const [tickers, setTickers] = useState(INITIAL_TICKERS);
  const [positions, setPositions] = useState<Position[]>([
    {
      id: 'pos_init_1',
      symbol: 'RELIANCE',
      symbolName: 'Reliance Industries Ltd.',
      action: 'BUY',
      entryPrice: 2940.50,
      currentPrice: 2985.00,
      quantity: 15,
      leverage: 1,
      stopLoss: 2900.00,
      target: 3050.00,
      pnl: 667.50,
      pnlPercentage: 1.51,
      timestamp: 'Today 10:15 AM',
    },
  ]);
  const [journalEntries, setJournalEntries] = useState<TradeJournalEntry[]>(INITIAL_JOURNAL_ENTRIES);
  const [modules, setModules] = useState<AcademyModule[]>(ACADEMY_MODULES);
  const [challenges, setChallenges] = useState<DailyChallenge[]>(DAILY_CHALLENGES);
  const [badges, setBadges] = useState<Badge[]>(BADGES);

  const [activeTab, setActiveTab] = useState<'terminal' | 'academy' | 'journal' | 'chat' | 'account'>('terminal');
  const [theme, setTheme] = useState<'dark' | 'light'>('light');

  // Onboarding Modal Trigger
  const [isBrokerSwitchOpen, setIsBrokerSwitchOpen] = useState<boolean>(false);

  // Pre-Trade Nudge Modal state
  const [isNudgeModalOpen, setIsNudgeModalOpen] = useState<boolean>(false);
  const [pendingNudgeOrder, setPendingNudgeOrder] = useState<PendingOrder | null>(null);
  const [hasApiKey, setHasApiKey] = useState<boolean>(true);

  // Check health on load
  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => setHasApiKey(data.hasApiKey))
      .catch(() => setHasApiKey(false));
  }, []);

  const handleLogin = (userProfile: UserContext) => {
    setUser({ ...userProfile, isLoggedIn: true });
  };

  const handleLogout = () => {
    setUser((prev) => ({ ...prev, isLoggedIn: false }));
  };

  const handleUpdateUser = (updatedUser: Partial<UserContext>) => {
    setUser((prev) => ({ ...prev, ...updatedUser }));
  };

  const handleSwitchProfile = (profile: UserContext) => {
    setUser({ ...profile, isLoggedIn: true, hasCompletedOnboarding: true });
  };

  const handleResetBalance = () => {
    setUser((prev) => ({ ...prev, paperBalance: 100000, currentDailyLoss: 0, hearts: 5 }));
  };

  const handleOpenNudgeModal = (order: PendingOrder) => {
    setPendingNudgeOrder(order);
    setIsNudgeModalOpen(true);
  };

  const handleConfirmOrder = (order: PendingOrder, xpDelta: number) => {
    // 1. Update XP & Level
    setUser((prev) => {
      const newXp = Math.max(0, prev.xp + xpDelta);
      let newLevel = prev.level;
      let newNextXp = prev.nextLevelXp;

      if (newXp >= prev.nextLevelXp) {
        newLevel += 1;
        newNextXp += 1000;
      }

      const isDisciplined = xpDelta > 0;
      const newDisciplineScore = Math.min(
        100,
        Math.max(10, prev.disciplineScore + (isDisciplined ? 2 : -5))
      );

      return {
        ...prev,
        xp: newXp,
        level: newLevel,
        nextLevelXp: newNextXp,
        disciplineScore: newDisciplineScore,
      };
    });

    // 2. Add to active positions
    const newPosition: Position = {
      id: `pos_${Date.now()}`,
      symbol: order.symbol,
      symbolName: order.symbolName,
      action: order.action,
      entryPrice: order.price,
      currentPrice: order.price,
      quantity: order.quantity,
      leverage: order.leverage,
      stopLoss: order.stopLossPrice,
      target: order.targetPrice,
      pnl: 0,
      pnlPercentage: 0,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setPositions((prev) => [newPosition, ...prev]);

    // 3. Update Daily Challenges
    if (order.stopLossPrice) {
      setChallenges((prev) =>
        prev.map((ch) =>
          ch.type === 'TRADE_WITH_STOP_LOSS'
            ? { ...ch, progress: Math.min(ch.target, ch.progress + 1) }
            : ch
        )
      );
    }
  };

  const handleClosePosition = (positionId: string) => {
    const pos = positions.find((p) => p.id === positionId);
    if (!pos) return;

    const currentTicker = tickers.find((t) => t.symbol === pos.symbol);
    const exitPrice = currentTicker ? currentTicker.price : pos.currentPrice;
    const priceDiff = pos.action === 'BUY' ? exitPrice - pos.entryPrice : pos.entryPrice - exitPrice;
    const pnl = priceDiff * pos.quantity * pos.leverage;
    const pnlPercentage = Number(((priceDiff / pos.entryPrice) * 100 * pos.leverage).toFixed(2));

    const newJournalEntry: TradeJournalEntry = {
      id: `jour_${Date.now()}`,
      symbol: pos.symbol,
      action: pos.action,
      entryPrice: pos.entryPrice,
      exitPrice: exitPrice,
      quantity: pos.quantity,
      pnl: pnl,
      pnlPercentage: pnlPercentage,
      heldDuration: '35 mins',
      biasDetected: pos.stopLoss ? 'NONE' : 'NO_STOP_LOSS',
      disciplineXpGained: pos.stopLoss ? 50 : 0,
      timestamp: new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setJournalEntries((prev) => [newJournalEntry, ...prev]);
    setPositions((prev) => prev.filter((p) => p.id !== positionId));
  };

  const handleUpdateJournalEntry = (updatedEntry: TradeJournalEntry) => {
    setJournalEntries((prev) =>
      prev.map((e) => (e.id === updatedEntry.id ? updatedEntry : e))
    );
  };

  const handleCompleteQuiz = (xpGained: number) => {
    setUser((prev) => ({
      ...prev,
      xp: prev.xp + xpGained,
    }));
  };

  const handleClaimChallenge = (challengeId: string, xpReward: number) => {
    setChallenges((prev) =>
      prev.map((c) => (c.id === challengeId ? { ...c, completed: true } : c))
    );
    setUser((prev) => ({
      ...prev,
      xp: prev.xp + xpReward,
    }));
  };

  // App Startup Animated Splash Screen with QUESTRA Logo
  if (showSplash) {
    return <QuestraSplashScreen onFinishSplash={() => setShowSplash(false)} />;
  }

  // If user is NOT logged in, show full-screen Auth Page
  if (!user.isLoggedIn) {
    return <AuthScreen onLogin={handleLogin} />;
  }

  return (
    <div className={`min-h-screen font-sans transition-colors duration-200 selection:bg-emerald-500 selection:text-white ${
      theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'
    }`}>
      {/* Top Navbar */}
      <Navbar
        user={user}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        hasApiKey={hasApiKey}
        onLogout={handleLogout}
        onOpenAuthModal={() => setUser((prev) => ({ ...prev, isLoggedIn: false }))}
        onOpenBrokerSwitch={() => setIsBrokerSwitchOpen(true)}
        theme={theme}
        onToggleTheme={() => setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'))}
      />

      {/* Main Container */}
      <main className="pb-16">
        {activeTab === 'terminal' && (
          <TradingTerminal
            tickers={tickers}
            setTickers={setTickers}
            user={user}
            onOpenNudgeModal={handleOpenNudgeModal}
            positions={positions}
            onClosePosition={handleClosePosition}
          />
        )}

        {activeTab === 'academy' && (
          <AcademyView
            user={user}
            challenges={challenges}
            badges={badges}
            onCompleteQuiz={handleCompleteQuiz}
            onClaimChallenge={handleClaimChallenge}
          />
        )}

        {activeTab === 'journal' && (
          <TradeJournalView
            entries={journalEntries}
            onUpdateEntry={handleUpdateJournalEntry}
          />
        )}

        {activeTab === 'chat' && (
          <MentorChatView user={user} onUpdateUser={handleUpdateUser} />
        )}

        {activeTab === 'account' && (
          <AccountDashboardView
            user={user}
            badges={badges}
            onUpdateUser={handleUpdateUser}
            onLogout={handleLogout}
            onSwitchProfile={handleSwitchProfile}
            onResetBalance={handleResetBalance}
          />
        )}
      </main>

      {/* Onboarding & App Tutorial with QUESTRA Modal */}
      {(!user.hasCompletedOnboarding || isBrokerSwitchOpen) && (
        <OnboardingQuestraModal
          user={user}
          onCompleteOnboarding={(updatedUser) => {
            handleUpdateUser({ ...updatedUser, hasCompletedOnboarding: true });
            setIsBrokerSwitchOpen(false);
            setActiveTab('academy'); // Automatically start trading lessons directly!
          }}
        />
      )}

      {/* Gemma Trade Pre-Trade Evaluation Nudge Modal */}
      {pendingNudgeOrder && (
        <GemmaTradeNudgeModal
          isOpen={isNudgeModalOpen}
          onClose={() => setIsNudgeModalOpen(false)}
          pendingOrder={pendingNudgeOrder}
          userContext={user}
          onConfirmOrder={handleConfirmOrder}
        />
      )}
    </div>
  );
}
