import { StockTicker, UserContext, AcademyModule, DailyChallenge, Badge, TradeJournalEntry } from '../types';

export const INITIAL_USER_CONTEXT: UserContext = {
  userId: 'user_questra_001',
  name: 'Alex Mercer',
  email: 'alex.mercer@questra.ai',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
  paperBalance: 100000,
  level: 2,
  xp: 450,
  nextLevelXp: 1000,
  disciplineScore: 84,
  streakDays: 5,
  dailyLossLimit: 2000,
  currentDailyLoss: 350,
  winRate: 64,
  emotionalMistakesHistory: [
    { bias: 'FOMO', count: 3, lastOccurred: '2 days ago' },
    { bias: 'NO_STOP_LOSS', count: 2, lastOccurred: 'Yesterday' },
    { bias: 'OVER_LEVERAGING', count: 1, lastOccurred: '4 days ago' }
  ],
  unlockedBadges: ['badge_first_trade', 'badge_stop_loss_master', 'badge_streak_5'],
  unlockedStage: 1,
  completedNodes: ['node_1_1'],
  isLoggedIn: true,
  role: 'Discipline Apprentice',
  joinedDate: 'July 2026',
  riskTolerance: 'Balanced',
  enableAiNudge: true,
  enforceStopLoss: true
};

export const PRESET_TRADER_PROFILES: UserContext[] = [
  INITIAL_USER_CONTEXT,
  {
    userId: 'user_priya_002',
    name: 'Priya Sharma',
    email: 'priya.sharma@niftyquest.in',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200',
    paperBalance: 250000,
    level: 4,
    xp: 1850,
    nextLevelXp: 2500,
    disciplineScore: 94,
    streakDays: 14,
    dailyLossLimit: 5000,
    currentDailyLoss: 0,
    winRate: 72,
    emotionalMistakesHistory: [
      { bias: 'FOMO', count: 1, lastOccurred: '12 days ago' }
    ],
    unlockedBadges: ['badge_first_trade', 'badge_stop_loss_master', 'badge_streak_5', 'badge_streak_10'],
    unlockedStage: 3,
    completedNodes: ['node_1_1', 'node_1_2', 'node_1_3', 'node_2_1', 'node_2_2'],
    isLoggedIn: true,
    role: 'Risk Master',
    joinedDate: 'May 2026',
    riskTolerance: 'Conservative',
    enableAiNudge: true,
    enforceStopLoss: true
  },
  {
    userId: 'user_rahul_003',
    name: 'Rahul Verma',
    email: 'rahul.verma@cryptomarket.io',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
    paperBalance: 50000,
    level: 1,
    xp: 150,
    nextLevelXp: 500,
    disciplineScore: 68,
    streakDays: 2,
    dailyLossLimit: 1500,
    currentDailyLoss: 800,
    winRate: 51,
    emotionalMistakesHistory: [
      { bias: 'FOMO', count: 5, lastOccurred: 'Today' },
      { bias: 'REVENGE_TRADING', count: 3, lastOccurred: '3 days ago' },
      { bias: 'NO_STOP_LOSS', count: 4, lastOccurred: 'Yesterday' }
    ],
    unlockedBadges: ['badge_first_trade'],
    unlockedStage: 1,
    completedNodes: [],
    isLoggedIn: true,
    role: 'Junior Novice',
    joinedDate: 'July 2026',
    riskTolerance: 'Aggressive',
    enableAiNudge: true,
    enforceStopLoss: false
  }
];

export const INITIAL_TICKERS: StockTicker[] = [
  {
    symbol: 'RELIANCE',
    name: 'Reliance Industries Ltd.',
    price: 2980.50,
    change: +42.80,
    changePercent: +1.46,
    high: 2995.00,
    low: 2935.10,
    volume: '8.4M',
    category: 'STOCKS',
    history: [2920.0, 2935.5, 2940.0, 2955.0, 2962.0, 2970.0, 2980.5]
  },
  {
    symbol: 'TCS',
    name: 'Tata Consultancy Services',
    price: 4150.20,
    change: +65.40,
    changePercent: +1.60,
    high: 4175.00,
    low: 4080.00,
    volume: '3.2M',
    category: 'STOCKS',
    history: [4070.0, 4090.0, 4110.0, 4125.0, 4140.0, 4150.2]
  },
  {
    symbol: 'HDFCBANK',
    name: 'HDFC Bank Ltd.',
    price: 1640.30,
    change: -12.50,
    changePercent: -0.76,
    high: 1660.00,
    low: 1635.00,
    volume: '14.8M',
    category: 'STOCKS',
    history: [1665.0, 1658.0, 1652.0, 1648.0, 1642.0, 1640.3]
  },
  {
    symbol: 'INFY',
    name: 'Infosys Limited',
    price: 1820.75,
    change: +28.50,
    changePercent: +1.59,
    high: 1835.00,
    low: 1790.00,
    volume: '9.6M',
    category: 'STOCKS',
    history: [1785.0, 1795.0, 1805.0, 1812.0, 1820.75]
  },
  {
    symbol: 'ICICIBANK',
    name: 'ICICI Bank Ltd.',
    price: 1215.60,
    change: +14.20,
    changePercent: +1.18,
    high: 1222.00,
    low: 1200.00,
    volume: '11.5M',
    category: 'STOCKS',
    history: [1198.0, 1204.0, 1208.0, 1212.0, 1215.6]
  },
  {
    symbol: 'TATAMOTORS',
    name: 'Tata Motors Ltd.',
    price: 1045.80,
    change: -18.40,
    changePercent: -1.73,
    high: 1070.00,
    low: 1040.00,
    volume: '12.1M',
    category: 'STOCKS',
    history: [1068.0, 1062.0, 1055.0, 1050.0, 1045.8]
  },
  {
    symbol: 'BHARTIARTL',
    name: 'Bharti Airtel Ltd.',
    price: 1480.00,
    change: +22.00,
    changePercent: +1.51,
    high: 1490.00,
    low: 1455.00,
    volume: '5.8M',
    category: 'STOCKS',
    history: [1450.0, 1460.0, 1468.0, 1475.0, 1480.0]
  },
  {
    symbol: 'LT',
    name: 'Larsen & Toubro Ltd.',
    price: 3620.40,
    change: +45.80,
    changePercent: +1.28,
    high: 3640.00,
    low: 3570.00,
    volume: '2.4M',
    category: 'STOCKS',
    history: [3560.0, 3580.0, 3600.0, 3612.0, 3620.4]
  },
  {
    symbol: 'NIFTY50',
    name: 'NIFTY 50 Index Fund',
    price: 24850.00,
    change: +180.50,
    changePercent: +0.73,
    high: 24910.00,
    low: 24680.00,
    volume: '54.2M',
    category: 'INDICES',
    history: [24620.0, 24690.0, 24740.0, 24800.0, 24850.0]
  },
  {
    symbol: 'BANKNIFTY',
    name: 'BANK NIFTY Index Fund',
    price: 51820.00,
    change: -210.00,
    changePercent: -0.40,
    high: 52150.00,
    low: 51700.00,
    volume: '38.1M',
    category: 'INDICES',
    history: [52050.0, 51980.0, 51920.0, 51880.0, 51820.0]
  }
];

export const ACADEMY_MODULES: AcademyModule[] = [
  {
    id: 'mod_1',
    title: '1. The Golden Rule of Risk Management',
    category: 'Risk & Capital Protection',
    description: 'Learn how professional traders protect capital using the 1% rule, Risk-to-Reward ratio, and mandatory Stop-Loss discipline.',
    icon: 'ShieldCheck',
    difficulty: 'Beginner',
    xpReward: 150,
    completed: true,
    lessons: [
      {
        id: 'les_1_1',
        title: 'Calculating Position Size & The 1% Rule',
        content: 'Never risk more than 1% to 2% of your total account equity on a single trade. If your capital is ₹10,000, your maximum risk per trade should be ₹100. Calculate position size by dividing your max risk by the distance to your stop loss.',
        keyTakeaways: [
          'Max risk = Account Balance × 1%',
          'Position Size = Max Risk / (Entry Price - Stop Loss Price)',
          'Protecting capital is more critical than making profits.'
        ],
        quiz: {
          question: 'If you have a ₹5,000 account and follow the 1% risk rule with a stock priced at ₹100 and Stop Loss at ₹95 (risk ₹5 per share), how many shares should you buy?',
          options: ['500 shares', '10 shares (₹50 risk)', '100 shares (₹500 risk)', '25 shares'],
          correctIndex: 1,
          explanation: '1% of ₹5,000 is ₹50 max risk. Distance to stop loss is ₹100 - ₹95 = ₹5. ₹50 / ₹5 = 10 shares.'
        }
      }
    ]
  },
  {
    id: 'mod_2',
    title: '2. Spotting High Probability Price Patterns',
    category: 'Technical Analysis',
    description: 'Master candlesticks, support/resistance breakouts, Bull Flags, and Double Bottom reversals.',
    icon: 'TrendingUp',
    difficulty: 'Intermediate',
    xpReward: 250,
    completed: false,
    lessons: [
      {
        id: 'les_2_1',
        title: 'Bullish Engulfing & Breakout Confirmation',
        content: 'A Bullish Engulfing candlestick pattern occurs at the bottom of a downtrend when a large green body completely covers the previous red candle, indicating buyers taking control with volume confirmation.',
        keyTakeaways: [
          'Second candle must engulf the real body of the first candle',
          'Higher volume on engulfing candle confirms strong momentum',
          'Place stop loss just below the swing low of the pattern'
        ],
        quiz: {
          question: 'Where should your Stop Loss be placed when trading a Bullish Engulfing breakout?',
          options: ['At current market price', 'Just below the lowest wick of the engulfing pattern', '10% below entry without looking at chart', 'No stop loss needed if pattern is clear'],
          correctIndex: 1,
          explanation: 'Placing stop loss just below the recent swing low / pattern wick protects you if the breakout fails.'
        }
      }
    ]
  },
  {
    id: 'mod_3',
    title: '3. Behavioral Psychology & Conquering FOMO',
    category: 'Trader Psychology',
    description: 'Identify emotional triggers like Fear Of Missing Out (FOMO), revenge trading after a loss, and over-leveraging.',
    icon: 'Brain',
    difficulty: 'Intermediate',
    xpReward: 300,
    completed: false,
    lessons: [
      {
        id: 'les_3_1',
        title: 'Detecting & Defeating FOMO',
        content: 'FOMO strikes when a stock shoots up 10%+ rapidly and you feel compelled to buy near the top without a trading plan or stop loss. Chasing extended green candles usually leads to buying the exact top before a pullback.',
        keyTakeaways: [
          'Never buy a stock that has moved >3 ATRs away from moving averages',
          'Wait for a pull-back to key support levels or moving averages',
          'There is always another high-probability trade opportunity coming'
        ],
        quiz: {
          question: 'A stock is up 15% in 20 minutes with RSI at 88. You feel urgent urge to jump in before missing gains. What is the disciplined move?',
          options: ['Market order with 10x leverage immediately', 'Step back, mark support levels, wait for consolidation/pullback', 'Sell all other positions to buy more shares', 'Cancel stop losses to stay in trade'],
          correctIndex: 1,
          explanation: 'Chasing an overextended stock (RSI 88) is classic FOMO. Disciplined traders wait for a retracement to key support before entering.'
        }
      }
    ]
  }
];

export const DAILY_CHALLENGES: DailyChallenge[] = [
  {
    id: 'ch_1',
    title: 'Stop-Loss Guardian',
    description: 'Execute 2 paper trades with a defined Stop Loss & minimum 1:2 R:R ratio.',
    xpReward: 100,
    progress: 1,
    target: 2,
    completed: false,
    type: 'TRADE_WITH_STOP_LOSS'
  },
  {
    id: 'ch_2',
    title: 'FOMO Shield Active',
    description: 'Trade without triggering any FOMO or over-leveraging warnings today.',
    xpReward: 80,
    progress: 1,
    target: 1,
    completed: true,
    type: 'ZERO_FOMO_DAY'
  },
  {
    id: 'ch_3',
    title: 'Chart Pattern Master',
    description: 'Complete 1 lesson in Academy or perform 1 AI Multimodal Chart Diagnostic.',
    xpReward: 120,
    progress: 0,
    target: 1,
    completed: false,
    type: 'PATTERNS_QUIZ'
  }
];

export const BADGES: Badge[] = [
  {
    id: 'badge_first_trade',
    title: 'First Step Trader',
    description: 'Executed your first paper trade on the platform.',
    iconName: 'Zap',
    unlocked: true,
    unlockedAt: '2026-07-20'
  },
  {
    id: 'badge_stop_loss_master',
    title: 'Risk Guardian',
    description: 'Placed 10 consecutive trades with mandatory Stop-Loss defined.',
    iconName: 'Shield',
    unlocked: true,
    unlockedAt: '2026-07-25'
  },
  {
    id: 'badge_streak_5',
    title: 'Discipline Streak',
    description: 'Maintained a 5-day active trading discipline streak.',
    iconName: 'Flame',
    unlocked: true,
    unlockedAt: '2026-07-28'
  },
  {
    id: 'badge_fomo_crusher',
    title: 'FOMO Crusher',
    description: 'Heeded AI Mentor warning and edited a risky overextended trade.',
    iconName: 'Award',
    unlocked: false
  },
  {
    id: 'badge_chart_wizard',
    title: 'Chart Wizard',
    description: 'Analyzed 5 chart screenshots using Questra AI Vision.',
    iconName: 'Eye',
    unlocked: false
  }
];

export const INITIAL_JOURNAL_ENTRIES: TradeJournalEntry[] = [
  {
    id: 'jour_1',
    symbol: 'RELIANCE',
    action: 'BUY',
    entryPrice: 2920.50,
    exitPrice: 2980.00,
    quantity: 20,
    pnl: +1190.00,
    pnlPercentage: +2.03,
    heldDuration: '2 hours 15 mins',
    biasDetected: 'NONE',
    disciplineXpGained: 50,
    aiPostMortem: {
      strengths: ['Strict 1:2.5 Risk-to-Reward ratio setup', 'Honored Stop Loss at ₹2890.00', 'Patience waiting for 15-min breakout'],
      mistakes: ['Exited slightly early before target (₹3000.00) due to mild anxiety'],
      keyTakeaway: 'Great execution overall! Next time set trailing stop to capture full trend.',
      grade: 'A'
    },
    timestamp: '2026-07-28 14:30'
  },
  {
    id: 'jour_2',
    symbol: 'TATAMOTORS',
    action: 'BUY',
    entryPrice: 1070.00,
    exitPrice: 1045.00,
    quantity: 30,
    pnl: -750.00,
    pnlPercentage: -2.33,
    heldDuration: '45 mins',
    biasDetected: 'FOMO',
    disciplineXpGained: 10,
    aiPostMortem: {
      strengths: ['Stop loss activated cleanly at ₹1045.00 preventing deeper drawdown'],
      mistakes: ['Entered after 4 consecutive green candles near daily resistance'],
      keyTakeaway: 'Avoid entering when price is >2% above VWAP without consolidation.',
      grade: 'C'
    },
    timestamp: '2026-07-27 11:15'
  }
];
