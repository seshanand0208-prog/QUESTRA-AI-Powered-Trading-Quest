import { IndianBroker } from '../types';

export interface IndianBrokerDetail {
  id: IndianBroker;
  name: string;
  tagline: string;
  badgeColor: string;
  bgGradient: string;
  logoIcon: string;
  usersCount: string;
  highlights: string[];
  description: string;
}

export const POPULAR_INDIAN_BROKERS: IndianBrokerDetail[] = [
  {
    id: 'Zerodha Kite',
    name: 'Zerodha Kite',
    tagline: "India's Largest & Cleanest Discount Broker",
    badgeColor: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    bgGradient: 'from-blue-600 via-indigo-700 to-slate-900',
    logoIcon: '📈',
    usersCount: '1.2+ Crore Active Traders',
    highlights: ['Minimalist TradingView Charts', 'GTT (Good-Till-Triggered) Orders', '0 Brokerage on Equity Delivery'],
    description: 'Clean, distraction-free UI with instant market depth and fast 1-click order entry window.'
  },
  {
    id: 'Groww',
    name: 'Groww Stocks',
    tagline: "Simple & Intuitive Mobile-First Trading",
    badgeColor: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    bgGradient: 'from-emerald-600 via-teal-700 to-slate-900',
    logoIcon: '🌱',
    usersCount: '1.5+ Crore Investors',
    highlights: ['1-Tap Stop-Loss Sliders', 'Instant NSE/BSE Market Movers', 'Seamless SIP & Equity Integration'],
    description: 'User-friendly card layout with smooth visual indicators designed for fast learning.'
  },
  {
    id: 'Angel One',
    name: 'Angel One (SmartAPI)',
    tagline: 'Advanced Charting & Options Platform',
    badgeColor: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
    bgGradient: 'from-orange-600 via-amber-700 to-slate-900',
    logoIcon: '🚀',
    usersCount: '1.0+ Crore Traders',
    highlights: ['Smart API Algorithmic Execution', 'InstaTrade Options Matrix', 'Pro Advisory Nudges'],
    description: 'High-speed order routing with multi-indicator chart overlays and intraday risk analytics.'
  },
  {
    id: 'Upstox',
    name: 'Upstox Pro',
    tagline: 'High-Speed Precision Trading Engine',
    badgeColor: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    bgGradient: 'from-purple-600 via-indigo-800 to-slate-900',
    logoIcon: '⚡',
    usersCount: '80+ Lakh Active Users',
    highlights: ['Advanced Option Chain Matrix', 'Custom Technical Indicators', 'Fast Bracket Order Execution'],
    description: 'Built for speed with dark theme charts, level-2 order book depth, and quick stop-loss triggers.'
  },
  {
    id: 'ICICI Direct',
    name: 'ICICI Direct (Breeze)',
    tagline: 'Institutional-Grade Full Service Broker',
    badgeColor: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
    bgGradient: 'from-rose-600 via-pink-700 to-slate-900',
    logoIcon: '🏛️',
    usersCount: '60+ Lakh Account Holders',
    highlights: ['Institutional Research Ideas', '3-in-1 Banking & Trading Sync', 'Automated Trailing Stop Orders'],
    description: 'Trusted banking integration with robust risk management and comprehensive market analysis.'
  }
];
