import React, { useState } from 'react';
import { ChartDiagnosticResult, StockTicker } from '../types';
import { LineChart, Upload, Eye, CheckCircle2, AlertCircle, ArrowUpRight, ArrowDownRight, ShieldCheck, Target, RefreshCw } from 'lucide-react';

interface ChartDiagnosticsProps {
  tickers: StockTicker[];
}

export const ChartDiagnostics: React.FC<ChartDiagnosticsProps> = ({ tickers }) => {
  const [selectedSymbol, setSelectedSymbol] = useState<string>('RELIANCE');
  const [timeframe, setTimeframe] = useState<string>('15m');
  const [chartImageBase64, setChartImageBase64] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<ChartDiagnosticResult | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setChartImageBase64(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRunAnalysis = async () => {
    setLoading(true);
    setResult(null);

    try {
      const res = await fetch('/api/gemma/chart-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          symbol: selectedSymbol,
          chartBase64: chartImageBase64,
          timeframe,
        }),
      });
      const data = await res.json();
      setResult(data);
    } catch (err) {
      console.error('Failed to run chart analysis:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-8 text-slate-900">
      {/* Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 flex flex-wrap items-center justify-between gap-4 shadow-sm">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-indigo-600 text-xs font-mono font-bold uppercase tracking-wider">
            <Eye className="w-4 h-4" />
            <span>Questra AI Multimodal Vision Engine</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900">AI Multimodal Technical Chart Diagnostic</h2>
          <p className="text-xs text-slate-600">
            Upload stock chart screenshots or choose a ticker to scan for support/resistance, RSI divergence, and actionable trade setups.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Inputs (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-5 space-y-5 shadow-sm">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
            1. Select Ticker & Chart Image
          </h3>

          {/* Ticker Selector */}
          <div className="space-y-2">
            <label className="text-xs text-slate-600 font-medium">Select Stock / Crypto:</label>
            <div className="grid grid-cols-3 gap-2">
              {tickers.map((t) => (
                <button
                  key={t.symbol}
                  onClick={() => setSelectedSymbol(t.symbol)}
                  className={`py-2 px-3 rounded-xl border font-mono text-xs font-bold transition-all ${
                    selectedSymbol === t.symbol
                      ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-300'
                  }`}
                >
                  {t.symbol}
                </button>
              ))}
            </div>
          </div>

          {/* Timeframe */}
          <div className="space-y-2">
            <label className="text-xs text-slate-600 font-medium">Timeframe:</label>
            <div className="flex gap-2">
              {['1m', '5m', '15m', '1h', '1D'].map((tf) => (
                <button
                  key={tf}
                  onClick={() => setTimeframe(tf)}
                  className={`flex-1 py-1.5 rounded-lg border font-mono text-xs font-semibold transition-all ${
                    timeframe === tf
                      ? 'bg-indigo-600 border-indigo-600 text-white'
                      : 'bg-slate-50 border-slate-200 text-slate-600'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>

          {/* Screenshot Uploader */}
          <div className="space-y-2">
            <label className="text-xs text-slate-600 font-medium">Upload Chart Image (Optional):</label>
            <div className="border-2 border-dashed border-slate-200 rounded-xl p-4 text-center hover:border-indigo-400 transition-all bg-slate-50 relative">
              <input
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
              />
              {chartImageBase64 ? (
                <div className="space-y-2">
                  <img
                    src={chartImageBase64}
                    alt="Uploaded chart"
                    className="max-h-32 mx-auto rounded-lg object-contain border border-slate-200"
                  />
                  <p className="text-[11px] text-emerald-600 font-mono">Chart image uploaded cleanly ✓</p>
                </div>
              ) : (
                <div className="space-y-2 text-slate-500">
                  <Upload className="w-6 h-6 mx-auto text-indigo-600" />
                  <div className="text-xs font-medium text-slate-800">Drag & drop or click to upload chart screenshot</div>
                  <div className="text-[10px] text-slate-400">Supports TradingView, Zerodha, Robinhood PNG/JPG</div>
                </div>
              )}
            </div>
          </div>

          <button
            disabled={loading}
            onClick={handleRunAnalysis}
            className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-bold uppercase tracking-wider text-white shadow-sm flex items-center justify-center gap-2 transition-all"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Gemma Vision Processing Chart...</span>
              </>
            ) : (
              <>
                <Eye className="w-4 h-4" />
                <span>Run Gemma Multimodal Chart AI</span>
              </>
            )}
          </button>
        </div>

        {/* Right Output Results (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 space-y-6 shadow-sm">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center justify-between">
            <span>2. Vision Analysis Breakdown</span>
            {result && <span className="text-emerald-600 font-mono text-xs">Confidence: {result.confidenceScore}%</span>}
          </h3>

          {!result && !loading && (
            <div className="py-16 text-center text-slate-400 text-xs space-y-2">
              <LineChart className="w-10 h-10 mx-auto text-slate-300" />
              <p>Select a ticker or upload a chart screenshot and click "Run Gemma Multimodal Chart AI".</p>
            </div>
          )}

          {loading && (
            <div className="py-20 flex flex-col items-center justify-center text-center space-y-3">
              <div className="w-10 h-10 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin" />
              <p className="text-sm font-semibold text-slate-800">
                Gemma 4 Vision is decoding candlestick patterns, support/resistance, & RSI indicators...
              </p>
            </div>
          )}

          {result && !loading && (
            <div className="space-y-5">
              {/* Pattern & Trend Summary Row */}
              <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div>
                  <div className="text-xs text-slate-500">Pattern Identified</div>
                  <div className="text-base font-bold text-slate-900 font-mono">{result.patternDetected}</div>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-lg text-xs font-bold font-mono border ${
                    result.trend === 'BULLISH'
                      ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                      : result.trend === 'BEARISH'
                      ? 'bg-rose-100 text-rose-800 border-rose-300'
                      : 'bg-slate-100 text-slate-700 border-slate-200'
                  }`}>
                    {result.trend} TREND
                  </span>

                  <span className="px-3 py-1 rounded-lg text-xs font-bold font-mono bg-indigo-600 text-white">
                    {result.suggestedAction} RECOMMENDATION
                  </span>
                </div>
              </div>

              {/* Trade Plan Box */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3 font-mono">
                <div className="text-xs font-bold uppercase tracking-wider text-indigo-700 flex items-center gap-1.5">
                  <Target className="w-4 h-4" />
                  <span>Actionable Trade Setup</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                    <span className="text-slate-500 block text-[10px]">SUGGESTED ENTRY</span>
                    <span className="text-slate-900 font-bold">₹{result.tradeSetup.suggestedEntry}</span>
                  </div>
                  <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                    <span className="text-slate-500 block text-[10px]">STOP LOSS</span>
                    <span className="text-rose-600 font-bold">₹{result.tradeSetup.suggestedStopLoss}</span>
                  </div>
                  <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                    <span className="text-slate-500 block text-[10px]">TARGET EXIT</span>
                    <span className="text-emerald-600 font-bold">₹{result.tradeSetup.suggestedTarget}</span>
                  </div>
                  <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                    <span className="text-slate-500 block text-[10px]">RISK : REWARD</span>
                    <span className="text-indigo-600 font-bold">{result.tradeSetup.riskReward}</span>
                  </div>
                </div>
              </div>

              {/* Technical Indicators */}
              <div className="grid grid-cols-3 gap-3 text-xs font-mono">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-slate-500 block text-[10px]">RSI (14)</span>
                  <span className="text-slate-800 font-semibold">{result.keyIndicators.rsi}</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-slate-500 block text-[10px]">MACD</span>
                  <span className="text-slate-800 font-semibold">{result.keyIndicators.macd}</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-slate-500 block text-[10px]">EMA (20/50)</span>
                  <span className="text-slate-800 font-semibold">{result.keyIndicators.ema}</span>
                </div>
              </div>

              {/* Gemma Analysis Commentary */}
              <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-200 space-y-2">
                <div className="text-xs font-bold text-indigo-900 uppercase tracking-wider">
                  Gemma Vision Educational Breakdown
                </div>
                <p className="text-xs text-slate-700 leading-relaxed">
                  {result.gemmaAnalysisText}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
