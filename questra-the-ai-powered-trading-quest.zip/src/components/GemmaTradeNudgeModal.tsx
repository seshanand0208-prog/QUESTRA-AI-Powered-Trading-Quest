import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PendingOrder, PreTradeNudgeResult, UserContext } from '../types';
import { ShieldAlert, ShieldCheck, Brain, ChevronDown, ChevronUp, AlertTriangle, ArrowRight, CheckCircle2, RefreshCw, X } from 'lucide-react';

interface GemmaTradeNudgeModalProps {
  isOpen: boolean;
  onClose: () => void;
  pendingOrder: PendingOrder;
  userContext: UserContext;
  onConfirmOrder: (order: PendingOrder, xpDelta: number) => void;
}

export const GemmaTradeNudgeModal: React.FC<GemmaTradeNudgeModalProps> = ({
  isOpen,
  onClose,
  pendingOrder,
  userContext,
  onConfirmOrder,
}) => {
  const [loading, setLoading] = useState(true);
  const [evaluation, setEvaluation] = useState<PreTradeNudgeResult | null>(null);
  const [showThinking, setShowThinking] = useState(true);

  useEffect(() => {
    if (isOpen) {
      evaluateOrder();
    }
  }, [isOpen, pendingOrder]);

  const evaluateOrder = async () => {
    setLoading(true);
    setEvaluation(null);

    try {
      const res = await fetch('/api/gemma/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pendingOrder, userContext }),
      });
      const data = await res.json();
      setEvaluation(data);
    } catch (err) {
      console.error('Failed to evaluate trade:', err);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const getRiskBadge = (risk: string) => {
    switch (risk) {
      case 'LOW':
        return {
          bg: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40',
          icon: <ShieldCheck className="w-4 h-4 text-emerald-400" />,
          label: 'LOW RISK - DISCIPLINED',
        };
      case 'MEDIUM':
        return {
          bg: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/40',
          icon: <AlertTriangle className="w-4 h-4 text-yellow-400" />,
          label: 'MEDIUM RISK - CAUTION',
        };
      case 'HIGH':
        return {
          bg: 'bg-orange-500/20 text-orange-400 border-orange-500/40',
          icon: <ShieldAlert className="w-4 h-4 text-orange-400" />,
          label: 'HIGH RISK - BEHAVIORAL WARNING',
        };
      case 'CRITICAL':
      default:
        return {
          bg: 'bg-red-500/20 text-red-400 border-red-500/40 animate-pulse',
          icon: <ShieldAlert className="w-4 h-4 text-red-400" />,
          label: 'CRITICAL RISK - HIGH DRAWDOWN',
        };
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="bg-white border border-slate-200 rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl text-slate-900"
        >
          {/* Header */}
          <div className="bg-slate-900 px-6 py-4 border-b border-slate-800 flex items-center justify-between text-white">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center">
                <Brain className="w-5 h-5 text-emerald-400 animate-pulse" />
              </div>
              <div>
                <h3 className="font-bold text-base text-white flex items-center gap-2">
                  Questra Pre-Trade Risk Evaluation
                </h3>
                <p className="text-xs text-slate-400">
                  Checking order for {pendingOrder.symbol} against user risk limits & emotional history
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Modal Content */}
          <div className="p-6 max-h-[75vh] overflow-y-auto space-y-5">
            {/* Order Brief Summary */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
              <div>
                <span className="text-slate-500">Action:</span>{' '}
                <span className={`font-bold ${pendingOrder.action === 'BUY' ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {pendingOrder.action} {pendingOrder.quantity} shares
                </span>
              </div>
              <div>
                <span className="text-slate-500">Entry Price:</span>{' '}
                <span className="font-bold text-slate-900">₹{pendingOrder.price.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-slate-500">Stop Loss:</span>{' '}
                <span className={`font-bold ${pendingOrder.stopLossPrice ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {pendingOrder.stopLossPrice ? `₹${pendingOrder.stopLossPrice.toFixed(2)}` : 'MISSING ⚠️'}
                </span>
              </div>
              <div>
                <span className="text-slate-500">Leverage:</span>{' '}
                <span className="font-bold text-indigo-600">{pendingOrder.leverage}x</span>
              </div>
            </div>

            {/* Loading State */}
            {loading ? (
              <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-12 h-12 rounded-full border-4 border-emerald-500/20 border-t-emerald-600 animate-spin" />
                <div className="space-y-1">
                  <p className="text-sm font-semibold text-slate-800">
                    Questra AI Mentor is analyzing order book & user history...
                  </p>
                  <p className="text-xs text-slate-500 font-mono">
                    Executing &lt;|think|&gt; chain for risk-to-reward ratio & behavioral triggers
                  </p>
                </div>
              </div>
            ) : evaluation ? (
              <>
                {/* Risk Level Badge & Bias Detection Row */}
                <div className="flex flex-wrap items-center justify-between gap-3">
                  {/* Risk Badge */}
                  {(() => {
                    const badge = getRiskBadge(evaluation.riskScore);
                    return (
                      <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-bold font-mono ${badge.bg}`}>
                        {badge.icon}
                        <span>{badge.label}</span>
                      </div>
                    );
                  })()}

                  {/* Detected Bias */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500">Detected Bias:</span>
                    <span className={`text-xs font-bold font-mono px-2.5 py-1 rounded-md border ${
                      evaluation.detectedBias === 'NONE'
                        ? 'bg-slate-100 text-slate-700 border-slate-200'
                        : 'bg-rose-100 text-rose-800 border-rose-300 animate-bounce'
                    }`}>
                      {evaluation.detectedBias}
                    </span>
                  </div>
                </div>

                {/* Educational Coaching Nudge Box */}
                <div className={`p-4 rounded-xl border ${
                  evaluation.riskScore === 'LOW'
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                    : 'bg-amber-50 border-amber-200 text-amber-900'
                }`}>
                  <div className="flex items-start gap-3">
                    <Brain className={`w-5 h-5 shrink-0 mt-0.5 ${
                      evaluation.riskScore === 'LOW' ? 'text-emerald-600' : 'text-amber-600'
                    }`} />
                    <div className="space-y-1">
                      <h4 className="text-xs font-bold uppercase tracking-wide text-slate-700">
                        Questra Coaching Nudge
                      </h4>
                      <p className="text-sm leading-relaxed">
                        {evaluation.coachingNudge}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Recommendations checklist */}
                {evaluation.recommendations && evaluation.recommendations.length > 0 && (
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                    <h5 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                      Targeted Recommendations
                    </h5>
                    <ul className="space-y-1.5">
                      {evaluation.recommendations.map((rec, i) => (
                        <li key={i} className="flex items-start gap-2 text-xs text-slate-700">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Collapsible <|think|> Chain Section */}
                <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden text-white">
                  <button
                    onClick={() => setShowThinking(!showThinking)}
                    className="w-full px-4 py-2.5 flex items-center justify-between text-xs font-mono font-medium text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 transition-all"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-emerald-400 font-bold">&lt;|think|&gt;</span>
                      <span>Questra AI Internal Reasoning Chain</span>
                    </div>
                    {showThinking ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>

                  {showThinking && (
                    <div className="p-4 bg-slate-950 font-mono text-xs text-slate-300 whitespace-pre-wrap leading-relaxed border-t border-slate-800 max-h-44 overflow-y-auto">
                      {evaluation.reasoningSteps}
                    </div>
                  )}
                </div>

                {/* Discipline XP Delta Preview */}
                <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                  <span className="text-slate-500 font-medium">Discipline Reward / Penalty Preview:</span>
                  <span className={`font-bold font-mono ${
                    evaluation.disciplineXpDelta >= 0 ? 'text-emerald-600' : 'text-rose-600'
                  }`}>
                    {evaluation.disciplineXpDelta >= 0 ? `+${evaluation.disciplineXpDelta} XP` : `${evaluation.disciplineXpDelta} XP`}
                  </span>
                </div>
              </>
            ) : null}
          </div>

          {/* Footer / User Action Buttons */}
          <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex flex-wrap items-center justify-end gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-all"
            >
              Acknowledge & Edit Trade
            </button>

            {evaluation && (
              <button
                onClick={() => {
                  onConfirmOrder(pendingOrder, evaluation.disciplineXpDelta);
                  onClose();
                }}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all shadow-md ${
                  evaluation.riskScore === 'HIGH' || evaluation.riskScore === 'CRITICAL'
                    ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/20'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/20'
                }`}
              >
                <span>
                  {evaluation.riskScore === 'HIGH' || evaluation.riskScore === 'CRITICAL'
                    ? `Execute Trade (${evaluation.disciplineXpDelta} XP Penalty)`
                    : `Execute Disciplined Trade (+${evaluation.disciplineXpDelta} XP)`}
                </span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
