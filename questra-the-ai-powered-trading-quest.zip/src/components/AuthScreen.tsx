import React, { useState } from 'react';
import { UserContext } from '../types';
import { PRESET_TRADER_PROFILES } from '../data/mockMarketData';
import { QuestraLogo } from './QuestraLogo';
import { Cpu, Lock, LogIn, UserPlus, Sparkles, CheckCircle2, ArrowRight, ShieldCheck, Zap, Eye, EyeOff, Award, TrendingUp } from 'lucide-react';

interface AuthScreenProps {
  onLogin: (userProfile: UserContext) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin }) => {
  const [authMode, setAuthMode] = useState<'login' | 'signup' | 'presets'>('login');

  // Login Form
  const [emailInput, setEmailInput] = useState('alex.mercer@questra.ai');
  const [passwordInput, setPasswordInput] = useState('••••••••');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Signup Form
  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupCapital, setSignupCapital] = useState<number>(100000);
  const [signupDailyLoss, setSignupDailyLoss] = useState<number>(2000);
  const [signupRisk, setSignupRisk] = useState<'Conservative' | 'Balanced' | 'Aggressive'>('Balanced');

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput.trim()) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }

    const matched = PRESET_TRADER_PROFILES.find(
      (p) => p.email?.toLowerCase() === emailInput.toLowerCase().trim()
    );

    if (matched) {
      onLogin({ ...matched, isLoggedIn: true, hasCompletedOnboarding: matched.hasCompletedOnboarding ?? false });
    } else {
      const customUser: UserContext = {
        userId: `user_${Date.now()}`,
        name: emailInput.split('@')[0].replace('.', ' ').toUpperCase(),
        email: emailInput.trim(),
        avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200',
        paperBalance: 100000,
        level: 1,
        xp: 100,
        nextLevelXp: 500,
        disciplineScore: 85,
        streakDays: 1,
        hearts: 5,
        maxHearts: 5,
        dailyLossLimit: 2000,
        currentDailyLoss: 0,
        winRate: 50,
        emotionalMistakesHistory: [],
        unlockedBadges: ['badge_first_trade'],
        unlockedStage: 1,
        completedNodes: [],
        isLoggedIn: true,
        hasCompletedOnboarding: false,
        role: 'Discipline Apprentice',
        joinedDate: 'Today',
        riskTolerance: 'Balanced',
        enableAiNudge: true,
        enforceStopLoss: true,
      };
      onLogin(customUser);
    }
  };

  const handleSignupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!signupName.trim() || !signupEmail.trim()) {
      setErrorMsg('Please enter both your name and email.');
      return;
    }

    const newUser: UserContext = {
      userId: `user_${Date.now()}`,
      name: signupName.trim(),
      email: signupEmail.trim(),
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
      paperBalance: signupCapital,
      level: 1,
      xp: 200,
      nextLevelXp: 500,
      disciplineScore: 90,
      streakDays: 1,
      hearts: 5,
      maxHearts: 5,
      dailyLossLimit: signupDailyLoss,
      currentDailyLoss: 0,
      winRate: 60,
      emotionalMistakesHistory: [],
      unlockedBadges: ['badge_first_trade'],
      unlockedStage: 1,
      completedNodes: [],
      isLoggedIn: true,
      hasCompletedOnboarding: false,
      role: 'Trading Questor',
      joinedDate: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
      riskTolerance: signupRisk,
      enableAiNudge: true,
      enforceStopLoss: true,
    };

    onLogin(newUser);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-between relative overflow-hidden font-sans">
      {/* Background Ambient Glow Effects */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-indigo-600/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-1/2 -right-40 w-96 h-96 bg-emerald-500/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute -bottom-40 left-1/3 w-96 h-96 bg-purple-600/20 rounded-full blur-[120px] pointer-events-none" />

      {/* Top Brand Navigation */}
      <header className="max-w-7xl mx-auto w-full p-6 flex items-center justify-between z-10">
        <QuestraLogo size="sm" showSubtitle={true} layout="horizontal" />

        <div className="flex items-center gap-3 text-xs font-semibold font-mono text-slate-400">
          <span className="flex items-center gap-1.5 text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/30">
            <Zap className="w-3.5 h-3.5 fill-emerald-400" /> Questra AI Trading Quest
          </span>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-6xl mx-auto w-full px-4 py-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center z-10 my-auto">
        {/* Left Hero Pitch Section (7 cols) */}
        <div className="lg:col-span-7 space-y-8 text-left">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-mono font-bold">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <span>Master Indian Stock Trading through Gamified Questra Quests</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-none text-white">
            Learn Trading <br />
            <span className="bg-gradient-to-r from-indigo-400 via-purple-300 to-emerald-400 bg-clip-text text-transparent">
              Like Playing Questra
            </span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 max-w-xl leading-relaxed">
            Welcome to <strong>QUESTRA</strong> — guided by Pip, your Questra AI Tutor. Build risk discipline, practice 1% position sizing, and master popular Indian trading apps (Zerodha, Groww, Angel One) without risking real money!
          </p>

          {/* Gamified Pillars Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
            <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1">
              <div className="text-indigo-400 text-xs font-bold font-mono flex items-center gap-1">
                ❤️ 5 Hearts / Lives
              </div>
              <div className="text-[11px] text-slate-400">Protect capital or lose hearts</div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1">
              <div className="text-emerald-400 text-xs font-bold font-mono flex items-center gap-1">
                🔥 Daily Streaks
              </div>
              <div className="text-[11px] text-slate-400">Trade & complete drills daily</div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1">
              <div className="text-amber-400 text-xs font-bold font-mono flex items-center gap-1">
                🤖 Questra AI Nudge
              </div>
              <div className="text-[11px] text-slate-400">Blocks impulsive emotional setups</div>
            </div>
          </div>
        </div>

        {/* Right Auth Card Section (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-3xl p-8 shadow-2xl space-y-6 backdrop-blur-xl">
          {/* Auth Tabs */}
          <div className="grid grid-cols-3 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-mono font-bold">
            <button
              onClick={() => { setAuthMode('login'); setErrorMsg(''); }}
              className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                authMode === 'login'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" /> Sign In
            </button>

            <button
              onClick={() => { setAuthMode('signup'); setErrorMsg(''); }}
              className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                authMode === 'signup'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" /> Sign Up
            </button>

            <button
              onClick={() => { setAuthMode('presets'); setErrorMsg(''); }}
              className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                authMode === 'presets'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Award className="w-3.5 h-3.5" /> Demos
            </button>
          </div>

          {errorMsg && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs font-medium">
              ⚠️ {errorMsg}
            </div>
          )}

          {/* LOGIN FORM */}
          {authMode === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div className="space-y-1.5 text-left">
                <label className="text-xs font-mono font-bold text-slate-300 block">Email Address</label>
                <input
                  type="email"
                  required
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  placeholder="alex.mercer@questra.ai"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-indigo-500 transition-all"
                />
              </div>

              <div className="space-y-1.5 text-left relative">
                <label className="text-xs font-mono font-bold text-slate-300 block">Password</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-indigo-500 transition-all pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2"
              >
                <span>Enter QUESTRA Portal & Begin</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* SIGNUP FORM */}
          {authMode === 'signup' && (
            <form onSubmit={handleSignupSubmit} className="space-y-4">
              <div className="space-y-1.5 text-left">
                <label className="text-xs font-mono font-bold text-slate-300 block">Your Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rahul Verma"
                  value={signupName}
                  onChange={(e) => setSignupName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-indigo-500 transition-all"
                />
              </div>

              <div className="space-y-1.5 text-left">
                <label className="text-xs font-mono font-bold text-slate-300 block">Email Address</label>
                <input
                  type="email"
                  required
                  placeholder="rahul@example.com"
                  value={signupEmail}
                  onChange={(e) => setSignupEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-indigo-500 transition-all"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 text-left">
                <div>
                  <label className="text-[11px] font-mono font-bold text-slate-300 block">Paper Capital (₹)</label>
                  <input
                    type="number"
                    value={signupCapital}
                    onChange={(e) => setSignupCapital(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-mono font-bold text-slate-300 block">Daily Loss Limit (₹)</label>
                  <input
                    type="number"
                    value={signupDailyLoss}
                    onChange={(e) => setSignupDailyLoss(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center gap-2"
              >
                <span>Create Account & Start Quest</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* PRESETS FORM */}
          {authMode === 'presets' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-400 text-left">Pick a pre-configured trader profile to test immediately:</p>
              {PRESET_TRADER_PROFILES.map((profile) => (
                <button
                  key={profile.userId}
                  onClick={() => onLogin({ ...profile, isLoggedIn: true, hasCompletedOnboarding: false })}
                  className="w-full p-3.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-indigo-500 transition-all text-left flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={profile.avatarUrl}
                      alt={profile.name}
                      className="w-9 h-9 rounded-full object-cover border border-slate-700"
                    />
                    <div>
                      <div className="font-bold text-xs text-white group-hover:text-indigo-400 transition-colors">
                        {profile.name}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        Level {profile.level} • {profile.disciplineScore}% Discipline
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-indigo-400 transition-colors" />
                </button>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto w-full p-6 text-center text-xs text-slate-500 font-mono z-10">
        QUESTRA AI Trading Academy Simulator • Questra Paper Trading Platform
      </footer>
    </div>
  );
};
