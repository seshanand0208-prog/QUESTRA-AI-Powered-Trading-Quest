import React from 'react';
import { UserContext } from '../types';
import { QuestraLogo } from './QuestraLogo';
import { Flame, ShieldCheck, Award, Zap, BookOpen, LineChart, MessageSquare, BookMarked, Cpu, User, LogOut, LogIn, Heart, Layers, Sun, Moon } from 'lucide-react';

interface NavbarProps {
  user: UserContext;
  activeTab: 'terminal' | 'academy' | 'journal' | 'chat' | 'account';
  setActiveTab: (tab: 'terminal' | 'academy' | 'journal' | 'chat' | 'account') => void;
  hasApiKey: boolean;
  onLogout: () => void;
  onOpenAuthModal: () => void;
  onOpenBrokerSwitch?: () => void;
  theme?: 'dark' | 'light';
  onToggleTheme?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  activeTab,
  setActiveTab,
  hasApiKey,
  onLogout,
  onOpenAuthModal,
  onOpenBrokerSwitch,
  theme = 'dark',
  onToggleTheme,
}) => {
  const xpPercentage = Math.min(100, Math.round((user.xp / user.nextLevelXp) * 100));
  const currentBroker = user.preferredBroker || 'Zerodha Kite';

  return (
    <header className={`${theme === 'light' ? 'bg-slate-900 border-b border-slate-800 text-white shadow-md' : 'bg-slate-900 border-b border-slate-800 text-white shadow-lg'} sticky top-0 z-40 transition-colors duration-200`}>
      {/* Top Banner */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-4">
        {/* Brand & Broker Switcher */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setActiveTab('terminal')}>
            <QuestraLogo size="sm" showSubtitle={false} layout="horizontal" />
          </div>

          {/* Broker Badge Tag */}
          <button
            onClick={onOpenBrokerSwitch}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-slate-950 border border-slate-700 hover:border-indigo-400 rounded-xl text-xs font-mono font-bold text-slate-200 transition-all"
            title="Click to switch Indian Broker Platform mode"
          >
            <Layers className="w-3.5 h-3.5 text-indigo-400" />
            <span>{currentBroker} Mode</span>
          </button>
        </div>

        {/* User Stats & Profile Account Bar */}
        <div className="flex items-center gap-3 sm:gap-4 flex-wrap">
          <div className="flex items-center gap-3 sm:gap-4 bg-slate-950/80 px-3.5 py-1.5 rounded-xl border border-slate-800/80">
            {/* Hearts / Lives */}
            <div className="flex items-center gap-1.5" title="Hearts/Lives left for risk defense">
              <Heart className="w-4 h-4 text-rose-500 fill-rose-500 animate-pulse" />
              <span className="font-extrabold text-xs text-rose-400 font-mono">
                {user.hearts ?? 5}/5
              </span>
            </div>

            <div className="h-6 w-px bg-slate-800" />

            {/* Level & XP */}
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center font-bold text-xs text-indigo-300">
                L{user.level}
              </div>
              <div className="w-16 sm:w-20">
                <div className="flex justify-between text-[10px] font-medium text-slate-400 mb-0.5 font-mono">
                  <span>XP</span>
                  <span className="text-indigo-300">{user.xp}/{user.nextLevelXp}</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 transition-all duration-500"
                    style={{ width: `${xpPercentage}%` }}
                  />
                </div>
              </div>
            </div>

            <div className="h-6 w-px bg-slate-800 hidden sm:block" />

            {/* Discipline Score */}
            <div className="flex items-center gap-1.5" title="Discipline Score based on Stop Loss adherence and risk management">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <div className="text-xs">
                <span className="text-slate-400 hidden sm:inline">Discipline: </span>
                <span className="font-bold text-emerald-400 font-mono">{user.disciplineScore}%</span>
              </div>
            </div>

            <div className="h-6 w-px bg-slate-800 hidden sm:block" />

            {/* Streak */}
            <div className="flex items-center gap-1.5" title={`${user.streakDays} day active discipline streak`}>
              <Flame className="w-4 h-4 text-amber-500 fill-amber-500/20 animate-bounce" />
              <span className="font-bold text-xs text-amber-400 font-mono">{user.streakDays}d Streak</span>
            </div>
          </div>

          {/* Theme Toggle & Profile Widget */}
          <div className="flex items-center gap-2">
            {onToggleTheme && (
              <button
                onClick={onToggleTheme}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950/80 border border-slate-800 text-xs font-semibold text-slate-300 hover:text-white hover:border-indigo-500/50 transition-all"
                title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} Mode`}
              >
                {theme === 'dark' ? (
                  <>
                    <Sun className="w-3.5 h-3.5 text-amber-400" />
                    <span className="hidden sm:inline">Light Mode</span>
                  </>
                ) : (
                  <>
                    <Moon className="w-3.5 h-3.5 text-indigo-400" />
                    <span className="hidden sm:inline">Dark Mode</span>
                  </>
                )}
              </button>
            )}

            {/* Profile & Logout Action Widget */}
            {user.isLoggedIn ? (
              <div className="flex items-center gap-2 bg-slate-950/80 p-1.5 rounded-xl border border-slate-800">
                <button
                  onClick={() => setActiveTab('account')}
                  className={`flex items-center gap-2 px-2.5 py-1 rounded-lg transition-all ${
                    activeTab === 'account' ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40' : 'hover:bg-slate-800 text-slate-300'
                  }`}
                  title="View Account Dashboard & Settings"
                >
                  <img
                    src={user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200'}
                    alt={user.name}
                    className="w-6 h-6 rounded-full object-cover border border-indigo-400"
                  />
                  <span className="text-xs font-bold max-w-[100px] truncate hidden sm:inline">{user.name}</span>
                </button>

                <button
                  onClick={onLogout}
                  className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                  title="Log Out of QUESTRA"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenAuthModal}
                className="flex items-center gap-2 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md shadow-indigo-600/30 transition-all"
              >
                <LogIn className="w-4 h-4" />
                Sign In
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 border-t border-slate-800/60 overflow-x-auto no-scrollbar">
        <nav className="flex items-center gap-1 py-1.5 min-w-max">
          <button
            onClick={() => setActiveTab('terminal')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'terminal'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Zap className="w-4 h-4" />
            {currentBroker} Terminal
          </button>

          <button
            onClick={() => setActiveTab('academy')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'academy'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            Questra Skill Tree Path
          </button>

          <button
            onClick={() => setActiveTab('journal')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'journal'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <BookMarked className="w-4 h-4" />
            Trade Journal & Post-Mortem
          </button>

          <button
            onClick={() => setActiveTab('chat')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'chat'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            Pip 🐥 AI Assistant & Chatbot
          </button>

          <button
            onClick={() => setActiveTab('account')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'account'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <User className="w-4 h-4" />
            Account Dashboard
          </button>
        </nav>
      </div>
    </header>
  );
};


