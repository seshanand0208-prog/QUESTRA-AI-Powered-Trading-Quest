import React, { useState } from 'react';
import { DailyChallenge, Badge, UserContext } from '../types';
import {
  Shield,
  Zap,
  Award,
  Flame,
  CheckCircle2,
  Lock,
  Star,
  Cpu,
  Brain,
  TrendingUp,
  Target,
  ArrowRight,
  RefreshCw,
  Sparkles,
  Layers,
  Activity,
  Eye,
  Crown,
  BookOpen,
  DollarSign,
  ChevronRight,
  MessageSquareText,
  HelpCircle
} from 'lucide-react';

export interface StageNode {
  id: string;
  stageId: 1 | 2 | 3;
  levelCode: string; // "1.1", "1.2", "1.3", "BOSS"
  title: string;
  shortDesc: string;
  xpReward: number;
  isBoss: boolean;
  scenario: {
    title: string;
    description: string;
    tickerSymbol?: string;
    chartContext?: string;
    options: string[];
    correctOptionIndex: number;
    quickViewpoints: string[];
  };
}

export interface StageInfo {
  id: 1 | 2 | 3;
  title: string;
  subTitle: string;
  description: string;
  badgeName: string;
  colorTheme: {
    headerBg: string;
    accentBg: string;
    badgeText: string;
    border: string;
    buttonBg: string;
    nodeActive: string;
  };
  nodes: StageNode[];
}

const STAGES_DATA: StageInfo[] = [
  {
    id: 1,
    title: 'STAGE 1: Novice Trader',
    subTitle: 'Market Fundamentals & Risk Protection',
    description: 'Master capital preservation, position sizing, and the non-negotiable 1% risk rule before touching live markets.',
    badgeName: 'Risk Guardian',
    colorTheme: {
      headerBg: 'from-emerald-600 via-teal-600 to-cyan-700',
      accentBg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      badgeText: 'text-emerald-600',
      border: 'border-emerald-200',
      buttonBg: 'bg-emerald-600 hover:bg-emerald-500',
      nodeActive: 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30 ring-4 ring-emerald-200'
    },
    nodes: [
      {
        id: 'node_1_1',
        stageId: 1,
        levelCode: '1.1',
        title: 'Capital Preservation & Market Basics',
        shortDesc: 'Understand why survival is the #1 rule in trading.',
        xpReward: 100,
        isBoss: false,
        scenario: {
          title: 'The High Volatility Breakout Dilemma',
          description: 'You start with a ₹10,000 account. RELIANCE surges +2.5% in 5 minutes with breaking market headlines. You feel an urgent urge to throw ₹5,000 into the trade without defining a stop loss. How do you respond?',
          tickerSymbol: 'RELIANCE',
          chartContext: 'RSI at 85 (Overbought), Price 4 ATRs above 20 EMA',
          options: [
            'Market order ₹5,000 immediately to catch the remaining pump.',
            'Step back, identify key support levels, and calculate maximum 1% risk (₹100) before placing any order.',
            'Use 20x leverage to double account size on the next candle.',
            'Panic sell all existing assets and wait 1 month.'
          ],
          correctOptionIndex: 1,
          quickViewpoints: [
            'I should wait for a pullback to support with a strict ₹100 stop loss.',
            'Chasing extended green candles usually leads to buying the exact top.',
            'Risking ₹5,000 on one trade violates risk management rules.'
          ]
        }
      },
      {
        id: 'node_1_2',
        stageId: 1,
        levelCode: '1.2',
        title: 'The Golden 1% Account Risk Rule',
        shortDesc: 'Calculate exact position size based on dollar risk.',
        xpReward: 150,
        isBoss: false,
        scenario: {
          title: 'Calculating Position Size for TATAMOTORS',
          description: 'Your total account balance is ₹10,000. Under the 1% risk defense rule, your maximum allowed loss on a single trade is ₹100. You plan to enter TATAMOTORS at ₹1,000.00 with a Stop Loss placed at ₹995.00 (Risk per share = ₹5.00). How many shares should you purchase?',
          tickerSymbol: 'TATAMOTORS',
          chartContext: 'Entry: ₹1,000.00 | Stop Loss: ₹995.00 | Risk/share: ₹5.00',
          options: [
            '200 shares (₹1,000 risk if stopped out)',
            '20 shares (₹100 max risk if stopped out)',
            '50 shares (₹250 risk if stopped out)',
            '100 shares (₹500 risk if stopped out)'
          ],
          correctOptionIndex: 1,
          quickViewpoints: [
            '20 shares x ₹5 risk/share = exactly ₹100 max risk (1% of ₹10,000).',
            'Position size must always adapt to the distance to the stop loss.',
            'Higher shares mean taking unapproved risk beyond 1%.'
          ]
        }
      },
      {
        id: 'node_1_3',
        stageId: 1,
        levelCode: '1.3',
        title: 'Stop Losses & 1:2 Risk-to-Reward Ratio',
        shortDesc: 'Ensure every winning trade pays at least double your risk.',
        xpReward: 150,
        isBoss: false,
        scenario: {
          title: 'Designing a 1:2 R:R Trade Setup on INFY',
          description: 'You spot a bullish consolidation breakout on INFY at ₹1,800.00. You place your Stop Loss at ₹1,780.00 (₹20.00 risk per share). To satisfy a disciplined 1:2 Risk-to-Reward ratio, where should your target take-profit exit price be set?',
          tickerSymbol: 'INFY',
          chartContext: 'Entry: ₹1,800.00 | Stop Loss: ₹1,780.00 (Risk: ₹20.00)',
          options: [
            '₹1,810.00 (Risk-to-Reward = 1 : 0.5)',
            '₹1,820.00 (Risk-to-Reward = 1 : 1.0)',
            '₹1,840.00 (Risk-to-Reward = 1 : 2.0)',
            '₹1,900.00 (Risk-to-Reward = 1 : 5.0)'
          ],
          correctOptionIndex: 2,
          quickViewpoints: [
            'With a ₹20 risk, a 1:2 R:R requires a ₹40 gain, targeting ₹1,840.00.',
            'Maintaining 1:2 R:R allows profitability even with a 40% win rate.',
            'Taking targets at ₹1,810 leads to negative mathematical expectancy.'
          ]
        }
      },
      {
        id: 'node_1_4_boss',
        stageId: 1,
        levelCode: 'BOSS 1',
        title: "Questra Risk Defense Checkpoint Exam",
        shortDesc: 'Prove your mastery of position sizing & risk discipline.',
        xpReward: 250,
        isBoss: true,
        scenario: {
          title: 'The Revenge Trading Spiral Challenge',
          description: 'A trader suffers 3 losing trades in a row (-₹300 total) and feels intensely frustrated. They want to open a ₹1,000 trade on HDFCBANK with 10x leverage without a stop loss to "get their money back immediately". How does Questra evaluate this mindset and what is the required action?',
          tickerSymbol: 'HDFCBANK',
          chartContext: 'Account drawdown: ₹300 | Emotional state: Angry / Revenge Mode',
          options: [
            'Approve the 10x leverage trade to recover losses fast.',
            'Flag Emotional Bias: REVENGE_TRADING. Halt trading for 15 minutes, step away from screens, and enforce mandatory Stop Loss on next trade.',
            'Double the position size again if price drops.',
            'Close account permanently.'
          ],
          correctOptionIndex: 1,
          quickViewpoints: [
            'Revenge trading with 10x leverage is the fastest way to blow up an account.',
            'Emotional state after losses requires a cooling-off period.',
            'Discipline means accepting losses as cost of doing business.'
          ]
        }
      }
    ]
  },
  {
    id: 2,
    title: 'STAGE 2: Technical Chartist',
    subTitle: 'Chart Patterns, Indicators & Price Action',
    description: 'Learn to read candlestick signals, support/resistance breakouts, and RSI divergence using multimodal chart vision.',
    badgeName: 'Chart Wizard',
    colorTheme: {
      headerBg: 'from-indigo-600 via-purple-600 to-violet-700',
      accentBg: 'bg-indigo-50 text-indigo-800 border-indigo-200',
      badgeText: 'text-indigo-600',
      border: 'border-indigo-200',
      buttonBg: 'bg-indigo-600 hover:bg-indigo-500',
      nodeActive: 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 ring-4 ring-indigo-200'
    },
    nodes: [
      {
        id: 'node_2_1',
        stageId: 2,
        levelCode: '2.1',
        title: 'Candlestick Patterns & Bullish Engulfing',
        shortDesc: 'Identify high-probability reversal candle patterns.',
        xpReward: 150,
        isBoss: false,
        scenario: {
          title: 'Spotting a Bullish Engulfing Reversal on ICICIBANK',
          description: 'ICICIBANK drops to a major 200-day moving average support zone at ₹1,200.00. A large green candle forms on 2.5x average volume, completely engulfing the body of the previous red candle. Where should you place your entry and stop loss?',
          tickerSymbol: 'ICICIBANK',
          chartContext: 'Pattern: Bullish Engulfing at 200 SMA Support (₹1,200.00)',
          options: [
            'Enter near ₹1,215.00 with Stop Loss just below the pattern low at ₹1,195.00.',
            'Sell short immediately expecting further decline.',
            'Buy with no stop loss because engulfing patterns never fail.',
            'Wait until price reaches ₹1,500 before looking at chart.'
          ],
          correctOptionIndex: 0,
          quickViewpoints: [
            'Bullish Engulfing on heavy volume at major support confirms buyers taking control.',
            'Placing stop loss below the pattern wick protects against false breakouts.',
            'Always wait for candle closure before confirming the pattern.'
          ]
        }
      },
      {
        id: 'node_2_2',
        stageId: 2,
        levelCode: '2.2',
        title: 'Support & Resistance Breakouts',
        shortDesc: 'Trade volume-confirmed breakouts without getting trapped.',
        xpReward: 200,
        isBoss: false,
        scenario: {
          title: 'NIFTY 50 ₹24,800 Major Resistance Breakout',
          description: 'NIFTY 50 has bounced off ₹24,800 resistance 4 times over the past week. On the 5th attempt, green volume surges 3x higher and price breaks through ₹24,850. How do professional traders enter this setup safely?',
          tickerSymbol: 'NIFTY50',
          chartContext: '4x Resistance retests at ₹24,800 | Volume Surge 3x',
          options: [
            'Enter on the breakout confirmation or on a clean retest of ₹24,800 as new support, with Stop Loss below ₹24,700.',
            'Short the market with 50x leverage.',
            'Market buy immediately and remove all stop losses.',
            'Do nothing and assume NIFTY 50 is going to zero.'
          ],
          correctOptionIndex: 0,
          quickViewpoints: [
            'Breakouts confirmed by high volume have high probability of follow-through.',
            'Entering on the pullback retest of ₹24,800 offers an optimal R:R entry.',
            'Proper stop loss below ₹24,700 defends against fakeout traps.'
          ]
        }
      },
      {
        id: 'node_2_3',
        stageId: 2,
        levelCode: '2.3',
        title: 'RSI Divergence & Momentum Signals',
        shortDesc: 'Detect hidden trend exhaustion before the crowd.',
        xpReward: 200,
        isBoss: false,
        scenario: {
          title: 'Bearish RSI Divergence Warning on TCS',
          description: 'TCS pushes to a new all-time high price of ₹4,180.00, but the 14-period Relative Strength Index (RSI) makes a distinctly lower peak (dropping from 76 down to 58). What does this Bearish RSI Divergence signal?',
          tickerSymbol: 'TCS',
          chartContext: 'Price: Higher High (₹4,180) | RSI: Lower High (76 -> 58)',
          options: [
            'Underlying buying momentum is weakening; prepare for a potential pullback or tightening stop loss.',
            'Massive buy signal to go 100% long.',
            'RSI is broken and irrelevant.',
            'Sell all assets and delete trading app.'
          ],
          correctOptionIndex: 0,
          quickViewpoints: [
            'Bearish RSI divergence signals institutional momentum drying up.',
            'Traders should tighten stop losses and avoid opening new aggressive long orders.',
            'Divergence often precedes major trend pullbacks.'
          ]
        }
      },
      {
        id: 'node_2_4_boss',
        stageId: 2,
        levelCode: 'BOSS 2',
        title: "Questra Multimodal Chart Diagnostic Challenge",
        shortDesc: 'Run a full AI Chart scan for support, resistance & trade plan.',
        xpReward: 300,
        isBoss: true,
        scenario: {
          title: 'Full Multimodal Technical Analysis Exam',
          description: 'You are presented with a chart showing a Double Bottom pattern on RELIANCE at ₹2,920 support with RSI MACD crossover. Explain your complete trade execution plan: Entry price, Stop Loss location, Take-Profit target, and R:R ratio.',
          tickerSymbol: 'RELIANCE',
          chartContext: 'Pattern: Double Bottom | RSI: 42 -> 58 Crossover | MACD: Bullish',
          options: [
            'Entry at ₹2,980.00, Stop Loss at ₹2,920.00 (Risk: ₹60.00), Target at ₹3,100.00 (Reward: ₹120.00), R:R = 1 : 2.0.',
            'Entry with no stop loss and leverage 20x.',
            'Wait until price drops to ₹500.',
            'Market order ₹10,000 without looking at support levels.'
          ],
          correctOptionIndex: 0,
          quickViewpoints: [
            'Double Bottom pattern confirmed by MACD crossover gives strong edge.',
            'Risk of ₹60 mapped to ₹120 target fulfills 1:2 R:R discipline.',
            'Questra AI Vision provides automated confidence scores.'
          ]
        }
      }
    ]
  },
  {
    id: 3,
    title: 'STAGE 3: Master Strategist',
    subTitle: 'Trader Psychology, Order Types & Portfolio Mastery',
    description: 'Eliminate emotional biases (FOMO, revenge trading), master advanced order types, and build a sustainable long-term edge.',
    badgeName: 'Master Trader',
    colorTheme: {
      headerBg: 'from-amber-600 via-orange-600 to-yellow-600',
      accentBg: 'bg-amber-50 text-amber-900 border-amber-200',
      badgeText: 'text-amber-600',
      border: 'border-amber-200',
      buttonBg: 'bg-amber-600 hover:bg-amber-500',
      nodeActive: 'bg-amber-500 text-white shadow-lg shadow-amber-500/30 ring-4 ring-amber-200'
    },
    nodes: [
      {
        id: 'node_3_1',
        stageId: 3,
        levelCode: '3.1',
        title: 'Conquering FOMO & Behavioral Biases',
        shortDesc: 'Master the psychological mindset of elite traders.',
        xpReward: 200,
        isBoss: false,
        scenario: {
          title: 'Overcoming Fear Of Missing Out (FOMO)',
          description: 'You stepped away from your desk and missed TATAMOTORS surging +8%. You feel severe regret and urge to buy immediately at the high without a setup. How do you master this psychological moment?',
          tickerSymbol: 'TATAMOTORS',
          chartContext: 'Price: +8% Extended | Trader Mindset: Regret / FOMO',
          options: [
            'Acknowledge the missed trade is in the past, record the observation in journal, and wait patiently for the next high-probability setup.',
            'Market buy with 5x leverage to catch whatever remains.',
            'Short the stock aggressively out of anger.',
            'Blame the market for bad luck.'
          ],
          correctOptionIndex: 0,
          quickViewpoints: [
            'There are thousands of high-probability setups every year; missing one is normal.',
            'Chasing out of regret violates disciplined trading rules.',
            'Master traders remain calm and detached from individual trade outcomes.'
          ]
        }
      },
      {
        id: 'node_3_2',
        stageId: 3,
        levelCode: '3.2',
        title: 'Order Types & Leverage Safety',
        shortDesc: 'Understand Limit vs Market orders & spread slippage.',
        xpReward: 200,
        isBoss: false,
        scenario: {
          title: 'Executing Orders During Volatile Earnings Releases',
          description: 'Why do disciplined institutional traders use Limit Orders instead of Market Orders when trading BHARTIARTL near high-volatility events like earnings reports?',
          tickerSymbol: 'BHARTIARTL',
          chartContext: 'Event: Earnings Release | Volatility: High Spread Slippage',
          options: [
            'Limit orders specify the maximum entry price, preventing bad fills caused by wide bid-ask slippage.',
            'Market orders always guarantee cheap prices.',
            'Limit orders double trading profits automatically.',
            'Order types make no difference.'
          ],
          correctOptionIndex: 0,
          quickViewpoints: [
            'Market orders during earnings can execute dollars away from intended price due to slippage.',
            'Limit orders ensure you enter only at price levels that preserve your R:R model.',
            'Controlling execution quality is part of risk management.'
          ]
        }
      },
      {
        id: 'node_3_3',
        stageId: 3,
        levelCode: '3.3',
        title: 'Post-Mortem Reflection & Continuous Growth',
        shortDesc: 'Audit every closed trade to uncover hidden behavioral habits.',
        xpReward: 250,
        isBoss: false,
        scenario: {
          title: 'The AI Post-Mortem Audit Routine',
          description: 'Why is conducting an AI Post-Mortem review after every trade (wins AND losses) essential for long-term consistency?',
          tickerSymbol: 'LT',
          chartContext: 'Activity: Post-Trade Reflection & Journaling',
          options: [
            'It exposes recurring emotional mistakes (e.g. moving stop loss, premature exit) and reinforces good execution habits.',
            'It automatically refunds lost money.',
            'It guarantees a 100% win rate forever.',
            'It is just for show.'
          ],
          correctOptionIndex: 0,
          quickViewpoints: [
            'Journaling builds self-awareness around emotional triggers.',
            'Analyzing winning trades ensures profits weren\'t just lucky gambles.',
            'Continuous post-mortems elevate discipline scores.'
          ]
        }
      },
      {
        id: 'node_3_4_boss',
        stageId: 3,
        levelCode: 'BOSS 3',
        title: 'Master Trader Graduation & Certification',
        shortDesc: 'Final Boss Challenge: Complete full trading strategy synthesis.',
        xpReward: 500,
        isBoss: true,
        scenario: {
          title: 'Master Trader Comprehensive Certification Exam',
          description: 'You manage a ₹20,000 account. Construct your master trading plan: 1% Max Risk (₹200), Pattern Confirmation (Bullish Engulfing / Breakout + Volume), Minimum 1:2 R:R Ratio, Limit Order execution, and Post-Mortem Journaling. Confirm your strategy to graduate!',
          tickerSymbol: 'ALL_MARKETS',
          chartContext: 'FINAL GRADUATION EXAM | Master Trader Certification',
          options: [
            'Enforce 1% Risk (₹200 max), 1:2 R:R minimum target, pattern confirmation on charts, limit orders, and AI post-mortem logging on every trade.',
            'Abandon rules and trade on gut feeling.',
            'Use 100x leverage on crypto coins.',
            'Never place a stop loss.'
          ],
          correctOptionIndex: 0,
          quickViewpoints: [
            'Mastery is the synthesis of strict risk rules, technical vision, and emotional control.',
            'Consistency over 100 trades matters far more than any single trade outcome.',
            'Congratulations on reaching Master Trader status!'
          ]
        }
      }
    ]
  }
];

interface AcademyViewProps {
  user: UserContext;
  challenges: DailyChallenge[];
  badges: Badge[];
  onCompleteQuiz: (xpGained: number) => void;
  onClaimChallenge: (challengeId: string, xpReward: number) => void;
}

export const AcademyView: React.FC<AcademyViewProps> = ({
  user,
  challenges,
  badges,
  onCompleteQuiz,
  onClaimChallenge,
}) => {
  const [activeStageId, setActiveStageId] = useState<1 | 2 | 3>((user.unlockedStage as 1 | 2 | 3) || 1);
  const [selectedNode, setSelectedNode] = useState<StageNode | null>(null);

  // Gemma AI Trainer Modal State
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [userViewpointText, setUserViewpointText] = useState<string>('');
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [evaluationResult, setEvaluationResult] = useState<{
    reasoningSteps: string;
    understandingAnalysis: string;
    gemmaCoaching: string;
    score: number;
    passed: boolean;
    xpAwarded: number;
    starsEarned: number;
    keyTakeaways: string[];
  } | null>(null);

  // Level Completion Announcement Modal State
  const [levelAnnouncement, setLevelAnnouncement] = useState<{
    nodeTitle: string;
    stageId: number;
    levelCode: string;
    xpAwarded: number;
    score: number;
    isBoss: boolean;
  } | null>(null);

  // User progression states
  const [completedNodeIds, setCompletedNodeIds] = useState<string[]>(
    user.completedNodes || ['node_1_1']
  );

  const handleNodeClick = (node: StageNode) => {
    // Check if node is accessible
    const isUnlocked = isNodeUnlocked(node);
    if (!isUnlocked) return;

    setSelectedNode(node);
    setSelectedOption(null);
    setUserViewpointText('');
    setEvaluationResult(null);
  };

  const isNodeUnlocked = (node: StageNode) => {
    if (node.id === 'node_1_1') return true;
    
    // Node is unlocked if previous node in the sequence is completed
    const allNodesInOrder = STAGES_DATA.flatMap((s) => s.nodes);
    const index = allNodesInOrder.findIndex((n) => n.id === node.id);
    if (index === 0) return true;
    const prevNode = allNodesInOrder[index - 1];
    return completedNodeIds.includes(prevNode.id);
  };

  const handleRunAiEvaluation = async () => {
    if (!selectedNode) return;
    setIsEvaluating(true);

    try {
      const response = await fetch('/api/gemma/trainer-node', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          stageId: selectedNode.stageId,
          nodeTitle: selectedNode.title,
          scenarioContext: `${selectedNode.scenario.title}: ${selectedNode.scenario.description}`,
          selectedOption: selectedOption !== null ? selectedNode.scenario.options[selectedOption] : '',
          userViewpoint: userViewpointText,
          userContext: user
        })
      });

      const data = await response.json();
      setEvaluationResult(data);

      if (data.passed) {
        if (!completedNodeIds.includes(selectedNode.id)) {
          setCompletedNodeIds((prev) => [...prev, selectedNode.id]);
        }
        onCompleteQuiz(data.xpAwarded || selectedNode.xpReward);

        // Trigger Level Completion Announcement Popup
        setLevelAnnouncement({
          nodeTitle: selectedNode.title,
          stageId: selectedNode.stageId,
          levelCode: selectedNode.levelCode,
          xpAwarded: data.xpAwarded || selectedNode.xpReward,
          score: data.score || 95,
          isBoss: selectedNode.isBoss,
        });

        // If boss node passed, unlock next stage
        if (selectedNode.isBoss && selectedNode.stageId < 3) {
          const nextStage = (selectedNode.stageId + 1) as 1 | 2 | 3;
          setActiveStageId(nextStage);
        }
      }
    } catch (err) {
      console.error('Error running Gemma trainer node evaluation:', err);
      // Fallback evaluation
      const fallbackResult = {
        reasoningSteps: `<|think|>\n- Analyzed user response for ${selectedNode.title}\n- User view: "${userViewpointText || 'Selected correct option'}"\n</|think|>`,
        understandingAnalysis: `Your viewpoint shows good risk discipline and understanding of market context!`,
        gemmaCoaching: `In this level, maintaining position size discipline and setting a strict stop loss is the foundation of long-term consistency. Always calculate your exact risk before clicking buy.`,
        score: 90,
        passed: true,
        xpAwarded: selectedNode.xpReward,
        starsEarned: 3,
        keyTakeaways: [
          'Stick to calculated position sizes',
          'Honor your stop loss without hesitation',
          'Log your trade execution in your journal'
        ]
      };
      setEvaluationResult(fallbackResult);
      if (!completedNodeIds.includes(selectedNode.id)) {
        setCompletedNodeIds((prev) => [...prev, selectedNode.id]);
      }
      onCompleteQuiz(selectedNode.xpReward);
    } finally {
      setIsEvaluating(false);
    }
  };

  const currentStageInfo = STAGES_DATA.find((s) => s.id === activeStageId) || STAGES_DATA[0];
  const stageCompletedCount = currentStageInfo.nodes.filter((n) => completedNodeIds.includes(n.id)).length;
  const stageProgressPercent = Math.round((stageCompletedCount / currentStageInfo.nodes.length) * 100);

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-8 text-slate-900">
      {/* Top Duolingo Header Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 flex flex-wrap items-center justify-between gap-6 shadow-sm">
        <div className="space-y-1.5 max-w-2xl">
          <div className="flex items-center gap-2 text-indigo-600 text-xs font-mono font-bold uppercase tracking-wider">
            <Cpu className="w-4 h-4 text-emerald-600 animate-pulse" />
            <span>Questra Interactive AI Trainer</span>
          </div>
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
            3-Stage Gamified Trading Roadmap
          </h2>
          <p className="text-sm text-slate-600">
            Cross levels, complete scenario challenges, and let Questra AI evaluate your viewpoint to build elite trading discipline.
          </p>
        </div>

        {/* Stage Progress Summary Badge */}
        <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 border border-indigo-200 flex items-center justify-center font-bold text-indigo-700">
              S{activeStageId}
            </div>
            <div>
              <div className="text-xs text-slate-500 font-medium">Stage {activeStageId} Progress</div>
              <div className="text-sm font-bold text-slate-900 font-mono">
                {stageCompletedCount} / {currentStageInfo.nodes.length} Levels ({stageProgressPercent}%)
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stage Tabs Navigation */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {STAGES_DATA.map((stg) => {
          const isUnlocked = stg.id === 1 || completedNodeIds.includes(`node_${stg.id - 1}_4_boss`);
          const isCompleted = stg.nodes.every((n) => completedNodeIds.includes(n.id));
          const isActive = activeStageId === stg.id;

          return (
            <button
              key={stg.id}
              onClick={() => isUnlocked && setActiveStageId(stg.id)}
              className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden ${
                isActive
                  ? `bg-white border-indigo-500 shadow-md ring-2 ring-indigo-200`
                  : isUnlocked
                  ? `bg-white border-slate-200 hover:border-slate-300 shadow-sm`
                  : `bg-slate-100 border-slate-200 opacity-60 cursor-not-allowed`
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className={`text-[11px] font-mono font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${stg.colorTheme.accentBg}`}>
                  Stage {stg.id}
                </span>

                {isCompleted ? (
                  <span className="flex items-center gap-1 text-xs font-bold text-emerald-600">
                    <CheckCircle2 className="w-4 h-4" /> Cleared
                  </span>
                ) : !isUnlocked ? (
                  <span className="flex items-center gap-1 text-xs font-semibold text-slate-400">
                    <Lock className="w-3.5 h-3.5" /> Locked
                  </span>
                ) : (
                  <span className="text-xs font-bold text-indigo-600">Active</span>
                )}
              </div>

              <div className="font-bold text-sm text-slate-900">{stg.title.replace(`STAGE ${stg.id}: `, '')}</div>
              <div className="text-xs text-slate-500 line-clamp-1">{stg.subTitle}</div>
            </button>
          );
        })}
      </div>

      {/* Main Roadmap Path & Sidebar Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left 8 cols: Duolingo Winding Roadmap Path */}
        <div className="lg:col-span-8 space-y-6">
          {/* Active Stage Hero Card */}
          <div className={`p-6 rounded-2xl bg-gradient-to-r ${currentStageInfo.colorTheme.headerBg} text-white shadow-md relative overflow-hidden`}>
            <div className="relative z-10 space-y-2 max-w-xl">
              <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-indigo-100 font-bold">
                <Crown className="w-4 h-4 text-amber-300" />
                <span>Level Roadmap - Stage {currentStageInfo.id}</span>
              </div>
              <h3 className="text-2xl font-extrabold">{currentStageInfo.title}</h3>
              <p className="text-xs text-indigo-100 leading-relaxed">
                {currentStageInfo.description}
              </p>

              <div className="pt-2 flex items-center gap-3 text-xs font-mono">
                <span className="bg-white/20 px-3 py-1 rounded-lg backdrop-blur-sm font-bold">
                  Reward Badge: {currentStageInfo.badgeName} 🏅
                </span>
              </div>
            </div>
          </div>

          {/* Duolingo Winding Roadmap Level Nodes */}
          <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden">
            <div className="text-center mb-8">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                Tap a level node to begin Questra AI Interactive Training
              </span>
            </div>

            <div className="flex flex-col items-center space-y-12 relative max-w-md mx-auto">
              {currentStageInfo.nodes.map((node, idx) => {
                const isPassed = completedNodeIds.includes(node.id);
                const unlocked = isNodeUnlocked(node);

                // Alternating zigzag position for Duolingo roadmap feel
                const aligns = ['self-center', 'self-end pr-8', 'self-center', 'self-start pl-8'];
                const alignmentClass = aligns[idx % aligns.length];

                return (
                  <div key={node.id} className={`flex flex-col items-center relative ${alignmentClass}`}>
                    {/* Connecting line to previous node */}
                    {idx > 0 && (
                      <div
                        className={`absolute -top-12 left-1/2 -translate-x-1/2 w-1.5 h-12 border-l-2 border-dashed ${
                          isPassed ? 'border-emerald-500' : 'border-slate-300'
                        }`}
                      />
                    )}

                    {/* Level Button Node */}
                    <button
                      onClick={() => handleNodeClick(node)}
                      disabled={!unlocked}
                      className={`group relative flex items-center justify-center w-20 h-20 rounded-full transition-all duration-300 ${
                        isPassed
                          ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30 hover:scale-105 ring-4 ring-emerald-100'
                          : unlocked
                          ? `${currentStageInfo.colorTheme.nodeActive} hover:scale-105 animate-bounce`
                          : 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
                      }`}
                    >
                      {/* Inner Icon */}
                      <div className="flex flex-col items-center justify-center">
                        {isPassed ? (
                          <CheckCircle2 className="w-8 h-8" />
                        ) : !unlocked ? (
                          <Lock className="w-6 h-6 text-slate-400" />
                        ) : node.isBoss ? (
                          <Crown className="w-8 h-8 text-amber-300 animate-pulse" />
                        ) : (
                          <Zap className="w-7 h-7" />
                        )}
                        <span className="text-[10px] font-mono font-bold mt-0.5">
                          {node.levelCode}
                        </span>
                      </div>

                      {/* Stars badge for passed node */}
                      {isPassed && (
                        <div className="absolute -top-2 flex gap-0.5 bg-amber-400 text-slate-900 px-2 py-0.5 rounded-full text-[10px] font-bold shadow-sm">
                          <Star className="w-3 h-3 fill-slate-900" />
                          <Star className="w-3 h-3 fill-slate-900" />
                          <Star className="w-3 h-3 fill-slate-900" />
                        </div>
                      )}
                    </button>

                    {/* Level Title Label */}
                    <div className="mt-3 text-center max-w-[180px]">
                      <div className={`text-xs font-bold ${unlocked ? 'text-slate-900' : 'text-slate-400'}`}>
                        {node.title}
                      </div>
                      <div className="text-[10px] text-slate-500 line-clamp-1">{node.shortDesc}</div>
                      <div className="text-[10px] font-mono font-bold text-amber-600 mt-0.5">
                        +{node.xpReward} XP
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right 4 cols: Daily Quests & Unlocked Badges */}
        <div className="lg:col-span-4 space-y-6">
          {/* Daily Quests */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center justify-between">
              <span>Daily Discipline Quests</span>
              <Award className="w-4 h-4 text-amber-500" />
            </h3>

            <div className="space-y-3">
              {challenges.map((c) => (
                <div key={c.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="text-xs font-bold text-slate-900">{c.title}</div>
                      <div className="text-[11px] text-slate-500">{c.description}</div>
                    </div>
                    <span className="text-[11px] font-mono font-bold text-amber-600">+{c.xpReward} XP</span>
                  </div>

                  <div className="flex items-center justify-between gap-3 text-xs">
                    <div className="flex-1 bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-amber-500 h-full transition-all duration-300"
                        style={{ width: `${Math.min(100, (c.progress / c.target) * 100)}%` }}
                      />
                    </div>
                    <span className="font-mono text-[11px] text-slate-500">
                      {c.progress}/{c.target}
                    </span>
                  </div>

                  {c.progress >= c.target && !c.completed && (
                    <button
                      onClick={() => onClaimChallenge(c.id, c.xpReward)}
                      className="w-full mt-2 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white transition-all"
                    >
                      Claim Reward (+{c.xpReward} XP)
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Badges Showcase */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center justify-between">
              <span>Discipline Badges</span>
              <Shield className="w-4 h-4 text-indigo-600" />
            </h3>

            <div className="grid grid-cols-2 gap-3">
              {badges.map((b) => (
                <div
                  key={b.id}
                  className={`p-3 rounded-xl border flex flex-col items-center text-center space-y-1.5 transition-all ${
                    b.unlocked
                      ? 'bg-indigo-50/60 border-indigo-200 text-indigo-900'
                      : 'bg-slate-50 border-slate-200 opacity-50 grayscale'
                  }`}
                >
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    b.unlocked ? 'bg-indigo-100 border border-indigo-300' : 'bg-slate-200'
                  }`}>
                    <Award className="w-5 h-5 text-indigo-600" />
                  </div>
                  <div className="text-xs font-bold text-slate-900 leading-tight">{b.title}</div>
                  <div className="text-[10px] text-slate-500 line-clamp-2">{b.description}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Gemma AI Trainer Interactive Modal */}
      {selectedNode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-3xl w-full overflow-hidden shadow-2xl text-slate-900 flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="bg-slate-900 px-6 py-4 border-b border-slate-800 flex items-center justify-between text-white shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center">
                  <Cpu className="w-5 h-5 text-emerald-400 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-emerald-400 uppercase">
                      Stage {selectedNode.stageId} • Level {selectedNode.levelCode}
                    </span>
                    {selectedNode.isBoss && (
                      <span className="text-[10px] uppercase font-bold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-500/30">
                        Boss Exam
                      </span>
                    )}
                  </div>
                  <h3 className="font-bold text-lg text-white">{selectedNode.title}</h3>
                </div>
              </div>

              <button
                onClick={() => setSelectedNode(null)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                ✕
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              {/* Scenario Context Box */}
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-indigo-700 uppercase tracking-wider flex items-center gap-1.5">
                    <HelpCircle className="w-4 h-4 text-indigo-600" />
                    <span>Real-World Market Dilemma</span>
                  </div>
                  {selectedNode.scenario.tickerSymbol && (
                    <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-md bg-slate-200 text-slate-800">
                      {selectedNode.scenario.tickerSymbol}
                    </span>
                  )}
                </div>

                <h4 className="text-base font-bold text-slate-900">
                  {selectedNode.scenario.title}
                </h4>

                <p className="text-sm text-slate-700 leading-relaxed">
                  {selectedNode.scenario.description}
                </p>

                {selectedNode.scenario.chartContext && (
                  <div className="text-xs font-mono text-slate-600 bg-white p-2.5 rounded-lg border border-slate-200">
                    💡 <span className="font-semibold text-slate-800">Chart Context:</span> {selectedNode.scenario.chartContext}
                  </div>
                )}
              </div>

              {/* Multiple Choice Options */}
              <div className="space-y-3">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Step 1: Select Your Decision
                </label>

                <div className="space-y-2">
                  {selectedNode.scenario.options.map((opt, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedOption(idx)}
                      className={`w-full text-left p-3.5 rounded-xl text-xs font-medium border transition-all ${
                        selectedOption === idx
                          ? 'bg-indigo-600 border-indigo-600 text-white font-bold shadow-sm'
                          : 'bg-white border-slate-200 text-slate-800 hover:border-indigo-300'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Viewpoint Input */}
              <div className="space-y-3">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center justify-between">
                  <span>Step 2: Explain Your Viewpoint to Questra AI (Optional)</span>
                  <MessageSquareText className="w-4 h-4 text-indigo-600" />
                </label>

                <textarea
                  value={userViewpointText}
                  onChange={(e) => setUserViewpointText(e.target.value)}
                  placeholder="Explain why you chose this option or share your personal trading viewpoint (e.g., 'I want to avoid FOMO because last week I lost money chasing extended green candles...')"
                  rows={3}
                  className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-indigo-500 placeholder:text-slate-400"
                />

                {/* Quick Viewpoint Buttons */}
                <div className="flex flex-wrap gap-2">
                  <span className="text-[11px] text-slate-400 self-center">Quick Viewpoints:</span>
                  {selectedNode.scenario.quickViewpoints.map((qv, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setUserViewpointText(qv)}
                      className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200 text-slate-700 hover:bg-slate-200 transition-all text-left line-clamp-1"
                    >
                      💡 {qv}
                    </button>
                  ))}
                </div>
              </div>

              {/* Action Button */}
              {!evaluationResult && (
                <button
                  disabled={selectedOption === null || isEvaluating}
                  onClick={handleRunAiEvaluation}
                  className="w-full py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-xs font-bold uppercase tracking-wider text-white shadow-md transition-all flex items-center justify-center gap-2"
                >
                  {isEvaluating ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Questra AI is analyzing your viewpoint...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Submit Viewpoint to Questra AI Trainer</span>
                    </>
                  )}
                </button>
              )}

              {/* Questra Evaluation Results Display */}
              {evaluationResult && (
                <div className="space-y-5 border-t border-slate-200 pt-5">
                  {/* Internal <|think|> Chain-of-Thought */}
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-slate-300 font-mono text-[11px] space-y-1.5">
                    <div className="flex items-center gap-2 text-indigo-400 font-bold uppercase">
                      <Cpu className="w-4 h-4 text-emerald-400" />
                      <span>Questra Reasoning Chain</span>
                    </div>
                    <pre className="whitespace-pre-wrap leading-relaxed text-slate-400">
                      {evaluationResult.reasoningSteps}
                    </pre>
                  </div>

                  {/* Understanding User Viewpoint Breakdown */}
                  <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-200 space-y-2">
                    <div className="text-xs font-bold text-indigo-900 uppercase tracking-wider flex items-center gap-2">
                      <Brain className="w-4 h-4 text-indigo-700" />
                      <span>Questra's Assessment of Your Viewpoint</span>
                    </div>
                    <p className="text-xs text-slate-800 leading-relaxed">
                      {evaluationResult.understandingAnalysis}
                    </p>
                  </div>

                  {/* Gemma Core Teaching */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                    <div className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-emerald-600" />
                      <span>Stage Lesson & Trading Rule</span>
                    </div>
                    <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">
                      {evaluationResult.gemmaCoaching}
                    </p>

                    <div className="pt-2">
                      <div className="text-[11px] font-bold text-emerald-700 uppercase mb-1">Key Takeaways:</div>
                      <ul className="space-y-1">
                        {evaluationResult.keyTakeaways.map((kt, i) => (
                          <li key={i} className="flex items-center gap-2 text-xs text-slate-700">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>{kt}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Score & XP Banner */}
                  <div className="flex items-center justify-between p-4 rounded-xl bg-emerald-50 border border-emerald-200">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
                        {evaluationResult.score}%
                      </div>
                      <div>
                        <div className="text-xs font-bold text-emerald-900">Level Cleared! ⭐⭐⭐</div>
                        <div className="text-[11px] text-emerald-700 font-mono">Awarded +{evaluationResult.xpAwarded} XP</div>
                      </div>
                    </div>

                    <button
                      onClick={() => setSelectedNode(null)}
                      className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white transition-all shadow-sm"
                    >
                      Continue Roadmap
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      {/* Level Completion Announcement Overlay Modal */}
      {levelAnnouncement && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="bg-slate-900 border-2 border-emerald-500/50 rounded-3xl max-w-lg w-full p-8 text-center text-white shadow-2xl relative overflow-hidden space-y-6">
            {/* Background Glow */}
            <div className="absolute -top-12 -left-12 w-40 h-40 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -bottom-12 -right-12 w-40 h-40 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />

            {/* Banner Header */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-mono text-xs font-black uppercase tracking-widest animate-pulse">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>🎉 ANNOUNCEMENT: LEVEL COMPLETED!</span>
            </div>

            {/* Pip Avatar & Star Trophy */}
            <div className="flex items-center justify-center gap-3 my-2">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-indigo-500 p-1 shadow-lg shadow-emerald-500/30 flex items-center justify-center">
                <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center text-4xl">
                  🐥
                </div>
              </div>
              <div className="text-4xl animate-bounce">🏆</div>
            </div>

            <div className="space-y-2">
              <div className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">
                Stage {levelAnnouncement.stageId} • Level {levelAnnouncement.levelCode}
              </div>
              <h2 className="text-2xl font-black text-white">
                {levelAnnouncement.nodeTitle}
              </h2>
              <p className="text-xs text-slate-300 italic max-w-md mx-auto">
                "Outstanding execution! You demonstrated key risk management principles and protected your virtual capital!" — Pip 🐥
              </p>
            </div>

            {/* XP & Score Card */}
            <div className="grid grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="flex flex-col items-center">
                <div className="text-[10px] font-mono text-slate-400 uppercase">XP Earned</div>
                <div className="text-2xl font-black text-amber-400 flex items-center gap-1">
                  <Zap className="w-5 h-5 fill-amber-400" />
                  <span>+{levelAnnouncement.xpAwarded}</span>
                </div>
              </div>

              <div className="flex flex-col items-center">
                <div className="text-[10px] font-mono text-slate-400 uppercase">Accuracy Score</div>
                <div className="text-2xl font-black text-emerald-400 flex items-center gap-1">
                  <Star className="w-5 h-5 fill-emerald-400" />
                  <span>{levelAnnouncement.score}%</span>
                </div>
              </div>
            </div>

            {/* Continue Button */}
            <button
              onClick={() => {
                setLevelAnnouncement(null);
                setSelectedNode(null);
              }}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-emerald-500/30 transition-all flex items-center justify-center gap-2"
            >
              <span>Next Level Unlocked • Claim Rewards</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
