import React, { useState } from 'react';
import { UserContext, Badge } from '../types';
import { PRESET_TRADER_PROFILES } from '../data/mockMarketData';
import {
  User,
  LogOut,
  ShieldCheck,
  Award,
  Zap,
  Flame,
  Wallet,
  TrendingUp,
  AlertTriangle,
  RotateCcw,
  Sliders,
  CheckCircle2,
  Lock,
  Mail,
  Calendar,
  Sparkles,
  ShieldAlert,
  ArrowRight,
  Download,
  Users
} from 'lucide-react';

interface AccountDashboardViewProps {
  user: UserContext;
  badges: Badge[];
  onUpdateUser: (updatedUser: Partial<UserContext>) => void;
  onLogout: () => void;
  onSwitchProfile: (profile: UserContext) => void;
  onResetBalance: () => void;
}

export const AccountDashboardView: React.FC<AccountDashboardViewProps> = ({
  user,
  badges,
  onUpdateUser,
  onLogout,
  onSwitchProfile,
  onResetBalance,
}) => {
  const [dailyLossLimitInput, setDailyLossLimitInput] = useState<number>(user.dailyLossLimit || 2000);
  const [isSavedToast, setIsSavedToast] = useState(false);
  const [showConfirmReset, setShowConfirmReset] = useState(false);

  const xpPercentage = Math.min(100, Math.round((user.xp / user.nextLevelXp) * 100));

  const handleSaveRiskSettings = () => {
    onUpdateUser({
      dailyLossLimit: dailyLossLimitInput,
    });
    setIsSavedToast(true);
    setTimeout(() => setIsSavedToast(false), 3000);
  };

  const handleToggleAiNudge = () => {
    onUpdateUser({
      enableAiNudge: !(user.enableAiNudge ?? true),
    });
  };

  const handleToggleEnforceStopLoss = () => {
    onUpdateUser({
      enforceStopLoss: !(user.enforceStopLoss ?? true),
    });
  };

  const handleRiskToleranceChange = (tolerance: 'Conservative' | 'Balanced' | 'Aggressive') => {
    onUpdateUser({ riskTolerance: tolerance });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6 animate-fade-in">
      {/* Top Banner & Profile Overview */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-indigo-500/10 via-purple-500/5 to-transparent rounded-full blur-3xl -z-10" />

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          {/* Left: Avatar & Identity */}
          <div className="flex items-center gap-4">
            <div className="relative">
              <img
                src={user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200'}
                alt={user.name}
                className="w-20 h-20 rounded-2xl object-cover border-2 border-indigo-500/40 shadow-lg"
              />
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-emerald-500 border-2 border-slate-900 flex items-center justify-center text-white" title="Active Trader Session">
                <CheckCircle2 className="w-3.5 h-3.5" />
              </div>
            </div>

            <div>
              <div className="flex items-center gap-3 flex-wrap">
                <h1 className="text-2xl font-extrabold text-white tracking-tight">{user.name}</h1>
                <span className="text-xs font-mono font-bold px-3 py-1 bg-indigo-500/20 text-indigo-300 rounded-full border border-indigo-500/30 flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5 text-indigo-400" />
                  Level {user.level} • {user.role || 'Discipline Apprentice'}
                </span>
              </div>

              <div className="flex items-center gap-4 text-xs text-slate-400 mt-2 flex-wrap font-mono">
                <div className="flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5 text-slate-500" />
                  <span>{user.email || 'trader@questra.ai'}</span>
                </div>
                <span className="text-slate-700">•</span>
                <div className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-500" />
                  <span>Member since {user.joinedDate || 'July 2026'}</span>
                </div>
                <span className="text-slate-700">•</span>
                <div className="flex items-center gap-1 text-amber-400">
                  <Flame className="w-3.5 h-3.5 fill-amber-500/20" />
                  <span>{user.streakDays} Day Active Streak</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Logout & Switch Account Controls */}
          <div className="flex items-center gap-3 w-full md:w-auto">
            <button
              onClick={onLogout}
              className="flex-1 md:flex-initial px-5 py-2.5 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/40 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-md shadow-rose-950/20"
            >
              <LogOut className="w-4 h-4" />
              Log Out of QUESTRA
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns: Financial Capital & Risk Management */}
        <div className="lg:col-span-2 space-y-6">
          {/* Key Financial Metrics Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 relative overflow-hidden">
              <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-1">
                <span>PAPER CAPITAL BALANCE</span>
                <Wallet className="w-4 h-4 text-indigo-400" />
              </div>
              <div className="text-2xl font-extrabold text-white font-mono">
                ₹{(user.paperBalance || 100000).toLocaleString()}
              </div>
              <div className="text-[11px] text-emerald-400 font-mono mt-1 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                <span>Simulated Funds Available</span>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 relative overflow-hidden">
              <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-1">
                <span>DISCIPLINE SCORE</span>
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-extrabold text-emerald-400 font-mono">
                {user.disciplineScore}%
              </div>
              <div className="text-[11px] text-slate-400 font-mono mt-1">
                {user.disciplineScore >= 80 ? 'Grade A: Elite Discipline' : 'Needs Risk Alignment'}
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 relative overflow-hidden">
              <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-1">
                <span>DAILY DRAWDOWN LIMIT</span>
                <ShieldAlert className="w-4 h-4 text-rose-400" />
              </div>
              <div className="text-2xl font-extrabold text-white font-mono">
                ₹{user.dailyLossLimit?.toLocaleString()}
              </div>
              <div className="text-[11px] text-rose-300 font-mono mt-1">
                Current Daily Loss: ₹{user.currentDailyLoss || 0}
              </div>
            </div>
          </div>

          {/* Interactive Risk & AI Nudge Settings */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Sliders className="w-5 h-5 text-indigo-400" />
                <h2 className="font-bold text-base text-white">Risk Management & Questra AI Controls</h2>
              </div>
              {isSavedToast && (
                <span className="text-xs text-emerald-400 font-mono bg-emerald-500/10 border border-emerald-500/30 px-3 py-1 rounded-full animate-fade-in flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Saved Settings
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Daily Loss Limit Input */}
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-300 block">
                  Daily Loss Limit (₹)
                </label>
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-sm">₹</span>
                    <input
                      type="number"
                      value={dailyLossLimitInput}
                      onChange={(e) => setDailyLossLimitInput(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-7 pr-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                  <button
                    onClick={handleSaveRiskSettings}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl transition-all shadow-md shadow-indigo-600/20"
                  >
                    Save
                  </button>
                </div>
                <p className="text-[11px] text-slate-500">
                  Questra AI will trigger a high-risk alert if orders exceed this daily drawdown limit.
                </p>
              </div>

              {/* Risk Tolerance Selector */}
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-300 block">
                  Trading Risk Profile
                </label>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  {(['Conservative', 'Balanced', 'Aggressive'] as const).map((mode) => (
                    <button
                      key={mode}
                      onClick={() => handleRiskToleranceChange(mode)}
                      className={`py-2 rounded-xl border font-semibold transition-all ${
                        (user.riskTolerance || 'Balanced') === mode
                          ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/30'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      {mode}
                    </button>
                  ))}
                </div>
                <p className="text-[11px] text-slate-500">
                  {user.riskTolerance === 'Conservative' && 'Max 1% risk per trade enforced.'}
                  {(user.riskTolerance === 'Balanced' || !user.riskTolerance) && 'Max 2% risk per trade standard.'}
                  {user.riskTolerance === 'Aggressive' && 'Higher position sizes permitted with warnings.'}
                </p>
              </div>
            </div>

            {/* Toggle Switches */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-slate-800/80">
              <div className="flex items-center justify-between p-3.5 bg-slate-950/80 rounded-xl border border-slate-800/80">
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400" /> Pre-Trade Questra Nudge
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">Evaluate FOMO & stop-loss before order execution</div>
                </div>
                <button
                  onClick={handleToggleAiNudge}
                  className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                    (user.enableAiNudge ?? true) ? 'bg-indigo-600' : 'bg-slate-800'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform ${
                      (user.enableAiNudge ?? true) ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              <div className="flex items-center justify-between p-3.5 bg-slate-950/80 rounded-xl border border-slate-800/80">
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Mandatory Stop Loss Rule
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">Require stop-loss entry on paper terminal orders</div>
                </div>
                <button
                  onClick={handleToggleEnforceStopLoss}
                  className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                    (user.enforceStopLoss ?? true) ? 'bg-emerald-600' : 'bg-slate-800'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform ${
                      (user.enforceStopLoss ?? true) ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>

          {/* Emotional Bias History & Discipline Log */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              Emotional Bias Diagnostics & Trigger History
            </h3>

            {user.emotionalMistakesHistory.length === 0 ? (
              <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800/80 text-center text-xs text-slate-400">
                🎉 No emotional bias mistakes detected! Keep honoring your trading plan.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {user.emotionalMistakesHistory.map((item, idx) => (
                  <div key={idx} className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-bold text-rose-400 font-mono">{item.bias}</span>
                      <span className="text-[10px] bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded-full border border-rose-500/30 font-bold">
                        {item.count}x
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Last triggered: {item.lastOccurred}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Account Switcher, Level Progress & Badges */}
        <div className="space-y-6">
          {/* Level Progress */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-indigo-400" />
                <h3 className="font-bold text-sm text-white">Quest Rank & XP</h3>
              </div>
              <span className="text-xs font-bold text-indigo-300 font-mono">Level {user.level}</span>
            </div>

            <div>
              <div className="flex justify-between text-xs text-slate-400 mb-1 font-mono">
                <span>XP Progress</span>
                <span>{user.xp} / {user.nextLevelXp} XP</span>
              </div>
              <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-400 transition-all duration-500"
                  style={{ width: `${xpPercentage}%` }}
                />
              </div>
            </div>

            <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/80 text-xs text-slate-400 space-y-1">
              <div className="text-white font-semibold">How to earn XP:</div>
              <div className="text-[11px]">• Execute orders with defined Stop Loss (+50 XP)</div>
              <div className="text-[11px]">• Complete Academy quizzes & stage exams (+100-500 XP)</div>
              <div className="text-[11px]">• Maintain daily discipline streak (+100 XP/day)</div>
            </div>
          </div>

          {/* Quick Account Switcher */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-400" />
                <h3 className="font-bold text-sm text-white">Switch Trader Profile</h3>
              </div>
            </div>

            <div className="space-y-2">
              {PRESET_TRADER_PROFILES.map((profile) => {
                const isActive = profile.userId === user.userId;
                return (
                  <button
                    key={profile.userId}
                    onClick={() => onSwitchProfile(profile)}
                    className={`w-full p-2.5 rounded-xl border transition-all text-left flex items-center justify-between ${
                      isActive
                        ? 'bg-indigo-600/20 border-indigo-500 text-white'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <img
                        src={profile.avatarUrl}
                        alt={profile.name}
                        className="w-8 h-8 rounded-full object-cover border border-slate-700"
                      />
                      <div>
                        <div className="text-xs font-bold">{profile.name}</div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          L{profile.level} • ₹{profile.paperBalance?.toLocaleString()}
                        </div>
                      </div>
                    </div>

                    {isActive ? (
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded border border-emerald-500/30">
                        Active
                      </span>
                    ) : (
                      <ArrowRight className="w-3.5 h-3.5 text-slate-500" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Badges Showcase */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-sm text-white">Unlocked Quest Badges</h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">
                {user.unlockedBadges.length}/{badges.length}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {badges.map((b) => {
                const isUnlocked = user.unlockedBadges.includes(b.id);
                return (
                  <div
                    key={b.id}
                    className={`p-3 rounded-xl border text-xs transition-all ${
                      isUnlocked
                        ? 'bg-amber-500/10 border-amber-500/30 text-amber-200'
                        : 'bg-slate-950/40 border-slate-800/60 text-slate-600 grayscale opacity-60'
                    }`}
                  >
                    <div className="font-bold text-white flex items-center justify-between">
                      <span className="truncate">{b.title}</span>
                      {isUnlocked && <Award className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5 line-clamp-2">
                      {b.description}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Danger Zone: Reset Paper Balance */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3">
            <h3 className="font-bold text-sm text-slate-300 flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-slate-400" /> Account Management
            </h3>

            {!showConfirmReset ? (
              <button
                onClick={() => setShowConfirmReset(true)}
                className="w-full py-2.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Reset Paper Capital Balance (₹100,000)
              </button>
            ) : (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl space-y-2">
                <div className="text-xs text-rose-300 font-medium">
                  Confirm reset paper balance to ₹100,000?
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      onResetBalance();
                      setShowConfirmReset(false);
                    }}
                    className="flex-1 py-1.5 bg-rose-600 text-white font-bold text-xs rounded-lg hover:bg-rose-500 transition-colors"
                  >
                    Yes, Reset
                  </button>
                  <button
                    onClick={() => setShowConfirmReset(false)}
                    className="flex-1 py-1.5 bg-slate-800 text-slate-300 text-xs rounded-lg hover:bg-slate-700 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            <button
              onClick={onLogout}
              className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl shadow-md shadow-rose-600/20 transition-all flex items-center justify-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              Log Out & Exit Session
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
