import React, { useState } from 'react';
import { UserContext } from '../types';
import { PRESET_TRADER_PROFILES } from '../data/mockMarketData';
import { Shield, Cpu, Lock, UserPlus, LogIn, CheckCircle2, ArrowRight, Zap, Sparkles, AlertCircle, Eye, EyeOff } from 'lucide-react';

interface AuthGatewayModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (userProfile: UserContext) => void;
  currentUser?: UserContext;
}

export const AuthGatewayModal: React.FC<AuthGatewayModalProps> = ({
  isOpen,
  onClose,
  onLogin,
  currentUser,
}) => {
  const [activeTab, setActiveTab] = useState<'preset' | 'email' | 'signup'>('preset');
  
  // Email Login Form State
  const [emailInput, setEmailInput] = useState('alex.mercer@questra.ai');
  const [passwordInput, setPasswordInput] = useState('••••••••');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');

  // Signup Form State
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newCapital, setNewCapital] = useState<number>(100000);
  const [newDailyLoss, setNewDailyLoss] = useState<number>(2000);
  const [newRiskTolerance, setNewRiskTolerance] = useState<'Conservative' | 'Balanced' | 'Aggressive'>('Balanced');

  if (!isOpen) return null;

  const handleEmailLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput.trim()) {
      setLoginError('Please enter a valid email address.');
      return;
    }

    // Match with preset profiles or create profile for entered email
    const matchedProfile = PRESET_TRADER_PROFILES.find(
      (p) => p.email?.toLowerCase() === emailInput.toLowerCase().trim()
    );

    if (matchedProfile) {
      onLogin({ ...matchedProfile, isLoggedIn: true });
    } else {
      // Create customized profile for email
      const customUser: UserContext = {
        userId: `user_${Date.now()}`,
        name: emailInput.split('@')[0].replace('.', ' ').toUpperCase(),
        email: emailInput,
        avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200',
        paperBalance: 100000,
        level: 1,
        xp: 100,
        nextLevelXp: 500,
        disciplineScore: 80,
        streakDays: 1,
        dailyLossLimit: 2000,
        currentDailyLoss: 0,
        winRate: 50,
        emotionalMistakesHistory: [],
        unlockedBadges: ['badge_first_trade'],
        unlockedStage: 1,
        completedNodes: [],
        isLoggedIn: true,
        role: 'Discipline Apprentice',
        joinedDate: 'Today',
        riskTolerance: 'Balanced',
        enableAiNudge: true,
        enforceStopLoss: true,
      };
      onLogin(customUser);
    }
  };

  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newEmail.trim()) {
      setLoginError('Please fill in your name and email address.');
      return;
    }

    const newUser: UserContext = {
      userId: `user_${Date.now()}`,
      name: newName.trim(),
      email: newEmail.trim(),
      avatarUrl: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200`,
      paperBalance: newCapital,
      level: 1,
      xp: 200,
      nextLevelXp: 500,
      disciplineScore: 90,
      streakDays: 1,
      dailyLossLimit: newDailyLoss,
      currentDailyLoss: 0,
      winRate: 60,
      emotionalMistakesHistory: [],
      unlockedBadges: ['badge_first_trade'],
      unlockedStage: 1,
      completedNodes: [],
      isLoggedIn: true,
      role: 'Paper Trader Questor',
      joinedDate: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
      riskTolerance: newRiskTolerance,
      enableAiNudge: true,
      enforceStopLoss: true,
    };

    onLogin(newUser);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl max-w-xl w-full overflow-hidden text-white my-8">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950 p-6 border-b border-slate-800 relative">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-emerald-400 p-0.5 shadow-lg shadow-indigo-500/20">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Cpu className="w-6 h-6 text-emerald-400 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-2xl tracking-wider text-white">QUESTRA</span>
                <span className="text-[10px] uppercase font-mono tracking-widest px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 rounded-full border border-emerald-500/30 font-bold">
                  Questra AI Portal
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Sign in to sync your paper trading account, AI nudges & discipline score
              </p>
            </div>
          </div>
        </div>

        {/* Auth Tab Navigation */}
        <div className="grid grid-cols-3 bg-slate-950/60 border-b border-slate-800 text-xs font-semibold font-mono">
          <button
            onClick={() => { setActiveTab('preset'); setLoginError(''); }}
            className={`py-3 flex items-center justify-center gap-2 transition-colors border-b-2 ${
              activeTab === 'preset'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-500/10'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            Demo Traders
          </button>
          <button
            onClick={() => { setActiveTab('email'); setLoginError(''); }}
            className={`py-3 flex items-center justify-center gap-2 transition-colors border-b-2 ${
              activeTab === 'email'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-500/10'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            Email Login
          </button>
          <button
            onClick={() => { setActiveTab('signup'); setLoginError(''); }}
            className={`py-3 flex items-center justify-center gap-2 transition-colors border-b-2 ${
              activeTab === 'signup'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-500/10'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            New Account
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6">
          {loginError && (
            <div className="mb-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          {/* TAB 1: PRESET DEMO TRADERS */}
          {activeTab === 'preset' && (
            <div className="space-y-4">
              <div className="text-xs text-slate-400 flex items-center justify-between">
                <span>Select a Trader Profile to enter QUESTRA instantly:</span>
                <span className="font-mono text-emerald-400">1-Click Sign In</span>
              </div>

              <div className="space-y-3">
                {PRESET_TRADER_PROFILES.map((profile) => {
                  const isCurrent = currentUser?.userId === profile.userId && currentUser?.isLoggedIn;
                  return (
                    <div
                      key={profile.userId}
                      onClick={() => onLogin({ ...profile, isLoggedIn: true })}
                      className={`p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between group ${
                        isCurrent
                          ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-lg shadow-indigo-500/10'
                          : 'bg-slate-950/80 border-slate-800 hover:border-slate-700 hover:bg-slate-800/50'
                      }`}
                    >
                      <div className="flex items-center gap-3.5">
                        <img
                          src={profile.avatarUrl}
                          alt={profile.name}
                          className="w-11 h-11 rounded-full object-cover border border-slate-700 group-hover:border-indigo-400 transition-colors"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-white group-hover:text-indigo-300 transition-colors">
                              {profile.name}
                            </span>
                            <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                              L{profile.level}
                            </span>
                            {isCurrent && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                                <CheckCircle2 className="w-3 h-3" /> Active
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-slate-400 mt-0.5 font-mono flex items-center gap-3">
                            <span>Balance: ₹{profile.paperBalance?.toLocaleString()}</span>
                            <span>Discipline: <strong className="text-emerald-400">{profile.disciplineScore}%</strong></span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-indigo-400 group-hover:translate-x-1 transition-transform">
                        <span className="text-xs font-semibold hidden sm:inline">Select</span>
                        <ArrowRight className="w-4 h-4" />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: EMAIL LOGIN */}
          {activeTab === 'email' && (
            <form onSubmit={handleEmailLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <input
                    type="email"
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    placeholder="trader@questra.ai"
                    required
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    required
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors font-mono pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-400">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" defaultChecked className="rounded border-slate-800 text-indigo-600 focus:ring-0" />
                  <span>Remember Session</span>
                </label>
                <button type="button" className="text-indigo-400 hover:underline">
                  Forgot password?
                </button>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2"
              >
                <LogIn className="w-4 h-4" />
                Sign In to QUESTRA
              </button>
            </form>
          )}

          {/* TAB 3: CREATE NEW ACCOUNT */}
          {activeTab === 'signup' && (
            <form onSubmit={handleCreateAccount} className="space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="e.g. Vikram Malhotra"
                    required
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    placeholder="vikram@trader.in"
                    required
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Paper Starting Capital (₹)
                  </label>
                  <select
                    value={newCapital}
                    onChange={(e) => setNewCapital(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 font-mono"
                  >
                    <option value={25000}>₹25,000</option>
                    <option value={50000}>₹50,000</option>
                    <option value={100000}>₹1,000,000 (1 Lakh)</option>
                    <option value={500000}>₹500,000 (5 Lakhs)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Daily Drawdown Limit (₹)
                  </label>
                  <input
                    type="number"
                    value={newDailyLoss}
                    onChange={(e) => setNewDailyLoss(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Risk Management Tolerance
                </label>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  {(['Conservative', 'Balanced', 'Aggressive'] as const).map((mode) => (
                    <button
                      key={mode}
                      type="button"
                      onClick={() => setNewRiskTolerance(mode)}
                      className={`py-2 rounded-lg border font-semibold transition-all ${
                        newRiskTolerance === mode
                          ? 'bg-indigo-600 text-white border-indigo-500'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      {mode}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center gap-2 mt-2"
              >
                <UserPlus className="w-4 h-4" />
                Initialize Paper Trader Account
              </button>
            </form>
          )}

          {/* Footer Info */}
          <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
            <div className="flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>Questra AI Protected Paper Environment</span>
            </div>
            {currentUser?.isLoggedIn && (
              <button
                onClick={onClose}
                className="text-slate-400 hover:text-white underline font-semibold"
              >
                Continue as {currentUser.name}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
