import React, { useState, useEffect, useRef } from 'react';
import { StockTicker, PendingOrder, Position, UserContext } from '../types';
import { TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, ShieldCheck, ShieldAlert, Cpu, Activity, Play, Pause, RefreshCw, SlidersHorizontal, DollarSign } from 'lucide-react';

interface TradingTerminalProps {
  tickers: StockTicker[];
  setTickers: React.Dispatch<React.SetStateAction<StockTicker[]>>;
  user: UserContext;
  onOpenNudgeModal: (order: PendingOrder) => void;
  positions: Position[];
  onClosePosition: (positionId: string) => void;
}

export const TradingTerminal: React.FC<TradingTerminalProps> = ({
  tickers,
  setTickers,
  user,
  onOpenNudgeModal,
  positions,
  onClosePosition,
}) => {
  const [selectedSymbol, setSelectedSymbol] = useState<string>('RELIANCE');
  const [isSimulating, setIsSimulating] = useState<boolean>(true);
  const [volatility, setVolatility] = useState<'Normal' | 'Volatile' | 'Rally'>('Normal');

  // Order state
  const selectedTicker = tickers.find((t) => t.symbol === selectedSymbol) || tickers[0];
  const [action, setAction] = useState<'BUY' | 'SELL'>('BUY');
  const [orderType, setOrderType] = useState<'MARKET' | 'LIMIT'>('MARKET');
  const [quantity, setQuantity] = useState<number>(10);
  const [price, setPrice] = useState<number>(selectedTicker.price);
  const [stopLoss, setStopLoss] = useState<string>((selectedTicker.price * 0.95).toFixed(2));
  const [targetPrice, setTargetPrice] = useState<string>((selectedTicker.price * 1.10).toFixed(2));
  const [leverage, setLeverage] = useState<number>(1);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Update order price when ticker changes
  useEffect(() => {
    if (orderType === 'MARKET') {
      setPrice(selectedTicker.price);
    }
  }, [selectedTicker.price, orderType]);

  // Real-time market price simulator tick
  useEffect(() => {
    if (!isSimulating) return;

    const interval = setInterval(() => {
      setTickers((prevTickers) =>
        prevTickers.map((ticker) => {
          let multiplier = 0.002; // 0.2% default
          if (volatility === 'Volatile') multiplier = 0.008;
          if (volatility === 'Rally') multiplier = 0.005;

          const delta = (Math.random() - (volatility === 'Rally' ? 0.35 : 0.5)) * ticker.price * multiplier;
          const newPrice = Number(Math.max(1, ticker.price + delta).toFixed(2));
          const newHistory = [...ticker.history.slice(-19), newPrice];
          const firstPrice = newHistory[0] || newPrice;
          const change = Number((newPrice - firstPrice).toFixed(2));
          const changePercent = Number(((change / firstPrice) * 100).toFixed(2));

          return {
            ...ticker,
            price: newPrice,
            change,
            changePercent,
            history: newHistory,
          };
        })
      );
    }, 2000);

    return () => clearInterval(interval);
  }, [isSimulating, volatility, setTickers]);

  // Draw interactive chart on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear
    ctx.clearRect(0, 0, width, height);

    // Background grid
    ctx.strokeStyle = 'rgba(51, 65, 85, 0.3)';
    ctx.lineWidth = 1;
    const gridRows = 6;
    for (let i = 1; i < gridRows; i++) {
      const y = (height / gridRows) * i;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    const prices = selectedTicker.history;
    if (prices.length < 2) return;

    const minPrice = Math.min(...prices) * 0.99;
    const maxPrice = Math.max(...prices) * 1.01;
    const range = maxPrice - minPrice || 1;

    // Calculate points
    const points = prices.map((p, idx) => {
      const x = (width / (prices.length - 1)) * idx;
      const y = height - ((p - minPrice) / range) * height;
      return { x, y, price: p };
    });

    // Draw gradient area under curve
    const isUp = prices[prices.length - 1] >= prices[0];
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    if (isUp) {
      gradient.addColorStop(0, 'rgba(16, 185, 129, 0.25)');
      gradient.addColorStop(1, 'rgba(16, 185, 129, 0.0)');
    } else {
      gradient.addColorStop(0, 'rgba(239, 68, 68, 0.25)');
      gradient.addColorStop(1, 'rgba(239, 68, 68, 0.0)');
    }

    ctx.beginPath();
    ctx.moveTo(points[0].x, height);
    points.forEach((pt) => ctx.lineTo(pt.x, pt.y));
    ctx.lineTo(points[points.length - 1].x, height);
    ctx.closePath();
    ctx.fillStyle = gradient;
    ctx.fill();

    // Draw price line
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    points.forEach((pt) => ctx.lineTo(pt.x, pt.y));
    ctx.strokeStyle = isUp ? '#10b981' : '#ef4444';
    ctx.lineWidth = 3;
    ctx.stroke();

    // Draw points & values
    points.forEach((pt, i) => {
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, 4, 0, Math.PI * 2);
      ctx.fillStyle = isUp ? '#10b981' : '#ef4444';
      ctx.fill();

      if (i === points.length - 1) {
        // Pulse glow on current price
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 8, 0, Math.PI * 2);
        ctx.fillStyle = isUp ? 'rgba(16, 185, 129, 0.3)' : 'rgba(239, 68, 68, 0.3)';
        ctx.fill();
      }
    });

    // Draw Stop Loss Line if defined
    if (stopLoss && Number(stopLoss) > minPrice && Number(stopLoss) < maxPrice) {
      const slY = height - ((Number(stopLoss) - minPrice) / range) * height;
      ctx.beginPath();
      ctx.setLineDash([5, 5]);
      ctx.moveTo(0, slY);
      ctx.lineTo(width, slY);
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = '#ef4444';
      ctx.font = '11px monospace';
      ctx.fillText(`Stop Loss: ₹${stopLoss}`, 10, slY - 4);
    }

    // Draw Target Line if defined
    if (targetPrice && Number(targetPrice) > minPrice && Number(targetPrice) < maxPrice) {
      const tgY = height - ((Number(targetPrice) - minPrice) / range) * height;
      ctx.beginPath();
      ctx.setLineDash([5, 5]);
      ctx.moveTo(0, tgY);
      ctx.lineTo(width, tgY);
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = '#10b981';
      ctx.font = '11px monospace';
      ctx.fillText(`Target: ₹${targetPrice}`, width - 110, tgY - 4);
    }
  }, [selectedTicker, stopLoss, targetPrice]);

  const handleEvaluateClick = () => {
    const sl = stopLoss ? parseFloat(stopLoss) : undefined;
    const tg = targetPrice ? parseFloat(targetPrice) : undefined;

    const pending: PendingOrder = {
      symbol: selectedTicker.symbol,
      symbolName: selectedTicker.name,
      action,
      orderType,
      price: orderType === 'MARKET' ? selectedTicker.price : price,
      quantity,
      stopLossPrice: sl,
      targetPrice: tg,
      leverage,
    };

    onOpenNudgeModal(pending);
  };

  const activeBroker = user.preferredBroker || 'Zerodha Kite';

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6 text-slate-900">
      {/* Indian Broker Active Platform Mode Banner */}
      <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 text-white flex flex-wrap items-center justify-between gap-4 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-emerald-400 p-0.5 shadow-md">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center font-bold text-lg">
              {activeBroker === 'Zerodha Kite' ? '📈' : activeBroker === 'Groww' ? '🌱' : activeBroker === 'Angel One' ? '🚀' : activeBroker === 'Upstox' ? '⚡' : '🏛️'}
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base tracking-wide text-white">{activeBroker} Terminal Simulator</span>
              <span className="text-[10px] uppercase font-mono font-bold px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded-full border border-emerald-500/30">
                NSE / BSE Live Sync
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Orders and chart workflows are styled for <strong>{activeBroker}</strong>. Practice risk management risk-free!
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-300">
            Paper Capital: <strong className="text-emerald-400">₹{user.paperBalance?.toLocaleString('en-IN') || '1,00,000'}</strong>
          </div>
          <div className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-300">
            Daily Loss Limit: <strong className="text-rose-400">₹{user.dailyLossLimit?.toLocaleString('en-IN') || '2,000'}</strong>
          </div>
        </div>
      </div>

      {/* Top Controls & Ticker Tape */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
        {/* Market Simulation Controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsSimulating(!isSimulating)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
              isSimulating
                ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                : 'bg-slate-100 text-slate-600 border-slate-200'
            }`}
          >
            {isSimulating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isSimulating ? 'Simulated Feed Live' : 'Feed Paused'}</span>
          </button>

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs font-mono">
            <span className="text-slate-500 px-2">Mode:</span>
            {(['Normal', 'Volatile', 'Rally'] as const).map((m) => (
              <button
                key={m}
                onClick={() => setVolatility(m)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium transition-all ${
                  volatility === m ? 'bg-indigo-600 text-white' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        {/* Selected Ticker Summary */}
        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-xs text-slate-500 font-medium">{selectedTicker.name}</div>
            <div className="flex items-center justify-end gap-2">
              <span className="text-xl font-bold font-mono text-slate-900">₹{selectedTicker.price.toFixed(2)}</span>
              <span
                className={`text-xs font-bold font-mono px-2 py-0.5 rounded ${
                  selectedTicker.change >= 0
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-rose-100 text-rose-800'
                }`}
              >
                {selectedTicker.change >= 0 ? '+' : ''}
                {selectedTicker.changePercent}%
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: Watchlist + Chart + Order Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Watchlist (3 cols) */}
        <div className="lg:col-span-3 bg-white rounded-2xl border border-slate-200 p-4 space-y-3 shadow-sm">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center justify-between">
            <span>Market Watchlist</span>
            <Activity className="w-4 h-4 text-indigo-600" />
          </h3>

          <div className="space-y-2">
            {tickers.map((t) => (
              <button
                key={t.symbol}
                onClick={() => {
                  setSelectedSymbol(t.symbol);
                  setStopLoss((t.price * 0.95).toFixed(2));
                  setTargetPrice((t.price * 1.10).toFixed(2));
                }}
                className={`w-full text-left p-3 rounded-xl border transition-all ${
                  selectedSymbol === t.symbol
                    ? 'bg-indigo-50/80 border-indigo-400 shadow-sm'
                    : 'bg-slate-50/80 border-slate-200/80 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900 font-mono">{t.symbol}</span>
                  <span className="font-bold text-xs text-slate-800 font-mono">₹{t.price.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between mt-1 text-xs">
                  <span className="text-slate-500 text-[11px] truncate max-w-[110px]">{t.name}</span>
                  <span
                    className={`font-semibold font-mono ${
                      t.change >= 0 ? 'text-emerald-600' : 'text-rose-600'
                    }`}
                  >
                    {t.change >= 0 ? '+' : ''}
                    {t.changePercent}%
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Center Canvas Chart (6 cols) */}
        <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 p-5 flex flex-col justify-between space-y-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <span>{selectedTicker.symbol}</span>
                <span className="text-xs text-slate-500 font-normal">({selectedTicker.name})</span>
              </h2>
              <p className="text-xs text-slate-500">15-Min Real-Time Price Simulation & AI Support Levels</p>
            </div>
            <div className="text-xs font-mono text-slate-500">
              Vol: <span className="text-slate-900 font-bold">{selectedTicker.volume}</span>
            </div>
          </div>

          {/* Canvas Component */}
          <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 relative">
            <canvas
              ref={canvasRef}
              width={560}
              height={260}
              className="w-full h-[260px] object-contain"
            />
          </div>

          {/* Stats Bar */}
          <div className="grid grid-cols-4 gap-2 text-center text-xs font-mono bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div>
              <span className="text-slate-500 block text-[10px]">24H HIGH</span>
              <span className="text-slate-900 font-bold">₹{selectedTicker.high.toFixed(2)}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">24H LOW</span>
              <span className="text-slate-900 font-bold">₹{selectedTicker.low.toFixed(2)}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">CATEGORY</span>
              <span className="text-indigo-600 font-bold">{selectedTicker.category}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">AI RATING</span>
              <span className="text-emerald-600 font-bold">BULLISH 88%</span>
            </div>
          </div>
        </div>

        {/* Right Order Execution Form (3 cols) */}
        <div className="lg:col-span-3 bg-white rounded-2xl border border-slate-200 p-4 space-y-4 shadow-sm">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center justify-between">
            <span>Order Entry Sandbox</span>
            <SlidersHorizontal className="w-4 h-4 text-indigo-600" />
          </h3>

          {/* BUY / SELL Switch */}
          <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setAction('BUY')}
              className={`py-2 rounded-lg text-xs font-bold transition-all ${
                action === 'BUY'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              BUY / LONG
            </button>
            <button
              onClick={() => setAction('SELL')}
              className={`py-2 rounded-lg text-xs font-bold transition-all ${
                action === 'SELL'
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-600/20'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              SELL / SHORT
            </button>
          </div>

          {/* Order Type */}
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Order Type:</span>
            <div className="flex gap-2">
              <button
                onClick={() => setOrderType('MARKET')}
                className={`px-2.5 py-1 rounded font-mono font-semibold transition-all ${
                  orderType === 'MARKET' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600'
                }`}
              >
                Market
              </button>
              <button
                onClick={() => setOrderType('LIMIT')}
                className={`px-2.5 py-1 rounded font-mono font-semibold transition-all ${
                  orderType === 'LIMIT' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600'
                }`}
              >
                Limit
              </button>
            </div>
          </div>

          {/* Quantity Input */}
          <div className="space-y-1">
            <label className="text-xs text-slate-600 flex justify-between font-medium">
              <span>Quantity (Shares):</span>
              <span className="text-indigo-600 font-mono font-bold">₹{(quantity * selectedTicker.price).toFixed(2)}</span>
            </label>
            <input
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm font-mono text-slate-900 focus:outline-none focus:border-indigo-500 focus:bg-white"
            />
          </div>

          {/* Stop Loss Input */}
          <div className="space-y-1">
            <label className="text-xs text-slate-600 flex justify-between font-medium">
              <span className="flex items-center gap-1 text-rose-600 font-bold">
                <ShieldAlert className="w-3.5 h-3.5" /> Stop Loss (₹):
              </span>
              <button
                onClick={() => setStopLoss('')}
                className="text-[10px] text-slate-400 hover:text-rose-600"
              >
                Clear
              </button>
            </label>
            <input
              type="number"
              step="0.1"
              value={stopLoss}
              placeholder="e.g. 120.00 (Required for high XP)"
              onChange={(e) => setStopLoss(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm font-mono text-slate-900 focus:outline-none focus:border-indigo-500 focus:bg-white placeholder:text-slate-400"
            />
          </div>

          {/* Target Price Input */}
          <div className="space-y-1">
            <label className="text-xs text-slate-600 flex justify-between font-medium">
              <span className="flex items-center gap-1 text-emerald-600 font-bold">
                <ShieldCheck className="w-3.5 h-3.5" /> Target Price (₹):
              </span>
            </label>
            <input
              type="number"
              step="0.1"
              value={targetPrice}
              placeholder="e.g. 135.00"
              onChange={(e) => setTargetPrice(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm font-mono text-slate-900 focus:outline-none focus:border-indigo-500 focus:bg-white placeholder:text-slate-400"
            />
          </div>

          {/* Leverage Slider */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs text-slate-600">
              <span>Leverage:</span>
              <span className={`font-mono font-bold ${leverage > 5 ? 'text-rose-600' : 'text-emerald-600'}`}>
                {leverage}x
              </span>
            </div>
            <input
              type="range"
              min={1}
              max={20}
              value={leverage}
              onChange={(e) => setLeverage(parseInt(e.target.value))}
              className="w-full accent-indigo-600 bg-slate-200 cursor-pointer"
            />
          </div>

          {/* Submit Order -> Triggers Questra Pre-Trade Evaluation */}
          <button
            onClick={handleEvaluateClick}
            className="w-full bg-emerald-600 hover:bg-emerald-500 py-3 rounded-xl font-bold text-xs uppercase tracking-wider text-white shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
          >
            <Cpu className="w-4 h-4 text-emerald-200 animate-pulse" />
            <span>Evaluate with Questra AI</span>
          </button>
        </div>
      </div>

      {/* Bottom Row: Active Positions Table */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-sm">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-600" />
            <span>Active Paper Positions ({positions.length})</span>
          </h3>
          <span className="text-xs text-slate-500">P&L calculates live against simulated feed</span>
        </div>

        {positions.length === 0 ? (
          <div className="text-center py-8 text-slate-400 text-xs">
            No active positions. Place an order above and pass Questra Pre-Trade Evaluation to open a position.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-mono uppercase text-[10px]">
                <tr>
                  <th className="p-3">Symbol</th>
                  <th className="p-3">Side</th>
                  <th className="p-3">Qty</th>
                  <th className="p-3">Entry Price</th>
                  <th className="p-3">Mark Price</th>
                  <th className="p-3">Stop Loss</th>
                  <th className="p-3">Target</th>
                  <th className="p-3">Unrealized P&L</th>
                  <th className="p-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {positions.map((pos) => {
                  const ticker = tickers.find((t) => t.symbol === pos.symbol);
                  const currentPrice = ticker ? ticker.price : pos.currentPrice;
                  const priceDiff = pos.action === 'BUY' ? currentPrice - pos.entryPrice : pos.entryPrice - currentPrice;
                  const pnl = priceDiff * pos.quantity * pos.leverage;
                  const pnlPercent = ((priceDiff / pos.entryPrice) * 100 * pos.leverage).toFixed(2);

                  return (
                    <tr key={pos.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 font-bold text-slate-900">{pos.symbol}</td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          pos.action === 'BUY' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                        }`}>
                          {pos.action} {pos.leverage}x
                        </span>
                      </td>
                      <td className="p-3 text-slate-700">{pos.quantity}</td>
                      <td className="p-3 text-slate-700">₹{pos.entryPrice.toFixed(2)}</td>
                      <td className="p-3 text-slate-900 font-bold">₹{currentPrice.toFixed(2)}</td>
                      <td className="p-3 text-rose-600">
                        {pos.stopLoss ? `₹${pos.stopLoss.toFixed(2)}` : 'NONE ⚠️'}
                      </td>
                      <td className="p-3 text-emerald-600">
                        {pos.target ? `₹${pos.target.toFixed(2)}` : 'NONE'}
                      </td>
                      <td className="p-3">
                        <span className={`font-bold ${pnl >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {pnl >= 0 ? '+' : ''}₹{pnl.toFixed(2)} ({pnlPercent}%)
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => onClosePosition(pos.id)}
                          className="px-3 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-sans text-slate-700 transition-all"
                        >
                          Close Position
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
