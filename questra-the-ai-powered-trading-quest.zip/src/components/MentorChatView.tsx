import React, { useState } from 'react';
import { UserContext } from '../types';
import {
  MessageSquare,
  Cpu,
  Send,
  Brain,
  Sparkles,
  AlertCircle,
  RefreshCw,
  ShieldCheck,
  BookOpen,
  Award,
  Zap,
  CheckCircle2,
  XCircle,
  ArrowRight,
  TrendingUp,
  Target,
  Sliders,
  Play
} from 'lucide-react';

interface MentorChatViewProps {
  user: UserContext;
  onUpdateUser?: (updated: Partial<UserContext>) => void;
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

interface StepWalkthrough {
  stepNumber: number;
  title: string;
  detail: string;
}

interface TrainerExampleData {
  stockSymbol: string;
  exampleTitle: string;
  marketContext: string;
  stepByStepWalkthrough: StepWalkthrough[];
  riskMath: {
    accountCapital: number;
    entryPrice: number;
    stopLossPrice: number;
    targetPrice: number;
    positionSizeShares: number;
    maxLossAmount: number;
    maxGainAmount: number;
    riskRewardRatio: string;
  };
  trainerKeyRules: string[];
  interactiveQuestion: {
    prompt: string;
    options: string[];
    correctIndex: number;
    explanation: string;
    xpReward: number;
  };
}

export const MentorChatView: React.FC<MentorChatViewProps> = ({ user, onUpdateUser }) => {
  const [activeTrainerMode, setActiveTrainerMode] = useState<'chat' | 'examples' | 'drills'>('examples');

  // Chat State
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: `Namaste ${user.name}! I'm Pip 🐥, your AI Trading Tutor & Behavioral Coach!\n\nI have reviewed your profile (Discipline: **${user.disciplineScore}%**, Level: **${user.level}**).\n\nTo help you master Indian stock markets on **${user.preferredBroker || 'Zerodha Kite'}**, I can guide you step-by-step through real trade scenarios, ask mini Socratic questions, or analyze any setup safely! What stock would you like to explore today?`,
      timestamp: 'Just now',
    },
  ]);
  const [input, setInput] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  // Example Walkthrough State
  const [selectedStockSymbol, setSelectedStockSymbol] = useState<string>('RELIANCE');
  const [exampleTopic, setExampleTopic] = useState<string>('Bullish Breakout & Risk Management');
  const [exampleData, setExampleData] = useState<TrainerExampleData | null>(null);
  const [loadingExample, setLoadingExample] = useState<boolean>(false);
  const [quizSelectedOption, setQuizSelectedOption] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);
  const [xpToast, setXpToast] = useState<string | null>(null);

  // Load Example Trade Walkthrough
  const fetchExampleWalkthrough = async (symbol: string, topic: string) => {
    setLoadingExample(true);
    setQuizSelectedOption(null);
    setQuizSubmitted(false);
    setSelectedStockSymbol(symbol);

    try {
      const res = await fetch('/api/gemma/trainer-example', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          symbol,
          topic,
          userContext: user,
        }),
      });
      const data = await res.json();
      setExampleData(data);
    } catch (err) {
      console.error('Error fetching trainer example:', err);
    } finally {
      setLoadingExample(false);
    }
  };

  // Initial load on component mount or tab switch
  React.useEffect(() => {
    if (!exampleData) {
      fetchExampleWalkthrough('RELIANCE', '1:2 Risk-to-Reward Breakout Execution');
    }
  }, []);

  const handleSendChat = async (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim() || loading) return;

    const userMsg: Message = {
      role: 'user',
      content: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/gemma/mentor-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, userMsg],
          userContext: user,
          currentModule: exampleTopic || "Risk Management 101: Stop Loss",
        }),
      });
      const data = await res.json();

      const textReply = data.tutor_message || data.reply || 'Always calculate your position size and protect your capital!';

      const assistantMsg: Message = {
        role: 'assistant',
        content: textReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMsg]);

      // Award XP if Pip granted any
      if (data.award_xp && data.award_xp > 0) {
        const earned = data.award_xp;
        const newXp = user.xp + earned;
        let newLevel = user.level;
        let newNextXp = user.nextLevelXp;

        if (newXp >= newNextXp) {
          newLevel += 1;
          newNextXp += 500;
        }

        if (onUpdateUser) {
          onUpdateUser({
            xp: newXp,
            level: newLevel,
            nextLevelXp: newNextXp,
            disciplineScore: Math.min(100, user.disciplineScore + 1),
          });
        }

        setXpToast(`🐥 Pip awarded +${earned} XP for active learning!`);
        setTimeout(() => setXpToast(null), 4000);
      }
    } catch (err) {
      console.error('Error in mentor chat:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleQuizSubmit = () => {
    if (quizSelectedOption === null || !exampleData) return;
    setQuizSubmitted(true);

    const isCorrect = quizSelectedOption === exampleData.interactiveQuestion.correctIndex;
    if (isCorrect) {
      const earnedXp = exampleData.interactiveQuestion.xpReward || 50;
      const newXp = user.xp + earnedXp;
      let newLevel = user.level;
      let newNextXp = user.nextLevelXp;

      if (newXp >= newNextXp) {
        newLevel += 1;
        newNextXp += 500;
      }

      if (onUpdateUser) {
        onUpdateUser({
          xp: newXp,
          level: newLevel,
          nextLevelXp: newNextXp,
          disciplineScore: Math.min(100, user.disciplineScore + 2),
        });
      }

      setXpToast(`🎉 Correct! +${earnedXp} XP Awarded & Discipline +2%!`);
      setTimeout(() => setXpToast(null), 4000);
    }
  };

  const indianStockPresets = [
    { symbol: 'RELIANCE', name: 'Reliance Ind.', topic: 'Bullish Resistance Breakout' },
    { symbol: 'TCS', name: 'Tata Consultancy', topic: '20 EMA Pullback Entry' },
    { symbol: 'HDFCBANK', name: 'HDFC Bank', topic: 'Stop Loss Defense in Downtrend' },
    { symbol: 'INFY', name: 'Infosys Ltd.', topic: '1:2 Risk-to-Reward Execution' },
    { symbol: 'TATAMOTORS', name: 'Tata Motors', topic: 'Reversal Pattern & Position Sizing' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6 text-slate-900">
      {/* Top AI Trainer Banner Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl -z-10" />

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-emerald-400 p-0.5 shadow-lg flex items-center justify-center shrink-0">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center text-2xl">
                🐥
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-extrabold tracking-tight">Pip 🐥 AI Trading Tutor Arena</h1>
                <span className="text-[10px] uppercase font-mono font-bold px-2.5 py-0.5 bg-emerald-500/20 text-emerald-400 rounded-full border border-emerald-500/30 flex items-center gap-1">
                  <Zap className="w-3 h-3" /> Socratic Questra Coach
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Learn step-by-step trade scenarios on Indian stocks, answer Socratic mini-challenges, and master risk discipline with Pip!
              </p>
            </div>
          </div>

          {/* Trainer Mode Selector Tabs */}
          <div className="flex items-center gap-2 bg-slate-950/80 p-1.5 rounded-xl border border-slate-800/80 w-full md:w-auto">
            <button
              onClick={() => setActiveTrainerMode('examples')}
              className={`flex-1 md:flex-initial px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                activeTrainerMode === 'examples'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              Step-by-Step Examples
            </button>

            <button
              onClick={() => setActiveTrainerMode('chat')}
              className={`flex-1 md:flex-initial px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                activeTrainerMode === 'chat'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              Ask AI Trainer
            </button>
          </div>
        </div>
      </div>

      {/* XP Toast Notification */}
      {xpToast && (
        <div className="bg-emerald-500 text-slate-950 px-4 py-3 rounded-xl shadow-xl font-bold text-xs flex items-center justify-between border border-emerald-400 animate-fade-in">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            <span>{xpToast}</span>
          </div>
          <button onClick={() => setXpToast(null)} className="text-xs underline font-mono">Dismiss</button>
        </div>
      )}

      {/* MODE 1: STEP-BY-STEP EXAMPLES */}
      {activeTrainerMode === 'examples' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Stock Example Selector Sidebar (4 cols) */}
          <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 p-5 space-y-6 shadow-sm">
            <div>
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Target className="w-4 h-4 text-indigo-600" />
                Select Indian Stock Trade Example
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">Choose an asset to load step-by-step AI Trainer breakdown</p>
            </div>

            <div className="space-y-2">
              {indianStockPresets.map((preset) => {
                const isSelected = selectedStockSymbol === preset.symbol;
                return (
                  <button
                    key={preset.symbol}
                    onClick={() => fetchExampleWalkthrough(preset.symbol, preset.topic)}
                    className={`w-full p-3 rounded-xl border text-left transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-indigo-50 border-indigo-400 text-indigo-950 font-bold shadow-sm'
                        : 'bg-slate-50 border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-extrabold flex items-center gap-1.5">
                        <span className="px-2 py-0.5 bg-slate-900 text-white rounded text-[10px] font-mono">
                          {preset.symbol}
                        </span>
                        <span>{preset.name}</span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-1 font-normal">
                        Topic: {preset.topic}
                      </div>
                    </div>
                    {isSelected ? (
                      <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                    ) : (
                      <Play className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Custom Example Topic Request */}
            <div className="pt-4 border-t border-slate-200 space-y-2">
              <label className="text-xs font-bold text-slate-700 block">Request Custom Stock Example</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="e.g., BHARTIARTL or LT"
                  value={exampleTopic}
                  onChange={(e) => setExampleTopic(e.target.value)}
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-indigo-500"
                />
                <button
                  onClick={() => fetchExampleWalkthrough(exampleTopic || 'RELIANCE', 'Custom Strategy Setup')}
                  className="px-3 py-2 bg-indigo-600 text-white font-bold text-xs rounded-xl hover:bg-indigo-500 transition-all shrink-0"
                >
                  Generate
                </button>
              </div>
            </div>

            {/* Trainer Stats Box */}
            <div className="bg-slate-900 text-white p-4 rounded-xl space-y-2 font-mono text-xs">
              <div className="text-indigo-300 font-bold flex items-center gap-1.5">
                <Award className="w-4 h-4" /> Game Progress
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Current Level:</span>
                <span className="font-bold text-amber-400">Level {user.level}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Discipline Rating:</span>
                <span className="font-bold text-emerald-400">{user.disciplineScore}%</span>
              </div>
            </div>
          </div>

          {/* Right Example Walkthrough Content (8 cols) */}
          <div className="lg:col-span-8 space-y-6">
            {loadingExample ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4">
                <RefreshCw className="w-8 h-8 animate-spin text-indigo-600 mx-auto" />
                <div>
                  <h3 className="font-bold text-slate-900">Pip 🐥 Questra AI Tutor is Formulating Example Walkthrough...</h3>
                  <p className="text-xs text-slate-500 mt-1">Calculating position size math and risk-to-reward ratios for {selectedStockSymbol}</p>
                </div>
              </div>
            ) : exampleData ? (
              <>
                {/* Walkthrough Header & Context */}
                <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-sm">
                  <div className="flex items-center justify-between flex-wrap gap-2 pb-3 border-b border-slate-100">
                    <div>
                      <span className="text-xs font-mono font-bold px-2.5 py-1 bg-indigo-50 text-indigo-700 rounded-lg border border-indigo-200">
                        INDIAN STOCK TUTORIAL • {exampleData.stockSymbol}
                      </span>
                      <h2 className="text-xl font-extrabold text-slate-900 mt-2">{exampleData.exampleTitle}</h2>
                    </div>
                    <div className="px-3 py-1.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5">
                      <TrendingUp className="w-4 h-4 text-emerald-600" />
                      R:R Ratio: {exampleData.riskMath.riskRewardRatio}
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                    💡 <strong>Market Context:</strong> {exampleData.marketContext}
                  </p>

                  {/* Step-By-Step Interactive Grid */}
                  <div className="space-y-3 pt-2">
                    <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-500">
                      Step-by-Step AI Trainer Execution Plan
                    </h3>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {exampleData.stepByStepWalkthrough.map((step) => (
                        <div
                          key={step.stepNumber}
                          className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5"
                        >
                          <div className="flex items-center gap-2 text-xs font-bold text-indigo-900">
                            <span className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center text-[11px] font-mono shrink-0">
                              {step.stepNumber}
                            </span>
                            <span>{step.title}</span>
                          </div>
                          <p className="text-xs text-slate-600 leading-relaxed pl-7">{step.detail}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Risk & Position Size Math Box */}
                  <div className="p-4 bg-slate-900 text-white rounded-xl space-y-3 font-mono text-xs">
                    <div className="font-bold text-indigo-300 flex items-center justify-between border-b border-slate-800 pb-2">
                      <span className="flex items-center gap-2">
                        <Sliders className="w-4 h-4 text-indigo-400" />
                        Exact Position Sizing & Risk Math Breakdown
                      </span>
                      <span className="text-[11px] text-slate-400">Account: ₹{exampleData.riskMath.accountCapital.toLocaleString()}</span>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
                      <div className="p-2 bg-slate-950 rounded-lg border border-slate-800">
                        <div className="text-slate-400 text-[10px]">ENTRY PRICE</div>
                        <div className="font-bold text-white text-sm">₹{exampleData.riskMath.entryPrice}</div>
                      </div>
                      <div className="p-2 bg-slate-950 rounded-lg border border-slate-800">
                        <div className="text-slate-400 text-[10px]">STOP LOSS</div>
                        <div className="font-bold text-rose-400 text-sm">₹{exampleData.riskMath.stopLossPrice}</div>
                      </div>
                      <div className="p-2 bg-slate-950 rounded-lg border border-slate-800">
                        <div className="text-slate-400 text-[10px]">TARGET EXIT</div>
                        <div className="font-bold text-emerald-400 text-sm">₹{exampleData.riskMath.targetPrice}</div>
                      </div>
                      <div className="p-2 bg-slate-950 rounded-lg border border-slate-800">
                        <div className="text-slate-400 text-[10px]">MAX SHARES</div>
                        <div className="font-bold text-amber-400 text-sm">{exampleData.riskMath.positionSizeShares} Shares</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Interactive Drill Quiz Card */}
                <div className="bg-white rounded-2xl border border-indigo-200 p-6 space-y-4 shadow-sm relative overflow-hidden">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div className="flex items-center gap-2">
                      <Zap className="w-5 h-5 text-indigo-600" />
                      <h3 className="font-bold text-slate-900 text-sm">Questra Trainer Interactive Drill Question</h3>
                    </div>
                    <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
                      +{exampleData.interactiveQuestion.xpReward} XP Reward
                    </span>
                  </div>

                  <p className="text-xs font-bold text-slate-800 leading-relaxed">
                    {exampleData.interactiveQuestion.prompt}
                  </p>

                  <div className="space-y-2">
                    {exampleData.interactiveQuestion.options.map((opt, idx) => {
                      const isSelected = quizSelectedOption === idx;
                      const isCorrect = idx === exampleData.interactiveQuestion.correctIndex;

                      let btnStyle = 'bg-slate-50 border-slate-200 text-slate-700 hover:border-indigo-400';
                      if (quizSubmitted) {
                        if (isCorrect) {
                          btnStyle = 'bg-emerald-50 border-emerald-500 text-emerald-900 font-bold';
                        } else if (isSelected && !isCorrect) {
                          btnStyle = 'bg-rose-50 border-rose-400 text-rose-900 font-bold';
                        }
                      } else if (isSelected) {
                        btnStyle = 'bg-indigo-50 border-indigo-500 text-indigo-900 font-bold';
                      }

                      return (
                        <button
                          key={idx}
                          disabled={quizSubmitted}
                          onClick={() => setQuizSelectedOption(idx)}
                          className={`w-full p-3 rounded-xl border text-xs text-left transition-all flex items-center justify-between ${btnStyle}`}
                        >
                          <span>{opt}</span>
                          {quizSubmitted && isCorrect && (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          )}
                          {quizSubmitted && isSelected && !isCorrect && (
                            <XCircle className="w-4 h-4 text-rose-500 shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {!quizSubmitted ? (
                    <button
                      disabled={quizSelectedOption === null}
                      onClick={handleQuizSubmit}
                      className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                    >
                      Submit Answer to AI Trainer
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs animate-fade-in">
                      <div className="font-bold text-slate-900 flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-indigo-600" /> Questra Trainer Explanation:
                      </div>
                      <p className="text-slate-600 leading-relaxed">{exampleData.interactiveQuestion.explanation}</p>
                    </div>
                  )}
                </div>
              </>
            ) : null}
          </div>
        </div>
      )}

      {/* MODE 2: DIRECT CHAT WITH AI TRAINER */}
      {activeTrainerMode === 'chat' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Sidebar */}
          <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 p-5 space-y-6 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-200 flex items-center justify-center">
                <Brain className="w-5 h-5 text-indigo-600" />
              </div>
              <div>
                <h3 className="font-bold text-base text-slate-900">Trader Behavioral Memory</h3>
                <p className="text-xs text-slate-500">Questra User Profile</p>
              </div>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3 font-mono text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Discipline Score:</span>
                <span className="font-bold text-emerald-700 text-sm">{user.disciplineScore}%</span>
              </div>
              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-600 h-full transition-all duration-500"
                  style={{ width: `${user.disciplineScore}%` }}
                />
              </div>

              <div className="flex justify-between items-center pt-2 border-t border-slate-200">
                <span className="text-slate-500">Daily Loss Limit:</span>
                <span className="font-bold text-slate-900">₹{user.dailyLossLimit}</span>
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-200">
              <span className="text-xs text-slate-500 font-medium">Quick Trainer Questions:</span>
              <div className="space-y-1.5">
                {[
                  'Explain position sizing for ₹1,00,000 capital in RELIANCE.',
                  'Why is buying after 4 green candles considered FOMO?',
                  'How to set trailing stop loss on NIFTY 50 options?',
                  'What is the 1:2 Risk-to-Reward golden rule?'
                ].map((qp, i) => (
                  <button
                    key={i}
                    onClick={() => handleSendChat(qp)}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 hover:text-slate-900 hover:border-indigo-400 transition-all line-clamp-2"
                  >
                    💡 {qp}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Chat Dialogue */}
          <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 flex flex-col h-[650px] shadow-sm">
            <div className="p-4 border-b border-slate-200 bg-slate-50 rounded-t-2xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-indigo-100 border border-indigo-300 flex items-center justify-center">
                  <Cpu className="w-5 h-5 text-indigo-700 animate-pulse" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Pip 🐥 Questra AI Assistant Chat</h3>
                  <p className="text-xs text-slate-500">Real-time coaching & Indian market breakdown</p>
                </div>
              </div>
            </div>

            <div className="flex-1 p-5 overflow-y-auto space-y-4">
              {messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex items-start gap-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {m.role === 'assistant' && (
                    <div className="w-8 h-8 rounded-lg bg-indigo-50 border border-indigo-200 flex items-center justify-center shrink-0 mt-1">
                      <Cpu className="w-4 h-4 text-indigo-600" />
                    </div>
                  )}

                  <div
                    className={`max-w-xl p-4 rounded-2xl text-xs leading-relaxed ${
                      m.role === 'user'
                        ? 'bg-indigo-600 text-white font-medium rounded-tr-none'
                        : 'bg-slate-50 border border-slate-200 text-slate-800 rounded-tl-none whitespace-pre-line'
                    }`}
                  >
                    <div>{m.content}</div>
                    <div className={`text-[10px] mt-1 text-right ${m.role === 'user' ? 'text-indigo-200' : 'text-slate-400'}`}>
                      {m.timestamp}
                    </div>
                  </div>

                  {m.role === 'user' && (
                    <div className="w-8 h-8 rounded-lg bg-slate-200 border border-slate-300 flex items-center justify-center shrink-0 mt-1 font-bold text-xs text-slate-700">
                      {user.name.charAt(0)}
                    </div>
                  )}
                </div>
              ))}

              {loading && (
                <div className="flex items-center gap-2 text-xs text-slate-500 p-2 font-mono">
                  <RefreshCw className="w-4 h-4 animate-spin text-indigo-600" />
                  <span>Pip 🐥 Questra AI is formulating custom advice...</span>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-slate-200 bg-slate-50 rounded-b-2xl">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendChat();
                }}
                className="flex items-center gap-2"
              >
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask Pip 🐥 Questra AI about Indian stocks, stop loss, or strategy..."
                  className="flex-1 bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs text-slate-900 focus:outline-none focus:border-indigo-500 placeholder:text-slate-400"
                />
                <button
                  type="submit"
                  disabled={!input.trim() || loading}
                  className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-xs font-bold text-white transition-all flex items-center gap-2 shadow-sm"
                >
                  <span>Send</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
