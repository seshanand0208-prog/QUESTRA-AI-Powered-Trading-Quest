import React, { useState, useEffect } from 'react';
import { QuestraLogo } from './QuestraLogo';
import { Sparkles, ArrowRight, ShieldCheck, Zap } from 'lucide-react';

interface QuestraSplashScreenProps {
  onFinishSplash: () => void;
}

export const QuestraSplashScreen: React.FC<QuestraSplashScreenProps> = ({ onFinishSplash }) => {
  const [progress, setProgress] = useState<number>(0);
  const [stageText, setStageText] = useState<string>('Booting Questra Core Engine...');
  const [isFadingOut, setIsFadingOut] = useState<boolean>(false);

  useEffect(() => {
    const timer1 = setTimeout(() => {
      setProgress(30);
      setStageText('Connecting to Zerodha & Indian Market Feeds...');
    }, 400);

    const timer2 = setTimeout(() => {
      setProgress(65);
      setStageText('Initializing Pip 🐥 AI Trading Tutor...');
    }, 1000);

    const timer3 = setTimeout(() => {
      setProgress(100);
      setStageText('Questra Ready! Opening Sign Up Portal...');
    }, 1800);

    const timer4 = setTimeout(() => {
      setIsFadingOut(true);
      setTimeout(() => {
        onFinishSplash();
      }, 400);
    }, 2400);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, [onFinishSplash]);

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-between p-6 sm:p-12 bg-slate-950 text-white selection:bg-emerald-500 transition-opacity duration-500 ${
        isFadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Background Animated Hex Pattern & Glow Orbs */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.15)_0,transparent_70%)] pointer-events-none" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-indigo-600/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Top Bar - Skip Action */}
      <div className="w-full max-w-6xl flex items-center justify-between relative z-10">
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900/80 border border-slate-800 text-xs font-mono text-emerald-400">
          <Zap className="w-3.5 h-3.5 fill-emerald-400" />
          <span>v2.4 • QUESTRA AI ENGINE</span>
        </div>

        <button
          onClick={() => {
            setIsFadingOut(true);
            setTimeout(onFinishSplash, 300);
          }}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300 hover:text-white hover:border-emerald-500/50 text-xs font-mono font-bold transition-all"
        >
          <span>Skip Intro</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Center Animated Logo & Branding */}
      <div className="relative z-10 flex flex-col items-center justify-center space-y-8 my-auto">
        <div className="relative group">
          {/* Pulsing Aura Rings */}
          <div className="absolute -inset-8 rounded-full bg-gradient-to-r from-emerald-500/20 via-indigo-500/20 to-purple-500/20 blur-2xl opacity-75 group-hover:opacity-100 transition duration-1000 animate-pulse" />

          {/* Logo Component with Scale Animation */}
          <div className="transform transition-transform duration-700 hover:scale-105 animate-bounce-slow">
            <QuestraLogo size="xl" showSubtitle={true} layout="vertical" animated={true} />
          </div>
        </div>

        {/* Feature Highlights Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 text-xs font-mono text-slate-400">
          <span className="px-3 py-1 rounded-full bg-slate-900/90 border border-slate-800/80 flex items-center gap-1.5 text-slate-300">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            1% Risk Defense
          </span>
          <span className="px-3 py-1 rounded-full bg-slate-900/90 border border-slate-800/80 flex items-center gap-1.5 text-slate-300">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            Pip 🐥 AI Tutor
          </span>
          <span className="px-3 py-1 rounded-full bg-slate-900/90 border border-slate-800/80 flex items-center gap-1.5 text-slate-300">
            🏆 3 Consolidated Stages
          </span>
        </div>
      </div>

      {/* Bottom Loading Progress Bar */}
      <div className="w-full max-w-md space-y-3 relative z-10 text-center">
        <div className="flex items-center justify-between text-xs font-mono">
          <span className="text-slate-400">{stageText}</span>
          <span className="text-emerald-400 font-bold">{progress}%</span>
        </div>

        {/* Progress Bar Container */}
        <div className="w-full h-2 rounded-full bg-slate-900 border border-slate-800 overflow-hidden p-0.5">
          <div
            className="h-full rounded-full bg-gradient-to-r from-emerald-500 via-teal-400 to-indigo-500 transition-all duration-500 shadow-sm shadow-emerald-500/50"
            style={{ width: `${progress}%` }}
          />
        </div>

        <p className="text-[11px] text-slate-400 font-mono">
          Interactive Socratic Paper Trading • No Real Money at Risk
        </p>
      </div>
    </div>
  );
};
