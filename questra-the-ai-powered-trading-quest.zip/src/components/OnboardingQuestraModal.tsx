import React, { useState } from 'react';
import { UserContext, IndianBroker } from '../types';
import { POPULAR_INDIAN_BROKERS, IndianBrokerDetail } from '../data/indianBrokers';
import {
  Cpu,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  Zap,
  BookOpen,
  Heart,
  Flame,
  Award,
  ChevronRight,
  Sliders,
  TrendingUp,
  Target,
  Brain
} from 'lucide-react';

interface OnboardingQuestraModalProps {
  user: UserContext;
  onCompleteOnboarding: (updatedUser: Partial<UserContext>) => void;
}

export const OnboardingQuestraModal: React.FC<OnboardingQuestraModalProps> = ({
  user,
  onCompleteOnboarding,
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1); // 1: Introduction, 2: Select Indian Broker, 3: Portal & Experience Level
  const [selectedBroker, setSelectedBroker] = useState<IndianBroker>('Zerodha Kite');
  const [experienceLevel, setExperienceLevel] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Beginner');
  const [isPortalAnimating, setIsPortalAnimating] = useState<boolean>(false);

  const selectedBrokerDetail = POPULAR_INDIAN_BROKERS.find((b) => b.id === selectedBroker) || POPULAR_INDIAN_BROKERS[0];

  const handleSelectBrokerAndContinue = () => {
    setIsPortalAnimating(true);
    setCurrentStep(3);
    setTimeout(() => {
      setIsPortalAnimating(false);
    }, 1200);
  };

  const handleFinish = () => {
    let unlockedStage = 1;
    let completedNodes = ['node_1_1'];
    let roleTitle = 'Beginner Questor';

    if (experienceLevel === 'Intermediate') {
      unlockedStage = 2;
      completedNodes = ['node_1_1', 'node_1_2', 'node_1_3', 'node_1_4', 'node_1_5'];
      roleTitle = 'Intermediate Questor';
    } else if (experienceLevel === 'Advanced') {
      unlockedStage = 3;
      completedNodes = [
        'node_1_1', 'node_1_2', 'node_1_3', 'node_1_4', 'node_1_5',
        'node_2_1', 'node_2_2', 'node_2_3', 'node_2_4'
      ];
      roleTitle = 'Advanced Questor';
    }

    onCompleteOnboarding({
      preferredBroker: selectedBroker,
      hasCompletedOnboarding: true,
      hearts: user.hearts || 5,
      maxHearts: 5,
      unlockedStage,
      completedNodes,
      role: roleTitle,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl max-w-3xl w-full overflow-hidden text-white my-8 relative">
        {/* Top Header Step Progress Bar */}
        <div className="bg-slate-950 p-6 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-emerald-400 p-0.5 shadow-md">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Cpu className="w-5 h-5 text-emerald-400 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg text-white">QUESTRA AI TUTOR</span>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 bg-indigo-500/20 text-indigo-300 rounded-full border border-indigo-500/30">
                  Onboarding Step {currentStep} of 3
                </span>
              </div>
              <p className="text-xs text-slate-400">Welcome to your gamified Indian Stock Trading journey</p>
            </div>
          </div>

          {/* Progress Indicator */}
          <div className="flex items-center gap-1.5 font-mono text-xs">
            {[1, 2, 3].map((step) => (
              <div
                key={step}
                className={`w-8 h-2 rounded-full transition-all ${
                  step === currentStep
                    ? 'bg-indigo-500 w-10'
                    : step < currentStep
                    ? 'bg-emerald-500'
                    : 'bg-slate-800'
                }`}
              />
            ))}
          </div>
        </div>

        {/* STEP 1: QUESTRA WELCOME & APP EXPLANATION */}
        {currentStep === 1 && (
          <div className="p-8 space-y-6 text-left animate-fade-in">
            {/* Prominent AI Mentor Avatar Introduction Card */}
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 bg-gradient-to-r from-slate-950 via-indigo-950/60 to-slate-950 p-6 rounded-3xl border border-indigo-500/30 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />

              {/* AI Avatar */}
              <div className="relative shrink-0">
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-emerald-400 p-1 shadow-lg shadow-indigo-500/30">
                  <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center text-4xl">
                    🐥
                  </div>
                </div>
                <span className="absolute -bottom-2 -right-2 px-2 py-0.5 bg-emerald-500 text-slate-950 font-black text-[9px] font-mono rounded-full uppercase tracking-wider shadow">
                  ONLINE
                </span>
              </div>

              <div className="space-y-2 text-center sm:text-left">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-mono font-bold">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Meet Your AI Mentor: Pip 🐥</span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-white">
                  "Hello {user.name}! I am Pip, your Questra AI Trading Tutor."
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  Welcome to <strong>QUESTRA</strong>! I am here to turn stock trading into an engaging game. You'll progress through <strong>3 Consolidated Stages</strong>, earn XP, maintain daily streaks, and practice real-world Indian stock scenarios (Zerodha, Groww, Angel One) with 0 financial risk!
                </p>
              </div>
            </div>

            {/* Core Mission Features */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm">
                  📚
                </div>
                <div className="font-extrabold text-xs text-white">Questra Skill Path</div>
                <div className="text-[11px] text-slate-400">
                  Level up through bite-sized interactive trade scenarios and pattern drills.
                </div>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-sm">
                  🛡️
                </div>
                <div className="font-extrabold text-xs text-white">1% Risk Defense Rule</div>
                <div className="text-[11px] text-slate-400">
                  Master exact position sizing and mandatory stop loss placement on every trade.
                </div>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <div className="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold text-sm">
                  🤖
                </div>
                <div className="font-extrabold text-xs text-white">AI Post-Mortem</div>
                <div className="text-[11px] text-slate-400">
                  Instant Questra AI audit on every trade to eliminate emotional mistakes.
                </div>
              </div>
            </div>

            <button
              onClick={() => setCurrentStep(2)}
              className="w-full py-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2"
            >
              <span>Next: Choose Your Indian Trading App</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* STEP 2: SELECT POPULAR INDIAN TRADING APP */}
        {currentStep === 2 && (
          <div className="p-8 space-y-6 text-left animate-fade-in">
            <div>
              <span className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-widest">
                STEP 2 • INDIAN PLATFORM PREFERENCE
              </span>
              <h2 className="text-xl font-extrabold text-white mt-1">
                Which Indian Trading App do you plan to trade on?
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                QUESTRA will adapt your paper terminal layout, order execution style, and example walkthroughs to mirror your chosen platform!
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[340px] overflow-y-auto pr-1">
              {POPULAR_INDIAN_BROKERS.map((broker) => {
                const isSelected = selectedBroker === broker.id;
                return (
                  <button
                    key={broker.id}
                    onClick={() => setSelectedBroker(broker.id)}
                    className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden flex flex-col justify-between ${
                      isSelected
                        ? 'bg-slate-950 border-indigo-500 ring-2 ring-indigo-500/40 shadow-lg shadow-indigo-500/20'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">{broker.logoIcon}</span>
                          <div>
                            <div className="font-extrabold text-sm text-white">{broker.name}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{broker.usersCount}</div>
                          </div>
                        </div>
                        {isSelected && (
                          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                        )}
                      </div>

                      <p className="text-xs text-slate-300 mt-2 line-clamp-2 leading-relaxed">
                        {broker.description}
                      </p>

                      <div className="flex flex-wrap gap-1 mt-3">
                        {broker.highlights.slice(0, 2).map((h, idx) => (
                          <span
                            key={idx}
                            className="text-[10px] font-mono px-2 py-0.5 bg-slate-900 border border-slate-800 text-slate-400 rounded-md"
                          >
                            ✓ {h}
                          </span>
                        ))}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Selection Confirmation Bar */}
            <div className="p-3.5 bg-indigo-950/60 border border-indigo-800/60 rounded-2xl flex items-center justify-between text-xs font-mono">
              <span className="text-slate-300">
                Selected Platform: <strong className="text-indigo-300">{selectedBroker}</strong>
              </span>
              <span className="text-emerald-400 font-bold">✓ Ready to Configure</span>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setCurrentStep(1)}
                className="px-5 py-3.5 bg-slate-800 text-slate-300 hover:text-white font-bold text-xs rounded-xl transition-all"
              >
                Back
              </button>
              <button
                onClick={handleSelectBrokerAndContinue}
                className="flex-1 py-3.5 bg-gradient-to-r from-indigo-600 via-purple-600 to-emerald-600 hover:from-indigo-500 hover:to-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2"
              >
                <span>Select & Enter Questra Portal</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: QUESTRA WELCOME PORTAL & EXPERIENCE ASSESSMENT */}
        {currentStep === 3 && (
          <div className="p-8 space-y-6 text-left animate-fade-in relative overflow-hidden">
            {/* Animated Portal Glow Opening */}
            {isPortalAnimating ? (
              <div className="py-16 flex flex-col items-center justify-center text-center space-y-6 animate-pulse">
                <div className="relative">
                  <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-indigo-500 via-purple-500 to-emerald-400 p-1 animate-spin shadow-2xl shadow-indigo-500/50 flex items-center justify-center">
                    <div className="w-full h-full bg-slate-950 rounded-full flex items-center justify-center">
                      <Sparkles className="w-12 h-12 text-emerald-400 animate-bounce" />
                    </div>
                  </div>
                  <div className="absolute inset-0 rounded-full bg-indigo-500/30 blur-xl animate-ping pointer-events-none" />
                </div>

                <div className="space-y-2">
                  <div className="text-2xl font-black bg-gradient-to-r from-indigo-300 via-purple-300 to-emerald-300 bg-clip-text text-transparent uppercase tracking-wider">
                    WELCOME TO QUESTRA! LET'S BEGIN...
                  </div>
                  <p className="text-xs text-slate-400 font-mono">
                    Initializing {selectedBroker} Trading Engine & Pip 🐥 AI Tutor...
                  </p>
                </div>
              </div>
            ) : (
              <>
                {/* Welcome & Experience Title */}
                <div className="bg-gradient-to-r from-slate-950 via-indigo-950/80 to-slate-950 p-6 rounded-3xl border border-indigo-500/40 shadow-xl relative overflow-hidden flex flex-col sm:flex-row items-center gap-5">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-400 via-indigo-500 to-purple-500 p-1 shrink-0 flex items-center justify-center shadow-lg shadow-indigo-500/30">
                    <div className="w-full h-full bg-slate-950 rounded-[12px] flex items-center justify-center text-3xl">
                      🐥
                    </div>
                  </div>

                  <div className="space-y-1 text-center sm:text-left">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-mono font-bold">
                      <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                      <span>WELCOME TO QUESTRA! LET'S BEGIN!</span>
                    </div>
                    <h2 className="text-xl font-extrabold text-white">
                      What is your experience level in stock trading?
                    </h2>
                    <p className="text-xs text-slate-300">
                      Pip 🐥 will adapt your 3-Stage learning path, quiz difficulty, and starting trade challenges based on your response!
                    </p>
                  </div>
                </div>

                {/* Experience Assessment Options */}
                <div className="space-y-3">
                  {/* Option 1: Beginner */}
                  <button
                    onClick={() => setExperienceLevel('Beginner')}
                    className={`w-full p-4 rounded-2xl border text-left transition-all flex items-start gap-4 ${
                      experienceLevel === 'Beginner'
                        ? 'bg-slate-950 border-emerald-500 ring-2 ring-emerald-500/40 shadow-lg shadow-emerald-500/20'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xl shrink-0">
                      🐣
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <div className="font-extrabold text-sm text-white">Beginner (0 - 6 Months)</div>
                        {experienceLevel === 'Beginner' && <CheckCircle2 className="w-5 h-5 text-emerald-400" />}
                      </div>
                      <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                        "I'm new to trading or want to build strong fundamentals. Start me from Stage 1: 1% Risk Defense & Mandatory Stop Losses."
                      </p>
                      <div className="mt-2 text-[10px] font-mono text-emerald-400 font-bold">
                        ✓ Unlocks Stage 1 (Foundations & Risk Management)
                      </div>
                    </div>
                  </button>

                  {/* Option 2: Intermediate */}
                  <button
                    onClick={() => setExperienceLevel('Intermediate')}
                    className={`w-full p-4 rounded-2xl border text-left transition-all flex items-start gap-4 ${
                      experienceLevel === 'Intermediate'
                        ? 'bg-slate-950 border-indigo-500 ring-2 ring-indigo-500/40 shadow-lg shadow-indigo-500/20'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-xl shrink-0">
                      📈
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <div className="font-extrabold text-sm text-white">Intermediate (6 Months - 2 Years)</div>
                        {experienceLevel === 'Intermediate' && <CheckCircle2 className="w-5 h-5 text-indigo-400" />}
                      </div>
                      <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                        "I know basic market orders. I want to master candlestick patterns, breakouts, and position sizing math."
                      </p>
                      <div className="mt-2 text-[10px] font-mono text-indigo-400 font-bold">
                        ✓ Unlocks Stage 1 & Stage 2 (Technical Patterns & Breakouts)
                      </div>
                    </div>
                  </button>

                  {/* Option 3: Advanced */}
                  <button
                    onClick={() => setExperienceLevel('Advanced')}
                    className={`w-full p-4 rounded-2xl border text-left transition-all flex items-start gap-4 ${
                      experienceLevel === 'Advanced'
                        ? 'bg-slate-950 border-purple-500 ring-2 ring-purple-500/40 shadow-lg shadow-purple-500/20'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center text-xl shrink-0">
                      ⚡
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <div className="font-extrabold text-sm text-white">Experienced / Pro Trader (2+ Years)</div>
                        {experienceLevel === 'Advanced' && <CheckCircle2 className="w-5 h-5 text-purple-400" />}
                      </div>
                      <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                        "I trade regularly. I want to eliminate emotional biases (FOMO, revenge trading) & refine advanced price action setups."
                      </p>
                      <div className="mt-2 text-[10px] font-mono text-purple-400 font-bold">
                        ✓ Unlocks All 3 Stages (Advanced Price Action & Behavioral Arena)
                      </div>
                    </div>
                  </button>
                </div>

                {/* Final Launch Action */}
                <div className="flex gap-3 pt-2">
                  <button
                    onClick={() => setCurrentStep(2)}
                    className="px-5 py-4 bg-slate-800 text-slate-300 hover:text-white font-bold text-xs rounded-xl transition-all"
                  >
                    Back
                  </button>
                  <button
                    onClick={handleFinish}
                    className="flex-1 py-4 bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-600 hover:from-emerald-400 hover:to-indigo-500 text-slate-950 font-black text-sm rounded-xl shadow-xl shadow-emerald-500/30 transition-all flex items-center justify-center gap-2"
                  >
                    <Sparkles className="w-5 h-5" />
                    <span>Start Teaching & Enter Questra Arena ({experienceLevel})</span>
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
