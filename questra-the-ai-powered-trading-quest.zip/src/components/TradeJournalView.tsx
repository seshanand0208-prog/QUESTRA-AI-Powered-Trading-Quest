import React, { useState } from 'react';
import { TradeJournalEntry } from '../types';
import { BookMarked, Award, CheckCircle2, AlertTriangle, TrendingUp, TrendingDown, Cpu, RefreshCw } from 'lucide-react';

interface TradeJournalViewProps {
  entries: TradeJournalEntry[];
  onUpdateEntry: (updatedEntry: TradeJournalEntry) => void;
}

export const TradeJournalView: React.FC<TradeJournalViewProps> = ({ entries, onUpdateEntry }) => {
  const [loadingMap, setLoadingMap] = useState<Record<string, boolean>>({});

  const handleRunPostMortem = async (entry: TradeJournalEntry) => {
    setLoadingMap((prev) => ({ ...prev, [entry.id]: true }));

    try {
      const res = await fetch('/api/gemma/post-mortem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tradeLog: entry }),
      });
      const data = await res.json();

      if (data.aiPostMortem) {
        onUpdateEntry({
          ...entry,
          aiPostMortem: data.aiPostMortem,
        });
      }
    } catch (err) {
      console.error('Failed post-mortem:', err);
    } finally {
      setLoadingMap((prev) => ({ ...prev, [entry.id]: false }));
    }
  };

  const totalPnl = entries.reduce((acc, curr) => acc + curr.pnl, 0);
  const wins = entries.filter((e) => e.pnl > 0).length;
  const winRate = entries.length > 0 ? Math.round((wins / entries.length) * 100) : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-8 text-slate-900">
      {/* Header Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 flex flex-wrap items-center justify-between gap-6 shadow-sm">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-indigo-600 text-xs font-mono font-bold uppercase tracking-wider">
            <BookMarked className="w-4 h-4" />
            <span>Reflective Learning Log</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900">Trade Journal & Questra AI Post-Mortem Audit</h2>
          <p className="text-xs text-slate-600">
            Every trade is an opportunity to learn. Review closed trade logs and run AI Post-Mortems to pinpoint behavioral strengths & areas for growth.
          </p>
        </div>

        {/* Stats Summary */}
        <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200 font-mono text-xs">
          <div>
            <span className="text-slate-500 block text-[10px]">TOTAL P&L</span>
            <span className={`font-bold text-sm ${totalPnl >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
              {totalPnl >= 0 ? '+' : ''}₹{totalPnl.toFixed(2)}
            </span>
          </div>
          <div className="h-8 w-px bg-slate-200" />
          <div>
            <span className="text-slate-500 block text-[10px]">WIN RATE</span>
            <span className="font-bold text-sm text-indigo-700">{winRate}%</span>
          </div>
          <div className="h-8 w-px bg-slate-200" />
          <div>
            <span className="text-slate-500 block text-[10px]">TRADES LOGGED</span>
            <span className="font-bold text-sm text-slate-900">{entries.length}</span>
          </div>
        </div>
      </div>

      {/* Trade Entries List */}
      <div className="space-y-4">
        {entries.length === 0 ? (
          <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center text-slate-400 text-xs shadow-sm">
            No trade logs yet. Open and close positions in the Paper Trading Terminal to build your journal history.
          </div>
        ) : (
          entries.map((entry) => (
            <div key={entry.id} className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-sm">
              {/* Top Row Header */}
              <div className="flex flex-wrap items-center justify-between gap-4 font-mono text-xs">
                <div className="flex items-center gap-3">
                  <span className={`px-2.5 py-1 rounded-md font-bold ${
                    entry.action === 'BUY' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                  }`}>
                    {entry.action} {entry.symbol}
                  </span>
                  <span className="text-slate-500">Qty: {entry.quantity}</span>
                  <span className="text-slate-300">|</span>
                  <span className="text-slate-700">Entry: ₹{entry.entryPrice.toFixed(2)}</span>
                  <span className="text-slate-700">Exit: ₹{entry.exitPrice.toFixed(2)}</span>
                </div>

                <div className="flex items-center gap-3">
                  <span className={`font-bold text-sm ${entry.pnl >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                    {entry.pnl >= 0 ? '+' : ''}₹{entry.pnl.toFixed(2)} ({entry.pnlPercentage}%)
                  </span>

                  <span className="text-[11px] text-slate-400">{entry.timestamp}</span>
                </div>
              </div>

              {/* AI Post Mortem Box if available */}
              {entry.aiPostMortem ? (
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-xs font-bold text-indigo-700 uppercase tracking-wider">
                      <Cpu className="w-4 h-4 text-emerald-600" />
                      <span>Questra Post-Mortem Audit</span>
                    </div>

                    {/* Grade Badge */}
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs text-slate-500">Execution Grade:</span>
                      <span className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs font-mono border ${
                        entry.aiPostMortem.grade === 'A'
                          ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                          : entry.aiPostMortem.grade === 'B'
                          ? 'bg-indigo-100 text-indigo-800 border-indigo-300'
                          : 'bg-amber-100 text-amber-800 border-amber-300'
                      }`}>
                        {entry.aiPostMortem.grade}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                    {/* Strengths */}
                    <div className="space-y-1.5">
                      <div className="text-[11px] font-bold text-emerald-700 uppercase">Execution Strengths</div>
                      <ul className="space-y-1">
                        {entry.aiPostMortem.strengths.map((s, idx) => (
                          <li key={idx} className="flex items-center gap-1.5 text-slate-700">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>{s}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Mistakes */}
                    <div className="space-y-1.5">
                      <div className="text-[11px] font-bold text-amber-700 uppercase">Areas For Improvement</div>
                      <ul className="space-y-1">
                        {entry.aiPostMortem.mistakes.map((m, idx) => (
                          <li key={idx} className="flex items-center gap-1.5 text-slate-700">
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                            <span>{m}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Key Takeaway */}
                  <div className="bg-indigo-50 p-3 rounded-lg border border-indigo-200 text-xs text-indigo-900">
                    <span className="font-bold text-indigo-950">Key Takeaway: </span>
                    <span>{entry.aiPostMortem.keyTakeaway}</span>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                  <span className="text-xs text-slate-500">Post-Mortem Audit pending for this closed trade.</span>
                  <button
                    disabled={loadingMap[entry.id]}
                    onClick={() => handleRunPostMortem(entry)}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white shadow-sm transition-all"
                  >
                    {loadingMap[entry.id] ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Cpu className="w-3.5 h-3.5" />
                    )}
                    <span>Run Questra AI Post-Mortem</span>
                  </button>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
