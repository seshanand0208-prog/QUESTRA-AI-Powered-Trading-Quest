import React from 'react';

interface QuestraLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
  layout?: 'horizontal' | 'vertical';
  animated?: boolean;
}

export const QuestraLogo: React.FC<QuestraLogoProps> = ({
  className = '',
  size = 'md',
  showSubtitle = true,
  layout = 'vertical',
  animated = false,
}) => {
  // Dimension mappings
  const dimensions = {
    sm: { icon: 32, text: 'text-sm', sub: 'text-[8px]', gap: 'gap-2' },
    md: { icon: 48, text: 'text-xl', sub: 'text-[10px]', gap: 'gap-3' },
    lg: { icon: 72, text: 'text-3xl', sub: 'text-xs', gap: 'gap-4' },
    xl: { icon: 110, text: 'text-5xl', sub: 'text-sm', gap: 'gap-5' },
  }[size];

  return (
    <div
      className={`inline-flex ${
        layout === 'vertical' ? 'flex-col items-center text-center' : 'flex-row items-center text-left'
      } ${dimensions.gap} ${className}`}
    >
      {/* 3D Geometric Hexagon Q Icon */}
      <div className={`relative shrink-0 ${animated ? 'animate-pulse' : ''}`}>
        <svg
          width={dimensions.icon}
          height={dimensions.icon}
          viewBox="0 0 200 200"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="drop-shadow-[0_10px_20px_rgba(16,185,129,0.25)] filter"
        >
          <defs>
            {/* White-Silver Isometric Gradients */}
            <linearGradient id="qTopFace" x1="100" y1="20" x2="160" y2="120" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#CBD5E1" />
            </linearGradient>

            <linearGradient id="qLeftFace" x1="40" y1="60" x2="100" y2="160" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#E2E8F0" />
              <stop offset="100%" stopColor="#64748B" />
            </linearGradient>

            <linearGradient id="qInnerFace" x1="60" y1="80" x2="140" y2="140" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#0F172A" />
              <stop offset="100%" stopColor="#020617" />
            </linearGradient>

            {/* Vibrant Emerald Green Slash Gradient */}
            <linearGradient id="qEmeraldSlash" x1="100" y1="120" x2="180" y2="175" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#34D399" />
              <stop offset="50%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#059669" />
            </linearGradient>

            <filter id="emeraldGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="8" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Background Ambient Glow */}
          <circle cx="100" cy="100" r="70" fill="#10B981" opacity="0.15" className="blur-xl" />

          {/* Outer Hexagon - Top & Right Bevel */}
          <path
            d="M 100 22 L 165 58 L 165 115 L 140 100 L 140 72 L 100 50 L 60 72 L 60 128 L 100 150 L 115 142 L 125 160 L 100 178 L 35 142 L 35 58 Z"
            fill="url(#qTopFace)"
          />

          {/* Outer Hexagon - Inner Cutout Dark Core */}
          <path
            d="M 100 50 L 140 72 L 140 100 L 122 90 L 122 79 L 100 67 L 78 79 L 78 121 L 100 133 L 108 129 L 118 145 L 100 150 L 60 128 L 60 72 Z"
            fill="url(#qLeftFace)"
            opacity="0.9"
          />

          {/* Green Slash Diagonal - Forming the Q Tail */}
          <path
            d="M 102 118 L 142 95 L 180 162 L 140 185 Z"
            fill="url(#qEmeraldSlash)"
            filter="url(#emeraldGlow)"
          />

          {/* 3D Highlight Edge on Green Slash */}
          <path
            d="M 102 118 L 142 95 L 148 105 L 112 126 Z"
            fill="#A7F3D0"
            opacity="0.8"
          />
        </svg>
      </div>

      {/* Typography Section */}
      <div className="flex flex-col items-center">
        {/* Main Brand Title QUESTRA */}
        <div className={`font-black tracking-[0.35em] text-white uppercase font-sans ${dimensions.text} flex items-center`}>
          <span>Q U E S T R</span>
          {/* Custom Stylized Triangular 'A' */}
          <span className="relative inline-block text-emerald-400 ml-1">
            <svg className="w-[0.85em] h-[0.85em] inline-block -mt-1" viewBox="0 0 100 100" fill="currentColor">
              <path d="M 50 10 L 95 90 L 72 90 L 50 48 L 28 90 L 5 90 Z" />
            </svg>
          </span>
        </div>

        {/* Subtitle */}
        {showSubtitle && (
          <div className={`flex items-center gap-2 mt-1 font-mono font-bold tracking-widest text-slate-400 uppercase ${dimensions.sub}`}>
            <span className="w-3 h-[1px] bg-emerald-500" />
            <span>THE AI-POWERED TRADING QUEST</span>
            <span className="w-3 h-[1px] bg-emerald-500" />
          </div>
        )}
      </div>
    </div>
  );
};
