export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type EmotionalBias = 'FOMO' | 'REVENGE_TRADING' | 'OVER_LEVERAGING' | 'NO_STOP_LOSS' | 'PANIC_SELLING' | 'NONE';

export type IndianBroker = 'Zerodha Kite' | 'Groww' | 'Angel One' | 'Upstox' | 'ICICI Direct';

export interface UserContext {
  userId: string;
  name: string;
  email?: string;
  avatarUrl?: string;
  paperBalance?: number;
  level: number;
  xp: number;
  nextLevelXp: number;
  disciplineScore: number; // 0 to 100
  streakDays: number;
  hearts?: number; // default 5
  maxHearts?: number; // 5
  preferredBroker?: IndianBroker;
  hasCompletedOnboarding?: boolean;
  dailyLossLimit: number; // in ₹
  currentDailyLoss: number;
  winRate: number; // e.g. 64%
  emotionalMistakesHistory: {
    bias: EmotionalBias;
    count: number;
    lastOccurred: string;
  }[];
  unlockedBadges: string[];
  unlockedStage?: number; // 1, 2, or 3
  completedNodes?: string[]; // array of node IDs passed
  isLoggedIn?: boolean;
  role?: string;
  joinedDate?: string;
  riskTolerance?: 'Conservative' | 'Balanced' | 'Aggressive';
  enableAiNudge?: boolean;
  enforceStopLoss?: boolean;
}

export interface PendingOrder {
  id?: string;
  symbol: string;
  symbolName: string;
  action: 'BUY' | 'SELL';
  orderType: 'MARKET' | 'LIMIT';
  price: number;
  quantity: number;
  stopLossPrice?: number;
  targetPrice?: number;
  leverage: number;
  chartImageBase64?: string;
  notes?: string;
}

export interface PreTradeNudgeResult {
  reasoningSteps: string; // Questra AI's <|think|> chain
  riskScore: RiskLevel;
  detectedBias: EmotionalBias;
  coachingNudge: string;
  riskRewardRatio: number;
  disciplineXpDelta: number;
  recommendations: string[];
}

export interface Position {
  id: string;
  symbol: string;
  symbolName: string;
  action: 'BUY' | 'SELL';
  entryPrice: number;
  currentPrice: number;
  quantity: number;
  leverage: number;
  stopLoss?: number;
  target?: number;
  pnl: number;
  pnlPercentage: number;
  timestamp: string;
}

export interface TradeJournalEntry {
  id: string;
  symbol: string;
  action: 'BUY' | 'SELL';
  entryPrice: number;
  exitPrice: number;
  quantity: number;
  pnl: number;
  pnlPercentage: number;
  heldDuration: string;
  biasDetected?: EmotionalBias;
  disciplineXpGained: number;
  aiPostMortem?: {
    strengths: string[];
    mistakes: string[];
    keyTakeaway: string;
    grade: 'A' | 'B' | 'C' | 'D' | 'F';
  };
  timestamp: string;
}

export interface StockTicker {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  high: number;
  low: number;
  volume: string;
  category: 'STOCKS' | 'CRYPTO' | 'INDICES' | 'FOREX';
  history: number[]; // recent prices for sparkline / chart
}

export interface AcademyModule {
  id: string;
  title: string;
  category: string;
  description: string;
  icon: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  xpReward: number;
  completed: boolean;
  lessons: {
    id: string;
    title: string;
    content: string;
    keyTakeaways: string[];
    quiz: {
      question: string;
      options: string[];
      correctIndex: number;
      explanation: string;
    };
  }[];
}

export interface DailyChallenge {
  id: string;
  title: string;
  description: string;
  xpReward: number;
  progress: number;
  target: number;
  completed: boolean;
  type: 'TRADE_WITH_STOP_LOSS' | 'PATTERNS_QUIZ' | 'ZERO_FOMO_DAY' | 'REVIEW_JOURNAL';
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  iconName: string;
  unlocked: boolean;
  unlockedAt?: string;
}

export interface ChartDiagnosticResult {
  patternDetected: string;
  trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  confidenceScore: number;
  supportLevels: number[];
  resistanceLevels: number[];
  keyIndicators: {
    rsi: string;
    macd: string;
    ema: string;
  };
  suggestedAction: 'BUY' | 'SELL' | 'WAIT';
  tradeSetup: {
    suggestedEntry: number;
    suggestedStopLoss: number;
    suggestedTarget: number;
    riskReward: string;
  };
  gemmaAnalysisText: string;
}
